$("#printButton").click(function(){
		printPage();
	});
	function printCurrentPage(){
		$('#printBtn').css('display','none');
		$('.wrapper').css('min-height','0');
		$('.right-pannel').css('margin-top', '-50px');
		$('.navbar').css('display','none');
		$('.icons-print').remove();
		window.document.close();
        window.print();
        window.close();
	}
	function printPage(){
		/*$('.backBtn').css('display', 'none');*/
		$('.navbar').remove();
		$('.icons-print').remove();
		/*$('#backbutton1').css('display', 'none');*/
		$('.wrapper').css('min-height','0');
		$('body').css('page-break-after','avoid');
		$('body').css('page-break-before','avoid');
		$('body').css('page-break-inside','avoid');
        
    	var html="<html>";
		html+= $('head').html();
		$('body').append('<center><button onclick="printCurrentPage()" id="printBtn" type="button">Print</button></center>');
		html+= $('body').html();
		html+="</html>";		
		var printWin = window.open('','','left=0,top=0,scrollbars=1');
		printWin.document.write(html);
		printWin.focus();
		location.reload();
	}
