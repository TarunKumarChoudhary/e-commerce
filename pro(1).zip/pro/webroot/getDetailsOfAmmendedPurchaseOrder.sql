CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailsOfAmmendedPurchaseOrder`(IN `po_idIn` BIGINT)
    NO SQL
BEGIN 


		SELECT 
		apo.id, 
		apo.new_po_nubmer as po_number, 
		po.exp_del_date,
		po.reg_date, 
		po.department_id,  
		terms.name as term_name,
		terms.content as content,
		s.id AS supplier_id, 
		s.name AS supplier_name, 
		s.address AS supplier_address, 
		s.gst_no AS supplier_gst_no,
		s.vendor_code as vendor_code,
		s.phone_no as phone_no,	
		po.reporting_person_id, 
		e.employee_name AS reporting_person_name, 
		e.phone_no AS reporting_person_phone_no, 
		po.address_id, 
		po.prepared_by_id, 
		pe.employee_name AS prepared_by_name, 
		apo.created_on, 
		apo.freight,
        apo.freight as total_amount,
		apo.status,
		po.mode_of_dispatch,
		sa.delivery_address,
		site.billing_address,
		company.cin_no 
	FROM 
		purchase_orders AS po  
			LEFT JOIN suppliers AS s ON po.supplier_id = s.id 
			LEFT JOIN employee AS e ON po.reporting_person_id = e.id
			LEFT JOIN terms_condition AS terms ON po.terms_id = terms.id
			LEFT JOIN employee AS pe ON po.prepared_by_id = pe.id 
			INNER JOIN site_address AS sa ON sa.id = po.address_id
			INNER JOIN site ON sa.site_id = site.id
			INNER JOIN company on company.id = site.company_id
			INNER JOIN amended_po apo ON apo.against_po_id = po.id

			WHERE apo.id = po_idIn LIMIT 1 OFFSET 0; 
			
			
END