-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 22, 2017 at 06:22 PM
-- Server version: 5.5.54-0ubuntu0.14.04.1
-- PHP Version: 5.6.30-10+deb.sury.org~trusty+2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nkc`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `addcompany`(IN `nameIn` VARCHAR(255), IN `contactpersonnameIn` VARCHAR(100), IN `contactemailIn` VARCHAR(100), IN `contactphoneIn` VARCHAR(15), IN `addressIn` TEXT, IN `gstnoIn` VARCHAR(50), IN `panIn` VARCHAR(20), IN `regnoIn` VARCHAR(50), IN `subcriptionmodeIn` INT(10), IN `substartIn` VARCHAR(25), IN `subendIn` VARCHAR(25), IN `cinIn` VARCHAR(25))
    NO SQL
BEGIN 
DECLARE last_insert_id INT;
DECLARE ifexist INT;

SELECT count(id) INTO ifexist from company WHERE contact_person_email = contactemailIn;

IF (ifexist = 0 ) THEN

INSERT INTO company(name, contact_person_name, contact_person_email, contact_person_phone, address, gst_no, pan_no, reg_no, cin_no) VALUES
(nameIn, contactpersonnameIn, contactemailIn, contactphoneIn, addressIn, gstnoIn, panIn, regnoIn, cinIn);

SELECT MAX(id) INTO last_insert_id FROM company;

INSERT INTO company_subscription(company_id, subcription_mode, subscription_start_date, subscription_end_date) VALUES
(last_insert_id, subcriptionmodeIn, substartIn, subendIn);

INSERT INTO admin (password,company_id) VALUES (12345,last_insert_id);

SELECT MAX(id) as company_id from company;

ELSE

SELECT ifexist;

END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `addEmployee`(IN `departmentIDIN` BIGINT, IN `empNameIN` VARCHAR(255), IN `emailIDIN` VARCHAR(255), IN `empCodeIN` VARCHAR(255), IN `dojIN` VARCHAR(10), IN `dobIN` VARCHAR(10), IN `phoneIN` VARCHAR(20), IN `empModeIN` INT, IN `companyIDIN` BIGINT, IN `designationIDIN` INT, IN `passwordIn` VARCHAR(255) CHARSET utf8)
BEGIN
DECLARE employeeid int;
INSERT INTO employee(department_id,
                     employee_name,
                     email_id,
                     employee_code,
                     company_id,
                     doj,
                     dob,
                     phone_no,
                     employee_mode, password)VALUES(
					departmentIDIN,empNameIN,emailIDIN,empCodeIN,
    				companyIDIN,dojIN,dobIN,phoneIN,empModeIN, MD5(passwordIn));
SELECT LAST_INSERT_ID() into employeeid;

SELECT employeeid;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkRequisitionIssue`(IN `requisition_idIn` BIGINT(11))
    NO SQL
BEGIN

DECLARE department_id_tmp INT DEFAULT 0;

SELECT department_id INTO department_id_tmp FROM requisition WHERE id = 
requisition_idIn;

IF(department_id_tmp != 4) THEN

SELECT * FROM (
SELECT tmp.material_id,(tmp.quantity-IFNULL(issue.issued_quantity,0)) AS quantity FROM (SELECT r.id,
	   ri.material_id,
	   ri.quantity
FROM requisition r 
INNER JOIN requisition_items ri
ON r.id = ri.requisition_id WHERE r.id = requisition_idIn ) AS tmp
LEFT JOIN
(SELECT SUM(ssi.quantity_issued) AS issued_quantity,ssi.material_id FROM store_issue_slip sis INNER JOIN store_slip_items ssi ON sis.id = ssi.store_slip_id WHERE sis.requisition_id = requisition_idIn GROUP BY ssi.material_id) as issue ON tmp.material_id = issue.material_id ) AS tmpp WHERE tmpp.quantity > 0;

ELSE

SELECT * FROM 
(
	SELECT tmp.equipment_id,
			(tmp.quantity-IFNULL(issue.issued_quantity,0)) AS quantity 
	FROM 
		(SELECT r.id,
				ri.equipment_id,
				ri.quantity
			FROM requisition r 
			INNER JOIN requisition_items ri
			ON r.id = ri.requisition_id WHERE r.id = requisition_idIn ) AS tmp
	LEFT JOIN (SELECT 
				  SUM(sis.quantity_issued) AS issued_quantity,equipment_id FROM 
				  store_issue_slip sis WHERE sis.requisition_id = 
				  requisition_idIn GROUP BY sis.equipment_id) AS 
				  issue 
				  ON tmp.equipment_id = issue.equipment_id) AS tmpp 
				  WHERE tmpp.quantity > 0;
				  

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAllIndentForPrint`(IN `department_idIn` INT(1), IN `site_idIn` INT(11), IN `fromIn` VARCHAR(255), IN `toIn` VARCHAR(255), IN `indent_idIn` BIGINT)
    NO SQL
BEGIN 

SELECT 
	indent.id AS indent_id, 
	indent.requisition_id AS requisition_id, 
	indent.indent_no AS indent_no, 
	indent.status AS indent_status, 
	material.material_name, 
	material.part_no, 
	unit.unit_name, 
	equipments.asset_code, 
	indent_items.remarks, 
	date_format(indent.registered_on, '%d/%m/%Y') AS registered_on, 
	indent_items.quantity_requested, 
	indent_items.quantity_approved 
FROM 
indent LEFT JOIN indent_items ON indent.id = indent_items.indent_id 
LEFT JOIN requisition ON indent.requisition_id = requisition.id 
LEFT JOIN material ON indent_items.material_id = material.id 
LEFT JOIN equipments ON indent_items.equipment_id = equipments.id 
LEFT JOIN unit ON material.unit_id = unit.id 
WHERE 
	(indent_idIn=0 OR indent.id = indent_idIn) AND requisition.department_id = department_idIn AND requisition.site_id = site_idIn AND (fromIn = '' OR (fromIn <> '' AND DATE(indent.created_on) >= STR_TO_DATE(fromIn, '%e/%c/%Y'))) AND (toIn = '' OR (toIn <> '' AND DATE(indent.created_on) <= STR_TO_DATE(toIn, '%e/%c/%Y'))); 

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCivilData`(IN `requisition_idIn` INT(11), IN `material_nameIn` VARCHAR(255) CHARSET utf8)
    NO SQL
BEGIN

SELECT temp.id, temp.material_name, temp.unit_name AS unit_name, temp.product_code, (temp.quantity - qa) AS quantity FROM  (SELECT 
material.id AS id, material_name, unit.unit_name AS unit_name, product_code, requisition_items.quantity AS quantity  
FROM 
requisition 
LEFT JOIN requisition_items 
ON requisition.id = requisition_items.requisition_id 
LEFT JOIN material 
ON requisition_items.material_id = material.id 
LEFT JOIN indent ON requisition.id = indent.requisition_id AND indent.requisition_id =  requisition_idIn
LEFT JOIN unit 
ON material.unit_id = unit.id 
WHERE requisition.id = requisition_idIn AND material.material_name LIKE CONCAT('%',material_nameIn,'%') GROUP BY material.id) as temp INNER JOIN (SELECT indent.id AS indent_id,material_id,SUM(quantity_approved) AS qa FROM indent LEFT JOIN indent_items ON indent.id = indent_items.indent_id WHERE indent.requisition_id = requisition_idIn GROUP BY material_id) AS indent_temp ON temp.id = indent_temp.material_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCivilMaterialForASite`(IN `site_idIn` INT(11), IN `limitIn` INT(11), IN `offsetIn` INT(11), IN `nameIn` VARCHAR(255) CHARSET utf8, IN `type_idIn` INT(1))
    NO SQL
BEGIN SELECT material_name AS `material_name`, mg.name AS `material_group`, msg.name AS `material_sub_group`, (IF(tmpp.added_in_stock IS NULL,0,tmpp.added_in_stock) - IF(tmppp.issued_items IS NULL,0,tmppp.issued_items) + IF(tm.opening_stock IS NULL,0,tm.opening_stock )) AS quantity, rate AS `rate`, ROUND(site_material.quantity * rate,2) AS `value`, material.id AS `id` FROM material material left JOIN material_group mg ON material.material_group_id = mg.id left JOIN material_group msg ON material.material_sub_group_id = msg.id left JOIN unit unit ON material.unit_id = unit.id left JOIN site_material site_material ON material.id = site_material.material_id LEFT JOIN (SELECT material_id,SUM(IF(quantity IS NULL, 0, quantity)) AS added_in_stock FROM `material_stock` WHERE site_id = site_idIn AND type = 2 GROUP BY material_id) AS tmpp ON material.id = tmpp.material_id LEFT JOIN (SELECT material_id,SUM(IF(quantity IS NULL, 0, quantity)) AS issued_items FROM `material_stock` WHERE site_id = site_idIn AND type = 3 GROUP BY material_id) AS tmppp ON material.id = tmppp.material_id LEFT JOIN (SELECT material_id,SUM(IF(quantity IS NULL, 0, quantity)) AS opening_stock FROM `material_stock` WHERE site_id = site_idIn AND type = 1 GROUP BY material_id) AS tm ON material.id = tm.material_id WHERE (material_type_id = type_idIn AND site_material.site_id = site_idIn AND material.material_name LIKE CONCAT('%',nameIn, '%')) GROUP BY material.id LIMIT limitIn OFFSET offsetIn; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailsOfAIndent`(IN `indent_idIn` VARCHAR(255) CHARSET utf8)
BEGIN


SELECT i.id,
       i.requisition_id,
       r.department_id,
       r.site_id,
       i.registered_on,
       i.indent_no,
       i.requested_by_id,
       rbe.employee_name AS requested_by_name,
       i.verified_by_id,
       vbe.employee_name AS verified_by_name,
       i.approved_by_id,
       abe.employee_name AS approved_by_name,
       i.status,
       i.created_on,
       i.is_approved
FROM indent AS i
INNER JOIN requisition AS r ON i.requisition_id = r.id
LEFT JOIN employee AS rbe ON i.requested_by_id = rbe.id
LEFT JOIN employee AS vbe ON i.verified_by_id = vbe.id
LEFT JOIN employee AS abe ON i.approved_by_id = abe.id
WHERE FIND_IN_SET (i.id, indent_idIn);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailsOfAPurchaseOrder`(IN `po_idIn` BIGINT)
BEGIN 


		SELECT 
		po.id, 
		po.po_number, 
		po.exp_del_date,
		po.reg_date, 
		po.department_id,  
		terms.name as term_name,
		terms.content as content,
		s.id AS supplier_id, 
		s.name AS supplier_name, 
		s.address AS supplier_address, 
		s.gst_no AS supplier_gst_no,
		s.vendor_code as vendor_code,
		s.phone_no as phone_no,	
		po.reporting_person_id, 
		e.employee_name AS reporting_person_name, 
		e.phone_no AS reporting_person_phone_no, 
		po.address_id, 
		po.prepared_by_id, 
		pe.employee_name AS prepared_by_name, 
		po.created_on, 
		po.total_amount,
		po.freight,
		po.status,
		po.mode_of_dispatch,
		sa.delivery_address,
		site.billing_address,
		company.cin_no 
	FROM 
		purchase_orders AS po 
			LEFT JOIN purchase_order_items AS poi ON po.id = poi.po_id 
			LEFT JOIN indent AS i ON poi.indent_id = i.id 
			LEFT JOIN requisition AS r ON i.requisition_id = r.id 
			LEFT JOIN suppliers AS s ON po.supplier_id = s.id 
			LEFT JOIN employee AS e ON po.reporting_person_id = e.id
			LEFT JOIN terms_condition AS terms ON po.terms_id = terms.id
			LEFT JOIN employee AS pe ON po.prepared_by_id = pe.id 
			INNER JOIN site_address AS sa ON sa.id = po.address_id
			INNER JOIN site ON sa.site_id = site.id
			INNER JOIN company on company.id = site.company_id

			WHERE po.id = po_idIn LIMIT 1 OFFSET 0; 
			
			
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailsOfARequisition`(IN `requisition_idIn` BIGINT)
BEGIN

SELECT r.id,
       r.requisition_no,
       r.department_id,
       d.department_name,
       r.registered_on,
       r.issue_to_dep_id,
       r.issues_to_id,
       ie.employee_name AS issues_to_name,
       r.prepared_by_id,
       pe.employee_name AS prepared_by_name,
       r.approved_by_id,
       ae.employee_name AS approved_by_name,
       r.hod_id,
       he.employee_name AS hod_name,
       r.site_id,
       s.site_name,
       r.nature,
       r.created_on,
       r.status,
       r.is_approved
FROM requisition AS r
LEFT JOIN department AS d ON r.department_id = d.id
LEFT JOIN employee AS ie ON r.issues_to_id = ie.id
LEFT JOIN employee AS pe ON r.prepared_by_id = pe.id
LEFT JOIN employee AS ae ON r.approved_by_id = ae.id
LEFT JOIN employee AS he ON r.hod_id = he.id
LEFT JOIN site AS s ON r.site_id = s.id
WHERE r.id = requisition_idIn;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDieselslipById`(IN `idIn` INT(11))
    NO SQL
BEGIN


SELECT 
	issue.site_id,
	site.site_name,
	issue.date_on,
	issue.equipment_id,
	eq.asset_code,
	eq.reg_no,
	issue.last_reading,
	issue.current_reading,
	issue.quantity_issued, 
	issue.received_by_id, 
	emp.employee_name, 
	emp.phone_no 
FROM store_issue_slip issue
LEFT JOIN equipments eq
ON issue.equipment_id = eq.id 
LEFT JOIN site
ON issue.site_id = site.id
LEFT JOIN employee emp
ON issue.received_by_id = emp.id
WHERE issue.id = idIn;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIndentItems`(IN `indent_idIn` BIGINT)
BEGIN

DECLARE department INT;

SELECT department_id INTO department FROM indent INNER JOIN requisition ON indent.requisition_id = requisition.id WHERE indent.id = indent_idIn; 

IF(department = 4) THEN 

SELECT ii.id,
       ii.indent_id,
       ii.equipment_id,
       e.asset_code,
		e.reg_no,
       ii.quantity_requested,
       ii.quantity_approved,
       ii.previous_purchase_rate,
       ii.place_of_use,
       ii.remarks,
       ii.created_on
FROM indent AS i
INNER JOIN indent_items AS ii ON i.id = ii.indent_id
LEFT JOIN equipments AS e ON ii.equipment_id = e.id
WHERE i.id = indent_idIn;

ELSE

SELECT ii.id,
       ii.indent_id,
       ii.material_id,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no,
       ii.quantity_requested,
       ii.quantity_approved,
       ii.previous_purchase_rate,
       ii.place_of_use,
       ii.remarks,
       ii.created_on
FROM indent AS i
INNER JOIN indent_items AS ii ON i.id = ii.indent_id
LEFT JOIN material AS m ON ii.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON m.equipment_id = e.id
WHERE i.id = indent_idIn;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIndentItemsForPurchaseOrder`(IN `indent_idIn` VARCHAR(255) CHARSET utf8, IN `department_idIn` INT(11))
BEGIN

IF(department_idIn = 4) THEN

SELECT ii.id,
       ii.indent_id,
       ii.equipment_id,
       e.asset_code,
       e.reg_no AS specifications,
       (ii.quantity_approved) AS quantity_requested,
       ii.previous_purchase_rate,
       ii.place_of_use,
       ii.remarks,
       ii.created_on
FROM indent AS i
INNER JOIN indent_items AS ii ON i.id = ii.indent_id
LEFT JOIN equipments AS e ON ii.equipment_id = e.id
WHERE  FIND_IN_SET(i.id, indent_idIn)
AND quantity_requested > 0;

ELSE

SELECT ii.id,
       ii.indent_id,
       ii.material_id,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no,
       (ii.quantity_approved) AS quantity_requested,
       ii.previous_purchase_rate,
       ii.place_of_use,
       ii.remarks,
       ii.created_on
FROM indent AS i
INNER JOIN indent_items AS ii ON i.id = ii.indent_id
LEFT JOIN material AS m ON ii.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON ii.material_id = e.id
WHERE  FIND_IN_SET(i.id, indent_idIn)
AND quantity_requested > 0;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIndentItemsForPurchaseOrder_v1`(IN `indent_idIn` BIGINT)
BEGIN

SELECT ii.id,
       ii.indent_id,
       ii.material_id,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no,
       (ii.quantity_approved - SUM(IFNULL(poi.quantity, 0))) AS quantity_requested,
       ii.previous_purchase_rate,
       ii.place_of_use,
       ii.remarks,
       ii.created_on
FROM indent AS i
INNER JOIN indent_items AS ii ON i.id = ii.indent_id
LEFT JOIN material AS m ON ii.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON ii.material_id = e.id
LEFT JOIN purchase_orders AS po ON i.id = po.indent_id
LEFT JOIN purchase_order_items AS poi ON po.id = poi.po_id AND ii.material_id = poi.material_id
WHERE i.id = indent_idIn
GROUP BY ii.material_id
HAVING quantity_requested > 0;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIndentList`(IN `emp_idIn` BIGINT, IN `site_idIn` BIGINT, IN `department_idIn` BIGINT, IN `searchIn` VARCHAR(255), IN `limitIn` INT, IN `offsetIn` INT, IN `fromIn` VARCHAR(255), IN `toIn` VARCHAR(255))
BEGIN DECLARE total_tmp BIGINT DEFAULT 0; DECLARE total_indent_state INT DEFAULT 0; SELECT COUNT(id) INTO total_indent_state FROM indent_state_mapping; SELECT COUNT(DISTINCT i.id) INTO total_tmp FROM indent AS i INNER JOIN requisition AS r ON i.requisition_id = r.id INNER JOIN site AS s ON r.site_id = s.id INNER JOIN (SELECT t1.indent_id,t1.status,t1.id FROM indent_track t1 JOIN (SELECT indent_id,status, MAX(id) AS max_id_t2 FROM indent_track GROUP BY indent_id) t2 ON t1.indent_id = t2.indent_id AND t1.id = t2.max_id_t2) AS tmp ON i.id = tmp.indent_id INNER JOIN department AS d ON r.department_id = d.id AND (department_idIn = 0 OR (department_idIn <> 0 AND d.id = department_idIn)) INNER JOIN indent_current_state AS ics ON i.id = ics.indent_id INNER JOIN indent_state_mapping AS ism ON ics.state_id = ism.`state` INNER JOIN emp_role AS er ON er.empid = emp_idIn AND ((er.role_id = 7 AND ism.next_role_id = 0) OR (er.role_id <> 7 AND (er.role_id = ism.role_id OR er.role_id = ism.next_role_id))) WHERE i.indent_no LIKE CONCAT(searchIn, '%') AND r.status <> 3 AND (fromIn = '' OR (fromIn <> '' AND DATE(i.created_on) >= STR_TO_DATE(fromIn, '%e/%c/%Y'))) AND (toIn = '' OR (toIn <> '' AND DATE(i.created_on) <= STR_TO_DATE(toIn, '%e/%c/%Y'))) AND (site_idIn = 0 OR (site_idIn <> 0 AND r.site_id = site_idIn)); SELECT total_tmp AS total, tmpp.indent_id, tmpp.indent_no, tmpp.save_to_draft, tmpp.indent_status, tmpp.is_approve, tmpp.site_name, tmpp.department, tmpp.requisition_no, tmpp.approved, IF(COUNT(ics1.id) - total_indent_state = 0,1,0) AS fully_approved, tmpp.requested_by_id, tmpp.last_status FROM (SELECT total_tmp AS total, i.id AS indent_id, i.indent_no, i.save_to_draft, i.status AS indent_status, IF(i.is_approved = 1,"Yes", "No") AS is_approve, s.site_name, d.department_name AS department, r.requisition_no, i.is_approved AS approved, i.requested_by_id, tmp.status AS last_status FROM indent AS i INNER JOIN requisition AS r ON i.requisition_id = r.id INNER JOIN site AS s ON r.site_id = s.id INNER JOIN (SELECT t1.indent_id,t1.status,t1.id FROM indent_track t1 JOIN (SELECT indent_id,status, MAX(id) AS max_id_t2 FROM indent_track GROUP BY indent_id) t2 ON t1.indent_id = t2.indent_id AND t1.id = t2.max_id_t2) AS tmp ON i.id = tmp.indent_id INNER JOIN department AS d ON r.department_id = d.id AND (department_idIn = 0 OR (department_idIn <> 0 AND d.id = department_idIn)) INNER JOIN indent_current_state AS ics ON i.id = ics.indent_id INNER JOIN indent_state_mapping AS ism ON ics.state_id = ism.`state` INNER JOIN emp_role AS er ON er.empid = emp_idIn AND ((er.role_id = 7 AND ism.next_role_id = 0) OR (er.role_id <> 7 AND (er.role_id = ism.role_id OR er.role_id = ism.next_role_id))) WHERE i.indent_no LIKE CONCAT(searchIn, '%') AND r.status <> 3 AND (fromIn = '' OR (fromIn <> '' AND DATE(i.created_on) >= STR_TO_DATE(fromIn, '%e/%c/%Y'))) AND (toIn = '' OR (toIn <> '' AND DATE(i.created_on) <= STR_TO_DATE(toIn, '%e/%c/%Y'))) AND (site_idIn = 0 OR (site_idIn <> 0 AND r.site_id = site_idIn)) GROUP BY i.id ORDER BY i.id DESC LIMIT offsetIn, limitIn) AS tmpp INNER JOIN indent_current_state ics1 ON tmpp.indent_id = ics1.indent_id GROUP BY ics1.indent_id ORDER BY tmpp.indent_id DESC; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIssueSlipDetails`(IN `issue_slip_idIn` BIGINT, IN `issue_slip_typeIn` BIGINT)
BEGIN

IF (issue_slip_typeIn = 2) THEN

SELECT sis.id,
       sis.site_id,
       s.site_name,
       sis.serial_no,
       IF(nature.name IS NULL,'',nature.name) AS nature_name,
       DATE(sis.date_on) AS date_on,
       e.asset_code,
       sis.last_reading,
       e.reg_no AS vehicle_reg_no,
       sis.current_reading,
       sis.quantity_issued,
       emp.employee_name AS receiver_name,
       emp.phone_no AS receiver_phone
FROM store_issue_slip AS sis
LEFT JOIN site AS s ON sis.site_id = s.id
LEFT JOIN equipments AS e ON sis.equipment_id = e.id
LEFT JOIN employee AS emp ON sis.received_by_id = emp.id 
LEFT JOIN nature ON sis.nature_id = nature.id 
WHERE sis.id = issue_slip_idIn;

ELSE

SELECT sis.id,
       sis.site_id,
       s.site_name,
       sis.serial_no,
       DATE(sis.date_on) AS date_on,
       sis.purpose,
       IF(nature.name IS NULL,'',nature.name) AS nature_name,
       remp.employee_name AS requisition_prepared_by_name,
       rb.employee_name AS receiver_name,
       it.employee_name AS issued_to_name,
       ab.employee_name AS authorised_by_name,
       si.employee_name AS store_incharge_name
FROM store_issue_slip AS sis
LEFT JOIN site AS s ON sis.site_id = s.id
LEFT JOIN requisition AS r ON sis.requisition_id = r.id
LEFT JOIN employee AS remp ON r.prepared_by_id = remp.id
LEFT JOIN employee AS rb ON sis.received_by_id = rb.id
LEFT JOIN employee AS it ON sis.issue_to_id = it.id
LEFT JOIN employee AS ab ON sis.authorised_by_id = ab.id
LEFT JOIN employee AS si ON sis.store_incharge_id = si.id
LEFT JOIN nature ON sis.nature_id = nature.id 
WHERE sis.id = issue_slip_idIn;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIssueSlipItems`(IN `issue_slip_idIn` BIGINT)
BEGIN

SELECT IFNULL(m.material_name, IFNULL(m.part_no, e.name)) AS description_of_goods,
       u.unit_name,
       m.product_code,
       ri.quantity,
       ssi.quantity_issued,
       ssi.remarks
FROM store_issue_slip AS sis
INNER JOIN store_slip_items AS ssi ON sis.id = ssi.store_slip_id
LEFT JOIN material AS m ON ssi.material_id = m.id
LEFT JOIN equipments AS e ON ssi.equipment_id = e.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN requisition AS r ON sis.requisition_id = r.id
LEFT JOIN requisition_items AS ri ON r.id = ri.requisition_id AND (m.id = ri.material_id OR e.id = ri.equipment_id)
WHERE sis.id = issue_slip_idIn
GROUP BY ssi.id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getIssueSlipsForPrintPreview`(IN `site_idIn` BIGINT)
BEGIN

SELECT sis.serial_no,
       IFNULL(m.material_name, IFNULL(m.part_no,e.name)) AS description_of_goods,
       it.employee_name AS issued_to_name,
       u.unit_name,
       ssi.quantity_required,
       ssi.quantity_issued,
       ssi.rate,
       ssi.amount,
       n.name AS nature,
       ssi.remarks
FROM store_issue_slip AS sis
INNER JOIN store_slip_items AS ssi ON sis.id = ssi.store_slip_id
LEFT JOIN material AS m ON ssi.material_id = m.id
LEFT JOIN equipments AS e ON ssi.equipment_id = e.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN requisition AS r ON sis.requisition_id = r.id
LEFT JOIN requisition_items AS ri ON r.id = ri.requisition_id AND (m.id = ri.material_id OR e.id = ri.equipment_id)
LEFT JOIN employee AS it ON sis.issue_to_id = it.id
LEFT JOIN nature AS n ON sis.nature_id = n.id
WHERE sis.site_id = site_idIn
GROUP BY ssi.id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMaterialData`(IN `requisition_idIn` INT(11), IN `asset_codeIn` VARCHAR(255) CHARSET utf8)
    NO SQL
BEGIN

SELECT temp.id, temp.name, temp.asset_code,temp.specifications,temp.descriptions,temp.part_no, (temp.quantity - qa) AS quantity FROM  (SELECT 
material.id AS id, name,asset_code,material.specifications, material.descriptions, part_no, requisition_items.quantity AS quantity 
FROM 
requisition 
LEFT JOIN requisition_items 
ON requisition.id = requisition_items.requisition_id 
LEFT JOIN material 
ON requisition_items.material_id = material.id 
LEFT JOIN equipments ON equipments.id = material.equipment_id 
LEFT JOIN indent ON requisition.id = indent.requisition_id AND indent.requisition_id =  requisition_idIn
WHERE requisition.id = requisition_idIn AND equipments.asset_code LIKE CONCAT('%',asset_codeIn, '%') GROUP BY material.id) as temp INNER JOIN (SELECT indent.id AS indent_id,material_id,SUM(quantity_approved) AS qa FROM indent LEFT JOIN indent_items ON indent.id = indent_items.indent_id WHERE indent.requisition_id = requisition_idIn GROUP BY material_id) AS indent_temp ON temp.id = indent_temp.material_id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMaterialReceipt`(IN `receipt_idIn` INT(11))
    NO SQL
BEGIN

DECLARE departmentId INT;
SELECT department_id INTO departmentId FROM material_receipt INNER JOIN purchase_orders ON material_receipt.po_id = purchase_orders.id WHERE material_receipt.id = receipt_idIn;

IF(departmentId != 4) THEN

SELECT 
	departmentId AS department,
	site.id AS site_id,
	site.site_name AS site_name,
	suppliers.id AS supplier_id,
	suppliers.name AS supplier_name,
	suppliers.address AS address,
	mrn_no,
	mrn_date,
	bill_number,
	bill_date,
	truck_no,
	transport_no,
	purchase_orders.id AS po_id,
	purchase_orders.po_number AS po_number,
	purchase_orders.reg_date AS po_date,
	purchase_order_items.quantity AS requested_quantity,
	IFNULL(material.material_name, material.part_no) AS material_name,
	material.id AS material_id,
	unit.unit_name,
	requested_store_keeper_id AS store_keeper,
	received_store_incharge_id AS store_incharge,
	emp1.employee_name AS store_keeper_name,
	emp2.employee_name AS store_incharge_name,
	material_receipt_items.received_quantity,
	material_receipt_items.accepted_quantity,
	material_receipt_items.price,
	material_receipt_items.remarks
	
FROM material_receipt 
INNER JOIN material_receipt_items 
ON material_receipt.id = material_receipt_items.material_receipt_id 
INNER JOIN site 
ON material_receipt.site_id = site.id
INNER JOIN suppliers 
ON material_receipt.supplier_id = suppliers.id 
INNER JOIN purchase_orders ON material_receipt.po_id = purchase_orders.id 
INNER JOIN purchase_order_items ON purchase_orders.id = purchase_order_items.po_id AND material_receipt_items.material_id = purchase_order_items.material_id
INNER JOIN material ON material_receipt_items.material_id = material.id 
LEFT JOIN unit ON material.unit_id = unit.id 
LEFT JOIN employee emp1 ON material_receipt.requested_store_keeper_id = emp1.id
LEFT JOIN employee emp2 ON material_receipt.received_store_incharge_id = emp2.id
WHERE material_receipt.id = receipt_idIn
GROUP BY purchase_order_items.id;

ELSE

SELECT 
	departmentId AS department,
	site.id AS site_id,
	site.site_name AS site_name,
	suppliers.id AS supplier_id,
	suppliers.name AS supplier_name,
	suppliers.address AS address,
	mrn_no,
	mrn_date,
	bill_number,
	bill_date,
	truck_no,
	transport_no,
	material_receipt_items.equipment_id,
	e.asset_code,
	e.reg_no,
	purchase_orders.id AS po_id,
	purchase_orders.po_number AS po_number,
	purchase_orders.reg_date AS po_date,
	purchase_order_items.quantity AS requested_quantity,
	requested_store_keeper_id AS store_keeper,
	received_store_incharge_id AS store_incharge,
	emp1.employee_name AS store_keeper_name,
	emp2.employee_name AS store_incharge_name,
	material_receipt_items.received_quantity,
	material_receipt_items.accepted_quantity,
	material_receipt_items.price,
	material_receipt_items.remarks
	
FROM material_receipt 
INNER JOIN material_receipt_items 
ON material_receipt.id = material_receipt_items.material_receipt_id 
INNER JOIN site 
ON material_receipt.site_id = site.id
INNER JOIN suppliers 
ON material_receipt.supplier_id = suppliers.id 
INNER JOIN purchase_orders ON material_receipt.po_id = purchase_orders.id 
INNER JOIN purchase_order_items ON purchase_orders.id = purchase_order_items.po_id AND material_receipt_items.equipment_id = purchase_order_items.equipment_id
INNER JOIN equipments e ON material_receipt_items.equipment_id = e.id 
LEFT JOIN employee emp1 ON material_receipt.requested_store_keeper_id = emp1.id
LEFT JOIN employee emp2 ON material_receipt.received_store_incharge_id = emp2.id
WHERE material_receipt.id = receipt_idIn;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMRNDataForPDF`(IN `mrn_idIn` INT(11))
    NO SQL
BEGIN

DECLARE store_address TEXT;

SELECT site_address.delivery_address INTO store_address FROM site_address INNER 
JOIN purchase_orders ON purchase_orders.address_id = site_address.id 
WHERE purchase_orders.id = (SELECT po_id FROM material_receipt WHERE 
id = mrn_idIn); 


SELECT
		
		store_address,
		m.material_name,
		m.part_no,
		e1.employee_name AS store_keeper,
		e2.employee_name AS store_incharge,
		mr.site_id,
		mr.serial_no,
		e.asset_code,
		s.name,
		mr.created_on, 
		mr.transport_no,
		mr.truck_no,
		u.unit_name,
		mr.mrn_no,
		mr.mrn_date,
		mri.price,
		mri.received_quantity AS received_quantity,
		mri.accepted_quantity,
		(mri.accepted_quantity *mri.price) - (((mri.accepted_quantity 
		*mri.price)*mri.discount)/100) + (((mri.accepted_quantity 
		*mri.price)*mri.gst)/100) AS mrn_value,
		mr.bill_number,
		mr.freight,
		mr.bill_date,
		mri.remarks
FROM 
	material_receipt mr 
LEFT JOIN material_receipt_items mri ON mr.id = mri.material_receipt_id
LEFT JOIN material m ON mri.material_id = m.id
LEFT JOIN unit u ON m.unit_id = u.id
LEFT JOIN equipments e ON mri.equipment_id = e.id
LEFT JOIN suppliers s ON mr.supplier_id = s.id
LEFT JOIN employee e1 ON mr.requested_store_keeper_id = e1.id 
LEFT JOIN employee e2 ON mr.received_store_incharge_id = e2.id 
WHERE mr.id = mrn_idIn;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMRNPreview`(IN `site_idIn` INT(11), IN `fromIn` VARCHAR(255) CHARSET utf8, IN `toIn` VARCHAR(255) CHARSET utf8)
    NO SQL
BEGIN

SELECT
		m.material_name,
		m.part_no,
		e.asset_code,
		s.name,
		date_format(mr.created_on, '%d/%m/%Y') AS created_on, 
		mr.transport_no,
		mr.truck_no,
		u.unit_name,
		po.po_number,
		po.reg_date,
		poi.quantity AS po_quantity,
		(poi.quantity * poi.rate) - (((poi.quantity * 
		poi.rate)*poi.discount)/100) + (((poi.quantity 
		* poi.rate)*poi.gst)/100) AS po_value,
		mr.mrn_no,
		mr.mrn_date,
		mri.accepted_quantity AS mrn_quantity,
		(mri.accepted_quantity *mri.price) - (((mri.accepted_quantity 
		*mri.price)*mri.discount)/100) + (((mri.accepted_quantity 
		*mri.price)*mri.gst)/100) AS mrn_value,
		mr.bill_number,
		mr.bill_date,
		mr.freight,
		mri.accepted_quantity AS bill_quantity,
		(mri.accepted_quantity *mri.price) - (((mri.accepted_quantity 
		*mri.price)*mri.discount)/100) + (((mri.accepted_quantity 
		*mri.price)*mri.gst)/100) AS bill_value,
		mri.remarks
FROM 
	material_receipt mr
LEFT JOIN material_receipt_items mri ON mr.id = mri.material_receipt_id
LEFT JOIN purchase_orders po ON mr.po_id = po.id 
LEFT JOIN purchase_order_items poi ON mr.po_id = poi.po_id AND 
mri.material_id = poi.material_id
LEFT JOIN material m ON mri.material_id = m.id
LEFT JOIN unit u ON m.unit_id = u.id
LEFT JOIN equipments e ON mri.equipment_id = e.id
LEFT JOIN suppliers s ON mr.supplier_id = s.id
WHERE mr.site_id = site_idIn AND (fromIn = '' OR (fromIn<>'' AND 
DATE(mr.created_on) >= fromIn)) AND (toIn = '' OR (toIn<>'' AND 
DATE(mr.created_on) <= toIn));

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPOItemsForMrn`(IN `po_idIn` BIGINT, IN `department_idIn` INT(1))
    NO SQL
BEGIN
IF(department_idIn != 4) THEN
SELECT
		tmp.po_id AS po_id,
		tmp.freight,
		tmp.material_id,
		tmp.department_id,
		tmp.quantity,
		tmp.part_no,
		tmp.rate AS rate,
		(tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) AS left_quantity,
		((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) AS total_rate,
		((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) + ((((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) * tmp.gst)/100) - ((((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) * tmp.discount)/100) AS value,
		tmp.gst,
		tmp.discount,
		tmp.material_name,
		tmp.unit_name FROM
(SELECT 
		po.id AS po_id,
		po.freight,
		po.department_id,
		pot.material_id,
		pot.quantity,
		pot.rate,
		((pot.amount-((pot.amount * pot.discount)/100) ) + (((pot.amount-((pot.amount * pot.discount)/100))*pot.gst)/100)) as value,
		 pot.discount,
		 pot.gst,
		 IF(material.material_name IS NULL, material.part_no,
		 material.material_name) AS material_name,
		 material.part_no,
		 IFNULL(unit.unit_name,'') AS unit_name 
FROM 
	purchase_orders po 
	INNER JOIN 
	purchase_order_items pot 
	ON po.id = pot.po_id 
	INNER JOIN 
	material ON pot.material_id = material.id 
	LEFT JOIN unit ON material.unit_id = unit.id 
	LEFT JOIN equipments ON material.equipment_id = equipments.id 
	WHERE po.id = po_idIn) AS tmp
LEFT JOIN 
(
	SELECT 
		mr.po_id AS po_id,
		mri.material_id,
		mri.equipment_id,
		SUM(IFNULL(mri.accepted_quantity,0)) AS accepted_quantity
FROM 
	material_receipt mr 
	INNER JOIN 
	material_receipt_items mri 
	ON mr.id = mri.material_receipt_id 
	WHERE mr.po_id = po_idIn GROUP BY material_id) AS tmpp
	ON tmp.material_id = tmpp.material_id WHERE (tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) > 0;

ELSE 

SELECT
		tmp.po_id AS po_id,
		tmp.freight,
		tmp.equipment_id,
		tmp.department_id,
		tmp.quantity,
		tmp.rate AS rate,
		(tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) AS left_quantity,
		((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) AS total_rate,
		((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) + ((((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) * tmp.gst)/100) - ((((tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) * tmp.rate) * tmp.discount)/100) AS value,
		tmp.gst,
		tmp.discount,
		tmp.material_name,
		tmp.unit_name FROM
(SELECT 
		po.id AS po_id,
		po.freight,
		po.department_id,
		pot.equipment_id,
		pot.quantity,
		pot.rate,
		((pot.amount-((pot.amount * pot.discount)/100) ) + (((pot.amount-((pot.amount * pot.discount)/100))*pot.gst)/100)) as value,
		 pot.discount,
		 pot.gst,
		 equipments.asset_code AS material_name,
		 IFNULL(unit.unit_name,'') AS unit_name 
FROM 
	purchase_orders po 
	INNER JOIN 
	purchase_order_items pot 
	ON po.id = pot.po_id 
	LEFT JOIN 
	material ON pot.material_id = material.id 
	LEFT JOIN unit ON material.unit_id = unit.id 
	LEFT JOIN equipments ON pot.equipment_id = equipments.id 
	WHERE po.id = po_idIn) AS tmp
LEFT JOIN 
(
	SELECT 
		mr.po_id AS po_id,
		mri.equipment_id,
		SUM(IFNULL(mri.accepted_quantity,0)) AS accepted_quantity
FROM 
	material_receipt mr 
	INNER JOIN 
	material_receipt_items mri 
	ON mr.id = mri.material_receipt_id 
	WHERE mr.po_id = po_idIn GROUP BY equipment_id) AS tmpp
	ON tmp.equipment_id = tmpp.equipment_id WHERE (tmp.quantity - IFNULL(tmpp.accepted_quantity,0)) > 0;


END IF;



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPOList`(IN `emp_idIn` BIGINT, IN `searchIn` VARCHAR(255), IN `limitIn` INT, IN `offsetIn` INT, IN `departmentIDIN` INT, IN `po_typeIn` INT(1))
BEGIN

DECLARE total_tmp BIGINT DEFAULT 0;

DECLARE total_amended_tmp BIGINT DEFAULT 0;

DECLARE total BIGINT DEFAULT 0;

IF(po_typeIn = 0) THEN

if(departmentIDIN != 0) THEN

SELECT COUNT(DISTINCT po.id) INTO total_tmp
FROM purchase_orders AS po
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE po.po_number LIKE CONCAT(searchIn, '%')
  AND po.department_id = departmentIDIN;


SELECT COUNT(DISTINCT ampo.id) INTO total_amended_tmp
FROM amended_po ampo
LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%')
  AND ampo.department_id = departmentIDIN;


SET total = total_amended_tmp + total_tmp;


SELECT *
FROM
  ((SELECT total,
          po.id AS id,
          po.po_number AS po_number,
          po.reg_date AS reg_date,
          sp.name AS supplier_name,
          po.status AS status,
          tmp.status AS last_status,
          po.created_on AS created_on,
          0 as is_amended
   FROM purchase_orders AS po
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE po.po_number LIKE CONCAT(searchIn, '%')
     AND po.department_id = departmentIDIN
   GROUP BY po.id )
UNION ALL
  (SELECT total,
          ampo.id AS id,
          ampo.new_po_nubmer AS po_number,
          ampo.created_on AS reg_date,
          sp.name AS supplier_name,
          ampo.status AS status,
          tmp.status AS last_status,
          ampo.created_on AS created_on,
          1 as is_amended
   FROM amended_po ampo
   LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
   LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%')
     AND ampo.department_id = departmentIDIN
   GROUP BY ampo.id )) AS total_po
ORDER BY total_po.created_on DESC 
LIMIT offsetIn,
      limitIn;

ELSE

SELECT COUNT(DISTINCT po.id) INTO total_tmp
FROM purchase_orders AS po
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE po.po_number LIKE CONCAT(searchIn, '%') ;


SELECT COUNT(DISTINCT ampo.id) INTO total_amended_tmp
FROM amended_po ampo
LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%');


SET total = total_amended_tmp + total_tmp;


SELECT *
FROM
  ((SELECT total AS total,
          po.id,
          po.po_number,
          po.reg_date,
          sp.name AS supplier_name,
          po.status,
          tmp.status AS last_status,
          po.created_on,
          0 as is_amended
   FROM purchase_orders AS po
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE po.po_number LIKE CONCAT(searchIn, '%')
   GROUP BY po.id)
UNION ALL
  (SELECT total,
          ampo.id AS id,
          ampo.new_po_nubmer AS po_number,
          ampo.created_on AS reg_date,
          sp.name AS supplier_name,
          ampo.status AS status,
          tmp.status AS last_status,
          ampo.created_on AS created_on,
          1 as is_amended 
   FROM amended_po ampo
   LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
   LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%')
   GROUP BY ampo.id )) AS total_po
ORDER BY total_po.created_on  DESC
LIMIT offsetIn,
      limitIn;

END IF;

ELSEIF (po_typeIn = 1) THEN

if(departmentIDIN != 0) THEN

SELECT COUNT(DISTINCT po.id) INTO total_tmp
FROM purchase_orders AS po
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE po.po_number LIKE CONCAT(searchIn, '%')
  AND po.department_id = departmentIDIN;


SET total = total_amended_tmp + total_tmp;


SELECT *
FROM
  (SELECT total,
          po.id AS id,
          po.po_number AS po_number,
          po.reg_date AS reg_date,
          sp.name AS supplier_name,
          po.status AS status,
          tmp.status AS last_status,
          po.created_on AS created_on,
          0 as is_amended
   FROM purchase_orders AS po
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE po.po_number LIKE CONCAT(searchIn, '%')
     AND po.department_id = departmentIDIN
   GROUP BY po.id ) AS total_po
ORDER BY total_po.created_on DESC
LIMIT offsetIn,
      limitIn;

ELSE

SELECT COUNT(DISTINCT po.id) INTO total_tmp
FROM purchase_orders AS po
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE po.po_number LIKE CONCAT(searchIn, '%') ;


SET total = total_amended_tmp + total_tmp;


SELECT *
FROM
  (SELECT total AS total,
          po.id,
          po.po_number,
          po.reg_date,
          sp.name AS supplier_name,
          po.status,
          tmp.status AS last_status,
          po.created_on,
          0 as is_amended
   FROM purchase_orders AS po
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON po.id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE po.po_number LIKE CONCAT(searchIn, '%')
   GROUP BY po.id) AS total_po
ORDER BY total_po.created_on DESC 
LIMIT offsetIn,
      limitIn;
      
END IF;

ELSEIF (po_typeIn = 2) THEN

if(departmentIDIN != 0) THEN

SELECT COUNT(DISTINCT ampo.id) INTO total_amended_tmp
FROM amended_po ampo
LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%')
  AND ampo.department_id = departmentIDIN;


SET total = total_amended_tmp + total_tmp;


SELECT *
FROM
  (SELECT total,
          ampo.id AS id,
          ampo.new_po_nubmer AS po_number,
          ampo.created_on AS reg_date,
          sp.name AS supplier_name,
          ampo.status AS status,
          tmp.status AS last_status,
          ampo.created_on AS created_on,
          1 as is_amended
   FROM amended_po ampo
   LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
   LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%')
     AND ampo.department_id = departmentIDIN
   GROUP BY ampo.id ) AS total_po
ORDER BY total_po.created_on DESC 
LIMIT offsetIn,
      limitIn;

ELSE

SELECT COUNT(DISTINCT ampo.id) INTO total_amended_tmp
FROM amended_po ampo
LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
INNER JOIN
  (SELECT t1.po_id,
          t1.status,
          t1.id
   FROM po_track t1
   JOIN
     (SELECT po_id,
             status,
             MAX(id) AS max_id_t2
      FROM po_track
      GROUP BY po_id) t2 ON t1.po_id = t2.po_id
   AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12,
                     13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12,
                            13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%');


SET total = total_amended_tmp + total_tmp;


SELECT *
FROM
  (SELECT total,
          ampo.id AS id,
          ampo.new_po_nubmer AS po_number,
          ampo.created_on AS reg_date,
          sp.name AS supplier_name,
          ampo.status AS status,
          tmp.status AS last_status,
          ampo.created_on AS created_on,
          1 as is_amended
   FROM amended_po ampo
   LEFT JOIN amended_po_items ampoi ON ampo.id = ampoi.amended_po_id
   LEFT JOIN purchase_orders AS po ON ampo.against_po_id = po.id
   INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
   INNER JOIN po_current_state AS pocs ON ampo.against_po_id = pocs.po_id
   INNER JOIN
     (SELECT t1.po_id,
             t1.status,
             t1.id
      FROM po_track t1
      JOIN
        (SELECT po_id,
                status,
                MAX(id) AS max_id_t2
         FROM po_track
         GROUP BY po_id) t2 ON t1.po_id = t2.po_id
      AND t1.id = t2.max_id_t2) AS tmp ON ampo.against_po_id = tmp.po_id
   INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
   INNER JOIN emp_role AS er ON er.empid = emp_idIn
   AND ((er.role_id IN (12,
                        13)
         AND posm.next_role_id = 0)
        OR (er.role_id NOT IN (12,
                               13)
            AND (er.role_id = posm.role_id
                 OR er.role_id = posm.next_role_id)))
   WHERE ampo.new_po_nubmer LIKE CONCAT(searchIn, '%')
   GROUP BY ampo.id ) AS total_po
ORDER BY total_po.created_on DESC
LIMIT offsetIn,
      limitIn;

END IF;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPurchaseOrderItems`(IN `po_idIn` BIGINT, IN `department_idIn` INT(11))
BEGIN

IF(department_idIn = 4) THEN

SELECT tmp.*,indent_items.quantity_requested AS requested_quantity FROM(
SELECT poi.id,
	   poi.indent_id,
       poi.po_id,
       poi.equipment_id,
       poi.quantity,
       poi.rate,
       poi.gst,
       poi.discount,
       po.freight,
       po.total_amount,
       poi.amount,
       e.asset_code,
		e.reg_no
       
FROM purchase_order_items AS poi
LEFT JOIN purchase_orders AS po ON poi.po_id = po.id
LEFT JOIN indent_items AS ii ON poi.indent_id = ii.indent_id
LEFT JOIN equipments AS e ON poi.equipment_id = e.id 

WHERE poi.po_id = po_idIn
GROUP BY poi.id ) AS tmp 
LEFT JOIN indent_items  ON indent_items.indent_id = 
tmp.indent_id AND tmp.equipment_id = indent_items.equipment_id WHERE 
indent_items.indent_id = tmp.indent_id ;

ELSE

SELECT tmp.*,indent_items.quantity_requested AS requested_quantity FROM(
SELECT poi.id,
	   poi.indent_id,
       poi.po_id,
       poi.material_id,
       poi.quantity,
       poi.rate,
       poi.gst,
       poi.discount,
       po.freight,
       po.total_amount,
       poi.amount,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no
       
FROM purchase_order_items AS poi
LEFT JOIN purchase_orders AS po ON poi.po_id = po.id
LEFT JOIN indent_items AS ii ON poi.indent_id = ii.indent_id
LEFT JOIN material AS m ON poi.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON ii.material_id = e.id 

WHERE poi.po_id = po_idIn
GROUP BY poi.id ) AS tmp 
LEFT JOIN indent_items  ON indent_items.indent_id = 
tmp.indent_id AND tmp.material_id = indent_items.material_id WHERE 
indent_items.indent_id = tmp.indent_id ;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPurchaseOrderItems_v1`(IN `po_idIn` BIGINT)
BEGIN

SELECT poi.id,
       poi.po_id,
       poi.material_id,
       poi.quantity,
       poi.rate,
       poi.gst,
       poi.amount,
       poi.freight,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no,
       (ii.quantity_approved + poi.quantity - SUM(IFNULL(poi_tmp.quantity, 0))) AS requested_quantity
FROM purchase_order_items AS poi
LEFT JOIN purchase_orders AS po ON poi.po_id = po.id
LEFT JOIN indent_items AS ii ON po.indent_id = ii.indent_id
LEFT JOIN material AS m ON ii.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON ii.material_id = e.id
LEFT JOIN purchase_orders AS po_tmp ON po_tmp.indent_id = po.indent_id
LEFT JOIN purchase_order_items AS poi_tmp ON po_tmp.id = poi_tmp.po_id AND ii.material_id = poi_tmp.material_id
WHERE poi.po_id = po_idIn
GROUP BY poi.id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPurchaseOrdersForPrintPreview`(IN `site_idIn` BIGINT, IN `department_idIn` INT)
BEGIN

SELECT po.po_number,
       po.reg_date AS po_reg_date,
       poi.quantity AS po_quantity,
       poi.amount AS po_value,
       IF(m.material_name IS NULL AND m.part_no IS NULL, e.asset_code, IF(m.material_name IS NULL AND e.asset_code IS NULL, m.part_no,  m.material_name)) AS description_of_goods,
       i.indent_no,
       DATE(i.registered_on) AS indent_reg_date,
       ii.quantity_approved AS indent_quantity,
       po.exp_del_date,
       ii.remarks
FROM purchase_orders AS po
INNER JOIN purchase_order_items AS poi ON po.id = poi.po_id
LEFT JOIN material AS m ON poi.material_id = m.id
LEFT JOIN equipments AS e ON poi.equipment_id = e.id
INNER JOIN indent AS i ON poi.indent_id = i.id
INNER JOIN indent_items AS ii ON i.id = ii.indent_id
INNER JOIN requisition AS r ON i.requisition_id = r.id AND r.site_id = site_idIn
WHERE po.department_id = department_idIn
GROUP BY poi.id
ORDER BY poi.id DESC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getRequisitionData`(IN `requisition_idIn` INT(11))
    NO SQL
BEGIN

SELECT * FROM (
SELECT 
	material.material_name,
	requisition_data.material_id,
	material.product_code, 
	material.descriptions,
	material.specifications,
	material.part_no,
	(requisition_data.quantity - (IF(indent_data.approved_quantity IS NULL,0,indent_data.approved_quantity))) AS quantity, 
	equipments.name AS equipment_name, 
	equipments.id AS equipment_id, 
	equipments.asset_code AS asset_code ,
	unit.unit_name AS unit_name
FROM 
	(SELECT 
		requisition_items.material_id,
		IF(requisition_items.quantity IS NULL, 0, requisition_items.quantity) AS quantity 
	 FROM requisition 
	 LEFT JOIN 
	 requisition_items ON requisition.id = requisition_items.requisition_id 
	 WHERE requisition.id = requisition_idIn) AS requisition_data 
LEFT JOIN
	(SELECT 
		indent_items.material_id,
		SUM(IF(indent_items.quantity_approved IS NULL, 0, indent_items.quantity_approved)) AS approved_quantity 
	 FROM indent 
	 LEFT JOIN 
	 indent_items ON indent.id = indent_items.indent_id 
	 WHERE indent.requisition_id = requisition_idIn GROUP BY indent_items.material_id) AS indent_data
ON requisition_data.material_id = indent_data.material_id 
LEFT JOIN 
material ON requisition_data.material_id = material.id 
LEFT JOIN 
equipments ON material.equipment_id = equipments.id
LEFT JOIN 
unit ON material.unit_id = unit.id) AS tmp 
WHERE tmp.quantity > 0;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getRequisitionItems`(IN `requisition_idIn` BIGINT)
BEGIN

DECLARE siteId INT;
DECLARE departmentId INT;

SELECT site_id INTO siteId FROM requisition WHERE id = requisition_idIn;
SELECT department_id INTO departmentId FROM requisition WHERE id = requisition_idIn;
IF(departmentId = 4) THEN 

	SELECT 
	tmp.id,
		   tmp.requisition_id,
		   tmp.equipment_id,
		   tmp.current_reading,
		   tmp.last_reading,
		   tmp.asset_code,
		   tmp.quantity,
		   tmp.reg_no,
		   tmp.purpose,
		   tmp.remarks,
		   tmp.created_on,
		   tmp.is_issued,
		   IFNULL(issue_table.issue_quantity,0) AS issued_quantity,
		   tmp.status,
		   (IF(tmpp.added_in_stock IS NULL,0,tmpp.added_in_stock) - IF(tmppp.issued_items IS NULL,0,tmppp.issued_items) + IF(tm.opening_stock IS NULL,0,tm.opening_stock )) AS in_stock,
		   null AS previous_purchase_rate,
		   IF(employee_id IS NULL, contractor_id, employee_id) AS 
		   issuer_id,
		   IF(employee_name IS NULL, contractor_name, employee_name) AS 
		   issuer_name,
		   issue_type,
		   store_name,
		   store_id  
		   FROM 
	(SELECT ri.id,
			r.site_id,
			r.status,
			r.is_issued,
		   ri.requisition_id,
		   ri.equipment_id,
		   ri.current_reading,
     		ri.last_reading,
		   e.asset_code,
     	   e.reg_no,
		   ri.quantity,
		   ri.purpose,
		   ri.remarks,
		   ri.created_on,
		   site_address.store_name,
		   site_address.id AS store_id,
		   employee.id AS employee_id,
		   contractors.id AS contractor_id,
		   employee.employee_name AS employee_name,
		   contractors.name AS contractor_name,
		   ri.issue_type
	FROM requisition AS r
	INNER JOIN requisition_items AS ri ON r.id = ri.requisition_id
	INNER JOIN equipments AS e ON ri.equipment_id = e.id 
	LEFT JOIN site_address ON ri.location_id = site_address.id 
	LEFT JOIN employee ON ri.issue_to = employee.id AND 
	ri.issue_type = 1 
	LEFT JOIN contractors ON ri.issue_to = contractors.id AND 
	ri.issue_type = 2
	WHERE r.id = requisition_idIn) AS tmp
	LEFT JOIN 
	(SELECT site_id,SUM(IF(quantity IS NULL, 0, quantity)) AS added_in_stock FROM `diesel_stock` WHERE site_id = siteId AND type = 2 AND requisition_id != requisition_idIn) AS tmpp ON tmp.site_id = tmpp.site_id 
				 LEFT JOIN (SELECT site_id,SUM(IF(quantity IS NULL, 0, quantity)) AS issued_items FROM `diesel_stock` WHERE site_id = siteId AND type = 3 AND requisition_id != requisition_idIn) AS tmppp 
					ON tmp.site_id = tmppp.site_id
				  LEFT JOIN (SELECT site_id,SUM(IF(quantity IS NULL, 0, quantity)) AS opening_stock FROM `diesel_stock` WHERE site_id = siteId AND type = 1) AS tm 
				  ON tmp.site_id = tm.site_id
				  LEFT JOIN (SELECT 
				  SUM(sis.quantity_issued) AS issue_quantity,equipment_id FROM 
				  store_issue_slip sis WHERE sis.requisition_id = 
				  requisition_idIn GROUP BY sis.equipment_id) AS 
				  issue_table 
				  ON tmp.equipment_id = issue_table.equipment_id
				  ;

ELSE

	SELECT 
	tmp.id,
		   tmp.requisition_id,
		   tmp.material_id,
		   tmp.material_name,
		   tmp.product_code,
		   tmp.unit_name,
		   tmp.asset_code,
		   tmp.descriptions,
		   tmp.specifications,
		   tmp.make,
		   tmp.part_no,
		   tmp.quantity,
		   tmp.purpose,
		   tmp.remarks,
		   tmp.created_on,
		   tmp.is_issued,
		   tmp.status,
		   (IF(tmpp.added_in_stock IS NULL,0,tmpp.added_in_stock) - IF(tmppp.issued_items IS NULL,0,tmppp.issued_items) + IF(tm.opening_stock IS NULL,0,tm.opening_stock )) AS in_stock,
		   IF(pprate.rate IS NULL, 0, pprate.rate) AS 
		   previous_purchase_rate,
		   IF(employee_id IS NULL, contractor_id, employee_id) AS 
		   issuer_id,
		   IF(employee_name IS NULL, contractor_name, employee_name) AS 
		   issuer_name,
		   issue_type,
		   store_name,
		   store_id,
		   IFNULL(issue.issued_quantity,0) AS issued_quantity
		   FROM 
	(SELECT ri.id,
			r.status,
			r.is_issued,
		   ri.requisition_id,
		   ri.material_id,
		   m.material_name,
		   m.product_code,
		   u.unit_name,
		   e.asset_code,
		   m.descriptions,
		   m.specifications,
		   material_brand.brand AS make,
		   m.part_no,
		   ri.quantity,
		   ri.purpose,
		   ri.remarks,
		   ri.created_on,
		   site_address.store_name,
		   site_address.id AS store_id,
		   employee.id AS employee_id,
		   contractors.id AS contractor_id,
		   employee.employee_name AS employee_name,
		   contractors.name AS contractor_name,
		   ri.issue_type 
	FROM requisition AS r
	INNER JOIN requisition_items AS ri ON r.id = ri.requisition_id
	INNER JOIN material AS m ON ri.material_id = m.id
	LEFT JOIN unit AS u ON m.unit_id = u.id
	LEFT JOIN material_brand ON ri.material_brand_id = material_brand.id
	LEFT JOIN equipments AS e ON m.equipment_id = e.id 
	LEFT JOIN site_address ON ri.location_id = site_address.id 
	LEFT JOIN employee ON ri.issue_to = employee.id AND 
	ri.issue_type = 1 
	LEFT JOIN contractors ON ri.issue_to = contractors.id AND 
	ri.issue_type = 2
	WHERE r.id = requisition_idIn) AS tmp
	LEFT JOIN 
	(SELECT material_id,SUM(IF(quantity IS NULL, 0, quantity)) AS added_in_stock FROM `material_stock` WHERE site_id = siteId AND type = 2 GROUP BY material_id) AS tmpp ON tmp.material_id = tmpp.material_id 
				 LEFT JOIN (SELECT material_id,SUM(IF(quantity IS NULL, 0, quantity)) AS issued_items FROM `material_stock` WHERE site_id = siteId AND type = 3  GROUP BY material_id) AS tmppp 
					ON tmp.material_id = tmppp.material_id
				  LEFT JOIN (SELECT material_id,SUM(IF(quantity IS NULL, 0, quantity)) AS opening_stock FROM `material_stock` WHERE site_id = siteId AND type = 1 GROUP BY material_id) AS tm 
				  ON tmp.material_id = tm.material_id
	LEFT JOIN (SELECT p1.material_id,p1.rate
	FROM purchase_order_items p1 INNER JOIN purchase_order_items p2
	 ON (p1.material_id = p2.material_id AND p1.id < p2.id)
	) AS pprate ON tmp.material_id = pprate.material_id
	 LEFT JOIN (SELECT SUM(ssi.quantity_issued) AS issued_quantity,ssi.material_id FROM store_issue_slip sis INNER JOIN store_slip_items ssi ON sis.id = ssi.store_slip_id WHERE sis.requisition_id = requisition_idIn GROUP BY ssi.material_id) as issue ON tmp.material_id = issue.material_id group by tmp.material_id;
	
END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getRequisitionItems_v1`(IN `requisition_idIn` BIGINT)
BEGIN

SELECT ri.id,
       ri.requisition_id,
       ri.material_id,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no,
       ri.quantity,
       ri.purpose,
       ri.remarks,
       ri.created_on
FROM requisition AS r
INNER JOIN requisition_items AS ri ON r.id = ri.requisition_id
INNER JOIN material AS m ON ri.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON m.equipment_id = e.id
WHERE r.id = requisition_idIn;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getRequisitionList`(IN `emp_idIn` BIGINT, IN `site_idIn` BIGINT, IN `searchIn` VARCHAR(255), IN `limitIn` INT, IN `offsetIn` INT)
BEGIN

DECLARE department_id_tmp BIGINT DEFAULT 0;
DECLARE total_tmp BIGINT DEFAULT 0;

SELECT IFNULL(department_id, 0) INTO department_id_tmp
FROM employee
WHERE id = emp_idIn;

SELECT COUNT(DISTINCT r.id)
 INTO total_tmp
FROM requisition AS r
INNER JOIN department AS d ON r.department_id = d.id
INNER JOIN requisition_current_state AS rcs ON r.id = rcs.requisition_id
AND r.site_id = site_idIn
INNER JOIN requisition_state_mapping AS rsm ON rcs.state_id = rsm.`state`
INNER JOIN (SELECT t1.requisition_id,t1.status,t1.id FROM 
requisition_track t1 JOIN (SELECT requisition_id,status, MAX(id) AS max_id_t2 FROM 
  requisition_track GROUP BY requisition_id) t2
    ON t1.requisition_id = t2.requisition_id AND t1.id = t2.max_id_t2) 
    AS tmp ON r.id = tmp.requisition_id
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id = 3
      AND rsm.next_role_id = 0)
     OR (er.role_id <> 3
         AND (er.role_id = rsm.role_id
              OR er.role_id = rsm.next_role_id)))
INNER JOIN employee AS e ON er.empid = e.id
INNER JOIN designation_mapping AS dm ON e.id = dm.emp_id
WHERE d.department_name LIKE CONCAT('%', searchIn, '%')
AND (er.role_id = 3 OR (er.role_id <> 3 AND ((department_id_tmp = 1 AND (d.id = 1 OR (r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3)))
     OR (department_id_tmp = 2 AND (d.id = 2 OR (r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3) OR d.id = 4))
     OR ((department_id_tmp <> 1 AND department_id_tmp <> 2) AND ((r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3))))))
AND ((r.prepared_by_id = emp_idIn
      AND r.status NOT IN (0, 5))
     OR (r.prepared_by_id <> emp_idIn
         AND r.status <> 5));

SELECT total_tmp AS total,
       r.id,
       r.requisition_no,
       d.department_name,
       d.id AS department_id,
       r.is_approved AS approve,
       r.prepared_by_id,
       r.status,
       r.is_approved,
       r.save_to_draft,
       tmp.status AS last_status
FROM requisition AS r
INNER JOIN department AS d ON r.department_id = d.id
INNER JOIN requisition_current_state AS rcs ON r.id = rcs.requisition_id
AND r.site_id = site_idIn
INNER JOIN requisition_state_mapping AS rsm ON rcs.state_id = rsm.`state`
INNER JOIN (SELECT t1.requisition_id,t1.status,t1.id FROM 
requisition_track t1 JOIN (SELECT requisition_id,status, MAX(id) AS max_id_t2 FROM 
  requisition_track GROUP BY requisition_id) t2
    ON t1.requisition_id = t2.requisition_id AND t1.id = t2.max_id_t2) 
    AS tmp ON r.id = tmp.requisition_id
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id = 3
      AND rsm.next_role_id = 0)
     OR (er.role_id <> 3
         AND (er.role_id = rsm.role_id
              OR er.role_id = rsm.next_role_id)))
INNER JOIN employee AS e ON er.empid = e.id
INNER JOIN designation_mapping AS dm ON e.id = dm.emp_id
WHERE d.department_name LIKE CONCAT('%', searchIn, '%')
AND (er.role_id = 3 OR (er.role_id <> 3 AND ((department_id_tmp = 1 AND (d.id = 1 OR (r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3)))
     OR (department_id_tmp = 2 AND (d.id = 2 OR (r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3) OR d.id = 4))
     OR ((department_id_tmp <> 1 AND department_id_tmp <> 2) AND ((r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3))))))
AND ((r.prepared_by_id = emp_idIn
      AND r.status NOT IN (0, 5))
     OR (r.prepared_by_id <> emp_idIn
         AND r.status <> 5))
GROUP BY r.id
ORDER BY r.id DESC
LIMIT offsetIn, limitIn;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getSiteData`(IN `emp_idIn` BIGINT, IN `site_idIn` BIGINT, IN `limitIn` INT, IN `offsetIn` INT)
BEGIN

DECLARE department_id_tmp BIGINT DEFAULT 0;
DECLARE total_tmp BIGINT DEFAULT 0;
DECLARE total_raised_requisition BIGINT DEFAULT 0;
DECLARE total_pending_requisition BIGINT DEFAULT 0;
DECLARE total_rejected_requisition BIGINT DEFAULT 0;
DECLARE total_closed_requisition BIGINT DEFAULT 0;
DECLARE total_indent BIGINT DEFAULT 0;
DECLARE total_pending_indent BIGINT DEFAULT 0;
DECLARE total_rejected_indent BIGINT DEFAULT 0;
DECLARE total_closed_indent BIGINT DEFAULT 0;
DECLARE total_pending_po BIGINT DEFAULT 0;

SELECT IFNULL(department_id, 0) INTO department_id_tmp
FROM employee
WHERE id = emp_idIn;

SELECT COUNT(DISTINCT r.id),
       COUNT(DISTINCT IF(r.status NOT IN (3, 5), r.id, NULL)),
       COUNT(DISTINCT IF(r.status = 3, r.id, NULL)),
       COUNT(DISTINCT IF(r.status = 5, r.id, NULL)) INTO total_raised_requisition,
       total_pending_requisition,
       total_rejected_requisition,
       total_closed_requisition
FROM requisition AS r
INNER JOIN department AS d ON r.department_id = d.id
INNER JOIN requisition_current_state AS rcs ON r.id = rcs.requisition_id
AND r.site_id = site_idIn
INNER JOIN requisition_state_mapping AS rsm ON rcs.state_id = rsm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id = 3
      AND rsm.next_role_id = 0)
     OR (er.role_id <> 3
         AND (er.role_id = rsm.role_id
              OR er.role_id = rsm.next_role_id)))
INNER JOIN employee AS e ON er.empid = e.id
INNER JOIN designation_mapping AS dm ON e.id = dm.emp_id
WHERE (er.role_id = 3 OR (er.role_id <> 3 AND ((department_id_tmp = 1 AND (d.id = 1 OR (r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3)))
     OR (department_id_tmp = 2 AND (d.id = 2 OR (r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3) OR d.id = 4))
     OR ((department_id_tmp <> 1 AND department_id_tmp <> 2) AND ((r.prepared_by_id = emp_idIn AND d.id = 3) OR (e.department_id = 3 AND dm.designation_id = 1 AND d.id = 3))))))
/*AND ((r.prepared_by_id = emp_idIn
      AND r.status NOT IN (0, 5))
     OR (r.prepared_by_id <> emp_idIn
         AND r.status <> 5))*/;
         
SELECT COUNT(DISTINCT i.id),
       COUNT(DISTINCT IF(i.status NOT IN (2, 3), i.id, NULL)),
       COUNT(DISTINCT IF(i.status = 2, i.id, NULL)),
       COUNT(DISTINCT IF(i.status = 3, i.id, NULL)) INTO total_indent,
       total_pending_indent,
       total_rejected_indent,
       total_closed_indent
FROM indent AS i
INNER JOIN requisition AS r ON i.requisition_id = r.id
INNER JOIN site AS s ON r.site_id = s.id 
INNER JOIN department AS d ON r.department_id = d.id
INNER JOIN indent_current_state AS ics ON i.id = ics.indent_id
INNER JOIN indent_state_mapping AS ism ON ics.state_id = ism.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id = 7
      AND ism.next_role_id = 0)
     OR (er.role_id <> 7
         AND (er.role_id = ism.role_id
              OR er.role_id = ism.next_role_id)))
WHERE r.status <> 3 AND (site_idIn = 0 OR (site_idIn <> 0 AND r.site_id = site_idIn));

SELECT COUNT(DISTINCT po.id) INTO total_pending_po
FROM purchase_orders AS po
INNER JOIN suppliers AS sp ON po.supplier_id = sp.id
INNER JOIN po_current_state AS pocs ON po.id = pocs.po_id
INNER JOIN po_state_mapping AS posm ON pocs.state_id = posm.`state`
INNER JOIN emp_role AS er ON er.empid = emp_idIn
AND ((er.role_id IN (12, 13)
      AND posm.next_role_id = 0)
     OR (er.role_id NOT IN (12, 13)
         AND (er.role_id = posm.role_id
              OR er.role_id = posm.next_role_id)))
WHERE po.status <> 3;

SELECT COUNT(DISTINCT s.id) INTO total_tmp
FROM site AS s
WHERE (site_idIn = 0
       OR (site_idIn <> 0
           AND s.id = site_idIn));

SELECT total_tmp AS total,
       s.id AS site_id,
       s.site_name,
       total_raised_requisition,
       total_pending_requisition,
       total_rejected_requisition,
       total_closed_requisition,
       total_indent,
       total_pending_indent,
       total_rejected_indent,
       total_closed_indent,
       total_pending_po
FROM site AS s
WHERE (site_idIn = 0
       OR (site_idIn <> 0
           AND s.id = site_idIn))
LIMIT offsetIn, limitIn;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getSiteReport`(IN `site_idIn` INT, IN `from_dateIn` VARCHAR(255) CHARSET utf8, IN `to_dateIn` VARCHAR(255) CHARSET utf8, IN `department_idIn` INT(1))
BEGIN SELECT IFNULL(e.name, m.material_name) AS material_name, IFNULL(mg.name, '') AS material_group_name, IFNULL(msg.name, '') AS material_sub_group_name, IFNULL(m.rate, 0) AS rate, IFNULL(u.unit_name, '') AS unit, IFNULL(SUM(IF(ms.type = 1, ms.quantity, 0)), 0) AS opening_balance_quantity, IFNULL(SUM(IF(ms.type = 2, ms.quantity, 0)), 0) AS inwards_quantity, IFNULL(SUM(IF(ms.type = 3, ms.quantity, 0)), 0) AS outwards_quantity FROM material AS m INNER JOIN site_material AS sm ON m.id = sm.material_id AND sm.site_id = site_idIn LEFT JOIN equipments AS e ON m.equipment_id = e.id LEFT JOIN material_group AS mg ON m.material_group_id = mg.id LEFT JOIN material_group AS msg ON m.material_sub_group_id = msg.id LEFT JOIN unit AS u ON m.unit_id = u.id LEFT JOIN material_stock AS ms ON m.id = ms.material_id AND ('' = from_dateIn OR (from_dateIn <> '' AND DATE(ms.created_on) >= from_dateIn)) AND ('' = to_dateIn OR (to_dateIn <> '' AND DATE(ms.created_on) <= to_dateIn)) WHERE (department_idIn = 0 OR m.material_type_id = department_idIn) GROUP BY m.id; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `importCivilMaterial`(IN `groupNameIn` VARCHAR(255), IN `subGroupNameIn` VARCHAR(255), IN `materialNameIn` VARCHAR(255), IN `productCodeIn` VARCHAR(255), IN `unitNameIn` VARCHAR(255), IN `brandIn` VARCHAR(255), IN `quantityIn` INT(11), IN `rateIn` DOUBLE, IN `hsn_codeIn` VARCHAR(50), IN `company_idIn` INT(11), IN `site_idIn` INT(11), IN `material_type_idIn` INT, IN `specificationsIn` TEXT)
BEGIN

DECLARE number_of_rows_inserted_tmp INT(1) DEFAULT 0;
DECLARE is_error_tmp TINYINT(1) DEFAULT 0;
DECLARE group_id_tmp INT;
DECLARE sub_group_id_tmp INT;
DECLARE unit_id_tmp INT;
DECLARE material_id_tmp INT;

IF (groupNameIn <> '') THEN

SELECT id INTO group_id_tmp FROM material_group WHERE name = groupNameIn AND parent_id = 0;

IF (group_id_tmp IS NULL) THEN

INSERT INTO `material_group` (`parent_id`, `name`) VALUES (0, groupNameIn);

SELECT ROW_COUNT(), LAST_INSERT_ID() INTO number_of_rows_inserted_tmp, group_id_tmp;

IF (number_of_rows_inserted_tmp = 1) THEN

SET number_of_rows_inserted_tmp = 0;

ELSE

SET is_error_tmp = 1;

END IF;

END IF;

END IF;

IF (subGroupNameIn <> '') THEN

SELECT id INTO sub_group_id_tmp FROM material_group WHERE name = subGroupNameIn AND parent_id = group_id_tmp;

IF (is_error_tmp = 0 AND sub_group_id_tmp IS NULL) THEN

INSERT INTO `material_group` (`parent_id`, `name`) VALUES (group_id_tmp, subGroupNameIn);

SELECT ROW_COUNT(), LAST_INSERT_ID() INTO number_of_rows_inserted_tmp, sub_group_id_tmp;

IF (number_of_rows_inserted_tmp = 1) THEN

SET number_of_rows_inserted_tmp = 0;

ELSE

SET is_error_tmp = 1;

END IF;

END IF;

END IF;

SELECT id INTO unit_id_tmp FROM unit WHERE unit_name = unitNameIn;

IF (is_error_tmp = 0 AND unit_id_tmp IS NULL) THEN

INSERT INTO `unit` (`unit_name`) VALUES (unitNameIn);

SELECT ROW_COUNT(), LAST_INSERT_ID() INTO number_of_rows_inserted_tmp, unit_id_tmp;

IF (number_of_rows_inserted_tmp = 1) THEN

SET number_of_rows_inserted_tmp = 0;

ELSE

SET is_error_tmp = 1;

END IF;

END IF;

SELECT m.id INTO material_id_tmp FROM material AS m INNER JOIN site_material AS sm ON m.id = sm.material_id AND sm.site_id = site_idIn WHERE m.material_name = materialNameIn AND m.material_group_id = group_id_tmp AND m.material_sub_group_id = sub_group_id_tmp;

IF (is_error_tmp = 0 AND material_id_tmp IS NULL) THEN

INSERT INTO `material` (`material_group_id`, `material_sub_group_id`, 
	`material_name`, 
	`product_code`, 
	`unit_id`, 
	`brand`, 
	`quantity`, 
	`rate`, 
	`value`,
	`material_type_id`, 
	`company_id`, 
	`hsn_code`,
	`specifications`)
	 VALUES 
	 (
	 group_id_tmp, 
	 sub_group_id_tmp, 
	 materialNameIn, 
	 IF(productCodeIn = '', NULL, productCodeIn), 
	 unit_id_tmp, 
	 IF(brandIn = '', NULL, brandIn), 
	 quantityIn, 
	 rateIn, 
	 quantityIn * rateIn,
	  material_type_idIN,
	  company_idIn, 
	  IF(hsn_codeIn = '', NULL, hsn_codeIn),
	  specificationsIn );

SELECT ROW_COUNT(), LAST_INSERT_ID() INTO number_of_rows_inserted_tmp, material_id_tmp;

IF (number_of_rows_inserted_tmp = 1) THEN

SET number_of_rows_inserted_tmp = 0;

IF (productCodeIn = '') THEN

IF (material_type_idIN = 1) THEN

SELECT CONCAT(short_name, '/CE/', SUBSTRING(materialNameIn, 1, 2), '/', material_id_tmp) INTO productCodeIn
FROM company
WHERE id = company_idIn;

ELSEIF (material_type_idIN = 3) THEN

SELECT CONCAT(short_name, '/HR/', SUBSTRING(materialNameIn, 1, 2), '/', material_id_tmp) INTO productCodeIn
FROM company
WHERE id = company_idIn;

END IF;

UPDATE `material` SET `product_code` = productCodeIn WHERE id = material_id_tmp;

END IF;

INSERT INTO `site_material` (`site_id`, `material_id`) VALUES (site_idIn, material_id_tmp);

INSERT INTO `material_stock` (`site_id`, `material_id`, `quantity`, `type`) VALUES (site_idIn, material_id_tmp, quantityIn, 1);

ELSE

SET is_error_tmp = 1;

END IF;

ELSEIF (is_error_tmp = 0) THEN

UPDATE `material` SET `product_code` = IF(productCodeIn = '', NULL, productCodeIn), `unit_id` = unit_id_tmp, `brand` = IF(brandIn = '', NULL, brandIn), `quantity` = `quantity` + quantityIn, `rate` = rateIn, `value` = `quantity` * rateIn, `hsn_code` = IF(hsn_codeIn = '', NULL, hsn_codeIn),`material_type_id` = material_type_idIn  ,`specifications` = specificationsIn  WHERE id = material_id_tmp;

INSERT INTO `material_stock` (`site_id`, `material_id`, `quantity`, `type`) VALUES (site_idIn, material_id_tmp, quantityIn, 1);

END IF;

IF (is_error_tmp = 1) THEN

SELECT 0 AS status;

ELSE

SELECT 1 AS status;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `importEquipmentParts`(IN `equipment_nameIn` VARCHAR(255), IN `specificationsIn` TEXT, IN `descriptionsIn` TEXT, IN `part_noIn` VARCHAR(255), IN `quantityIn` INT(11), IN `rateIn` DOUBLE, IN `hsn_codeIn` VARCHAR(50), IN `company_idIn` INT(11), IN `site_idIn` INT(11))
BEGIN

DECLARE number_of_rows_inserted_tmp INT(1) DEFAULT 0;
DECLARE is_error_tmp TINYINT(1) DEFAULT 0;
DECLARE equipment_id_tmp INT;
DECLARE material_id_tmp INT;

SELECT id INTO equipment_id_tmp FROM equipments WHERE asset_code = equipment_nameIn;

IF (equipment_id_tmp IS NULL) THEN

SET is_error_tmp = 1;

END IF;

SELECT m.id INTO material_id_tmp FROM material AS m INNER JOIN site_material AS sm ON m.id = sm.material_id AND sm.site_id = site_idIn WHERE m.equipment_id = equipment_id_tmp AND m.part_no = part_noIn;

IF (is_error_tmp = 0 AND material_id_tmp IS NULL) THEN

INSERT INTO `material` (`equipment_id`, `specifications`, `descriptions`, `part_no`, `quantity`, `rate`, `value`, `material_type_id`, `company_id`, `hsn_code`) VALUES (equipment_id_tmp, IF(specificationsIn = '', NULL, specificationsIn), IF(descriptionsIn = '', NULL, descriptionsIn), part_noIn, quantityIn, rateIn, quantityIn * rateIn, 2, company_idIn, IF(hsn_codeIn = '', NULL, hsn_codeIn));

SELECT ROW_COUNT(), LAST_INSERT_ID() INTO number_of_rows_inserted_tmp, material_id_tmp;

IF (number_of_rows_inserted_tmp = 1) THEN

SET number_of_rows_inserted_tmp = 0;

INSERT INTO `site_material` (`site_id`, `material_id`) VALUES (site_idIn, material_id_tmp);

INSERT INTO `material_stock` (`site_id`, `material_id`, `quantity`, `type`) VALUES (site_idIn, material_id_tmp, quantityIn, 1);

ELSE

SET is_error_tmp = 1;

END IF;

ELSEIF (is_error_tmp = 0) THEN

UPDATE `material` SET `specifications` = IF(specificationsIn = '', NULL, specificationsIn), `descriptions` = IF(descriptionsIn = '', NULL, descriptionsIn), `quantity` = `quantity` + quantityIn, `rate` = rateIn, `value` = `quantity` * rateIn, `hsn_code` = IF(hsn_codeIn = '', NULL, hsn_codeIn) WHERE id = material_id_tmp;

INSERT INTO `material_stock` (`site_id`, `material_id`, `quantity`, `type`) VALUES (site_idIn, material_id_tmp, quantityIn, 1);

END IF;

IF (is_error_tmp = 1) THEN

SELECT 0 AS status;

ELSE

SELECT 1 AS status;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `importEquipments`(IN `nameIn` VARCHAR(255), IN `asset_codeIn` VARCHAR(255), IN `engine_noIn` VARCHAR(255), IN `chasis_noIn` VARCHAR(255), IN `reg_noIn` VARCHAR(255), IN `insurance_fromIn` VARCHAR(25), IN `insurance_toIn` VARCHAR(25), IN `road_tax_fromIn` VARCHAR(25), IN `road_tax_toIn` VARCHAR(25), IN `brandIn` VARCHAR(255), IN `modelIn` VARCHAR(255), IN `hsn_codeIn` VARCHAR(50), IN `company_idIn` INT(11), IN `site_idIn` INT(11))
BEGIN

DECLARE number_of_rows_inserted_tmp INT(1) DEFAULT 0;
DECLARE is_error_tmp TINYINT(1) DEFAULT 0;
DECLARE equipment_id_tmp INT;

SELECT e.id INTO equipment_id_tmp FROM equipments AS e INNER JOIN site_equipment AS se ON e.id = se.equipment_id AND se.site_id = site_idIn WHERE e.name = nameIn AND e.asset_code = asset_codeIn;

IF (equipment_id_tmp IS NOT NULL) THEN

SET is_error_tmp = 1;

END IF;

IF (is_error_tmp = 0) THEN

INSERT INTO `equipments` (`company_id`, `name`, `asset_code`, `engine_no`, `chasis_no`, `reg_no`, `insurance_from`, `insurance_to`, `road_tax_from`, `road_tax_to`, `brand`, `model`, `hsn_code`) VALUES (company_idIn, nameIn, asset_codeIn, IF(engine_noIn = '', NULL, engine_noIn), IF(chasis_noIn = '', NULL, chasis_noIn), IF(reg_noIn = '', NULL, reg_noIn), IF(insurance_fromIn = '', NULL, insurance_fromIn), IF(insurance_toIn = '', NULL, insurance_toIn), IF(road_tax_fromIn = '', NULL, road_tax_fromIn), IF(road_tax_toIn = '', NULL, road_tax_toIn), IF(brandIn = '', NULL, brandIn), IF(modelIn = '', NULL, modelIn), IF(hsn_codeIn = '', NULL, hsn_codeIn));

SELECT ROW_COUNT(), LAST_INSERT_ID() INTO number_of_rows_inserted_tmp, equipment_id_tmp;

IF (number_of_rows_inserted_tmp = 1) THEN

SET number_of_rows_inserted_tmp = 0;

INSERT INTO `site_equipment` (`site_id`, `equipment_id`) VALUES (site_idIn, equipment_id_tmp);

ELSE

SET is_error_tmp = 1;

END IF;

END IF;

IF (is_error_tmp = 1) THEN

SELECT 0 AS status;

ELSE

SELECT 1 AS status;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `issueSlipView`(IN `issueSlip_idIn` INT(11), IN `issue_typeIn` INT(1))
    NO SQL
BEGIN

IF(issue_typeIn = 2) THEN

SELECT 
	issue_typeIn AS issue_type,
	sis.equipment_id, 
	sis.serial_no, 
	sis.site_id,
	site.site_name,
	e.asset_code, 
	sis.date_on, 
	sis.requisition_id, 
	sis.last_reading, 
	sis.current_reading, 
	sis.quantity_issued 
FROM 
	store_issue_slip sis 
	LEFT JOIN site ON sis.site_id = site.id 
	LEFT JOIN equipments e ON sis.equipment_id = e.id
	WHERE sis.id = issueSlip_idIn;

ELSE

SELECT 
	issue_typeIn AS issue_type,
	sis.equipment_id, 
	sis.serial_no, 
	sis.site_id,
	site.site_name,
	m.material_name, 
	sis.date_on, 
	sis.requisition_id 
FROM 
	store_issue_slip sis 
	LEFT JOIN site ON sis.site_id = site.id 
	LEFT JOIN material m ON sis.material_id = m.id
	WHERE sis.id = issueSlip_idIn;

END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `issueSlipViewItems`(IN `issueSlip_idIn` INT(11), IN `issue_typeIn` INT(1))
    NO SQL
BEGIN IF(issue_typeIn = 2) THEN SELECT issue_typeIn AS issue_type, sis.equipment_id, sis.serial_no, sis.site_id, site.site_name, e.asset_code, sis.date_on, sis.requisition_id, sis.last_reading, sis.current_reading, sis.quantity_issued FROM store_issue_slip sis LEFT JOIN site ON sis.site_id = site.id LEFT JOIN equipments e ON sis.equipment_id = e.id WHERE sis.id = issueSlip_idIn; ELSE SELECT issue_typeIn AS issue_type, sis.equipment_id, sis.material_id, sis.serial_no, sis.site_id, site.site_name, IFNULL(m.material_name,e.asset_code) AS material, sis.date_on, sis.requisition_id, ssi.quantity_required, ssi.quantity_issued, ssi.remarks FROM store_issue_slip sis LEFT JOIN store_slip_items ssi ON sis.id = ssi.store_slip_id LEFT JOIN site ON sis.site_id = site.id LEFT JOIN material m ON ssi.material_id = m.id LEFT JOIN equipments e ON m.equipment_id = e.id WHERE sis.id = issueSlip_idIn; END IF; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `requisitionStatus`(IN `requisition_idIn` INT(11))
    NO SQL
BEGIN

DECLARE requisition_quantity INT DEFAULT 0;

DECLARE requisition_quantity_approved INT DEFAULT 1;

SELECT SUM(quantity) INTO requisition_quantity FROM requisition INNER JOIN requisition_items ON requisition.id = requisition_items.requisition_id WHERE requisition.id = requisition_idIn;

SELECT SUM(quantity_approved) INTO requisition_quantity_approved FROM indent INNER JOIN indent_items ON indent.id = indent_items.indent_id WHERE indent.requisition_id = requisition_idIn;

IF(requisition_quantity_approved = requisition_quantity) THEN
	UPDATE requisition SET status = 0 WHERE id = requisition_idIn;
END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `searchAssetCodeForDiesel`(IN `asset_codeIn` VARCHAR(255), IN `site_idIn` INT(11))
    NO SQL
BEGIN

SELECT 
equipments.id AS equipment_id,asset_code,reg_no,
IF(MAX(current_reading) IS NULL,0,MAX(current_reading)) AS last_reading 
FROM 
equipments 
INNER JOIN site_equipment ON equipments.id = site_equipment.equipment_id AND site_equipment.site_id = site_idIn 
LEFT JOIN store_issue_slip ON equipments.id = store_issue_slip.equipment_id AND store_issue_slip.issue_type = 2 AND store_issue_slip.site_id = site_idIn 
WHERE site_equipment.site_id = site_idIn AND equipments.asset_code LIKE CONCAT('%',asset_codeIn,'%') 
GROUP BY equipments.id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `truncatematerialdata`()
BEGIN
set foreign_key_checks = 0;
truncate nkc.material;
truncate nkc.material_stock;
truncate nkc.diesel_stock;
truncate nkc.equipments;
truncate nkc.indent;
truncate nkc.indent_current_state;
truncate nkc.indent_files;
truncate nkc.indent_items;
truncate nkc.site_material;
truncate nkc.site_equipment;
truncate nkc.material_group;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `truncateTables`()
    NO SQL
BEGIN

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE requisition;
TRUNCATE requisition_items;
TRUNCATE requisition_current_state;
TRUNCATE requisition_file;
TRUNCATE requisition_files;
TRUNCATE requisition_track;
TRUNCATE ri_requisition;
TRUNCATE indent;
TRUNCATE indent_current_state;
TRUNCATE indent_files;
TRUNCATE indent_items;
TRUNCATE indent_track;
TRUNCATE material_receipt;
TRUNCATE material_receipt_items;
TRUNCATE mrn_current_state;
TRUNCATE po_current_state;
TRUNCATE po_track;
TRUNCATE purchase_orders;
TRUNCATE purchase_order_files;
TRUNCATE purchase_order_items;
TRUNCATE store_issue_slip;
TRUNCATE store_slip_items;
DELETE FROM material_stock WHERE type IN (2,3);
DELETE FROM diesel_stock WHERE type IN (2,3);


END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` bigint(20) NOT NULL,
  `emp_id` bigint(20) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL,
  `company_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `emp_id`, `password`, `company_id`) VALUES
(1, 1, '123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `amended_po`
--

CREATE TABLE IF NOT EXISTS `amended_po` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL,
  `supplier_id` bigint(20) NOT NULL,
  `against_po_id` bigint(20) NOT NULL,
  `new_po_nubmer` varchar(255) NOT NULL,
  `department_id` int(1) NOT NULL,
  `against_mrn_id` bigint(20) NOT NULL,
  `freight` float(11,2) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `amended_po`
--

INSERT INTO `amended_po` (`id`, `site_id`, `supplier_id`, `against_po_id`, `new_po_nubmer`, `department_id`, `against_mrn_id`, `freight`, `status`, `created_on`) VALUES
(3, 1, 1, 3, '2017-12-2210:20:050.27485300', 1, 9, 1000.00, 1, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `amended_po_items`
--

CREATE TABLE IF NOT EXISTS `amended_po_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amended_po_id` bigint(20) NOT NULL,
  `material_id` bigint(20) DEFAULT NULL,
  `equipment_id` bigint(20) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `rate` float(11,2) NOT NULL,
  `discount` float(11,2) NOT NULL,
  `gst` float(11,2) NOT NULL,
  `amount` float(11,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `amended_po_items`
--

INSERT INTO `amended_po_items` (`id`, `amended_po_id`, `material_id`, `equipment_id`, `quantity`, `rate`, `discount`, `gst`, `amount`) VALUES
(1, 3, 10, NULL, 200, 10.00, 5.00, 5.00, 12000.00);

-- --------------------------------------------------------

--
-- Table structure for table `approval_master`
--

CREATE TABLE IF NOT EXISTS `approval_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approval_type` tinyint(1) NOT NULL COMMENT '0->indent,1->requisition',
  `indent_id` int(11) NOT NULL,
  `requisition_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `approver_id` int(11) NOT NULL,
  `requested_on` varchar(20) NOT NULL,
  `approved_on` varchar(20) NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0->pending,1->approved,2->rejected',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_requisition_approval_rreq_id_idx` (`requisition_id`),
  KEY `fk_requisition_approval_dep_id_idx` (`dep_id`),
  KEY `fk_requisition_approval_approvar_id_idx` (`approver_id`),
  KEY `fk_requisition_indent_approval_indent_id_idx` (`indent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `contact_person_name` varchar(50) DEFAULT NULL,
  `contact_person_email` varchar(50) DEFAULT NULL,
  `contact_person_phone` varchar(20) DEFAULT NULL,
  `address` text NOT NULL,
  `gst_no` varchar(50) NOT NULL,
  `pan_no` varchar(20) NOT NULL,
  `reg_no` varchar(50) DEFAULT NULL,
  `cin_no` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `short_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `contact_person_name`, `contact_person_email`, `contact_person_phone`, `address`, `gst_no`, `pan_no`, `reg_no`, `cin_no`, `status`, `created_on`, `short_name`) VALUES
(1, 'test', 'test', 'test', 'test', 'test', '123654', 'test', 'test', 'NKC123456789', 1, '2017-09-26 10:39:29', 'NKC'),
(2, 'kishortest', 'test', 'test', 'test', 'test', '326854', 'test', 'tes', NULL, 1, '2017-09-26 10:40:13', 'NKC');

-- --------------------------------------------------------

--
-- Table structure for table `company_subscription`
--

CREATE TABLE IF NOT EXISTS `company_subscription` (
  `id` int(11) NOT NULL DEFAULT '0',
  `company_id` int(11) NOT NULL,
  `subcription_mode` tinyint(1) NOT NULL COMMENT '0->Free, 1->Paid',
  `subscription_start_date` varchar(20) DEFAULT NULL,
  `subscription_end_date` varchar(20) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_company_subscription_1_idx` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `composition`
--

CREATE TABLE IF NOT EXISTS `composition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `composition`
--

INSERT INTO `composition` (`id`, `name`, `created_on`, `status`) VALUES
(3, 'composition', '2017-10-04 05:43:59', 1),
(8, 'M10', '2017-10-06 04:26:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `composition_material`
--

CREATE TABLE IF NOT EXISTS `composition_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `composition_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `percentage` float(5,2) DEFAULT NULL,
  `quantity` float(11,2) DEFAULT NULL,
  `rate` float(11,2) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_composition_material_1_idx` (`material_id`),
  KEY `fk_composition_material_2_idx` (`composition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `composition_site`
--

CREATE TABLE IF NOT EXISTS `composition_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `composition_material_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_composition_site_1_idx` (`site_id`),
  KEY `fk_composition_site_2_idx` (`composition_material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `contractors`
--

CREATE TABLE IF NOT EXISTS `contractors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `work` varchar(255) NOT NULL,
  `gst_no` varchar(50) NOT NULL,
  `pan_no` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `w_o_number` varchar(100) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contractors`
--

INSERT INTO `contractors` (`id`, `name`, `work`, `gst_no`, `pan_no`, `address`, `phone_no`, `w_o_number`, `created_on`, `status`) VALUES
(1, 'bisht', 'SE', '2552', '548151', 'Kullu', '9120536789', '', '2017-10-05 11:36:33', 1);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_name`, `created_on`, `status`) VALUES
(1, 'civil', '2017-10-05 04:29:40', 1),
(2, 'mechanical', '2017-10-09 06:54:22', 1),
(3, 'hr', '2017-10-09 06:54:22', 1),
(4, 'Diesel', '2017-12-07 05:38:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE IF NOT EXISTS `designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `name`, `created_on`) VALUES
(1, 'HOD', '2017-10-09 04:50:08'),
(2, 'PM', '2017-10-09 04:50:08'),
(3, 'SITE ENGINEER', '2017-11-01 11:54:40'),
(4, 'STORE MANAGER', '2017-11-01 11:54:40'),
(5, 'STORE KEEPER', '2017-11-14 04:04:51'),
(6, 'HO PURCHASE', '2017-11-21 05:58:35'),
(7, 'HR', '2017-11-30 09:39:33'),
(8, 'HO Mechanical', '2017-12-14 11:41:08'),
(9, 'CEO', '2017-12-18 05:40:35');

-- --------------------------------------------------------

--
-- Table structure for table `designation_mapping`
--

CREATE TABLE IF NOT EXISTS `designation_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `designation_mapping`
--

INSERT INTO `designation_mapping` (`id`, `emp_id`, `designation_id`, `created_on`) VALUES
(8, 7, 6, '2017-11-21 06:01:40'),
(10, 10, 7, '2017-11-30 09:40:13'),
(12, 3, 3, '2017-11-30 09:50:12'),
(20, 13, 6, '2017-12-13 04:31:25'),
(21, 14, 3, '2017-12-13 04:34:02'),
(25, 15, 3, '2017-12-14 11:32:53'),
(26, 6, 1, '2017-12-14 11:38:45'),
(27, 16, 8, '2017-12-14 11:44:11'),
(29, 9, 1, '2017-12-14 12:29:24'),
(30, 1, 1, '2017-12-15 11:11:37'),
(35, 8, 9, '2017-12-18 05:41:26'),
(36, 11, 6, '2017-12-18 17:27:43'),
(37, 5, 5, '2017-12-19 09:05:57'),
(39, 4, 4, '2017-12-20 07:10:28'),
(40, 12, 1, '2017-12-20 08:34:24'),
(41, 2, 2, '2017-12-20 08:35:13');

-- --------------------------------------------------------

--
-- Table structure for table `diesel_stock`
--

CREATE TABLE IF NOT EXISTS `diesel_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `requisition_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) DEFAULT NULL,
  `type` int(1) NOT NULL COMMENT 'opening->1,2->po,3->issue',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `employee_code` varchar(255) DEFAULT NULL,
  `doj` varchar(20) NOT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `employee_mode` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0->contractor,1->permanent',
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_employee_1_idx` (`department_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `department_id`, `employee_name`, `email_id`, `password`, `employee_code`, `doj`, `dob`, `phone_no`, `created_on`, `status`, `employee_mode`, `company_id`) VALUES
(1, 1, 'MOHIT SOBTI', 'civil.hod@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '101', '2017-09-10 13:25:21', '11/01/2017', '546564645', '2017-10-05 04:29:44', 1, 1, 1),
(2, 2, 'SANJAY KUMAR ', 'project.manager@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '102', '10/09/2017', '10/01/2017', '25362', '2017-10-09 06:58:10', 1, 1, 1),
(3, 1, 'JONY KUMAR', 'site.engineer@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '103', '06/20/2017', '02/02/2007', '1122336655', '2017-11-01 12:02:23', 1, 1, 1),
(4, 2, 'AKHILESH DIKSHIT', 'store.manager@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '104', '11/01/2017', '02/22/2007', '7755889966', '2017-11-01 12:04:20', 1, 1, 1),
(5, 2, 'VED RAM', 'store.keeper@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '105', '11/14/2017', '01/17/2007', '1254789630', '2017-11-14 04:06:02', 1, 1, 1),
(6, 2, 'G S KAHLON', 'mechanical.hod@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '106', '11/01/2017', '11/01/2017', '32658254', '2017-11-19 04:50:18', 1, 1, 1),
(7, 1, 'ho purchase', 'ho.purchase@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '107', '01/01/2007', '02/28/2007', '7504929245', '2017-11-21 06:01:40', 1, 1, 1),
(8, 1, 'CEO', 'ceo@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '108', '2015-10-10', '1992-12-12', '5469871230', '2017-11-30 06:35:41', 1, 1, 1),
(9, 4, 'jeevan', 'jeevan@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '109', '11/30/2017', '11/02/2017', '12345432', '2017-11-30 08:54:15', 1, 1, 1),
(10, 1, 'AJAY SHARMA', 'hr@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '110', '11/01/2017', '11/01/2010', '1234567890', '2017-11-30 09:40:13', 1, 1, 1),
(11, 1, 'N  VEERRAJU', 'ho.planning@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '111', '11/01/2017', '11/01/2017', '3571594562', '2017-11-30 10:25:33', 1, 1, 1),
(12, 3, 'Akhilesh Dixit', 'hr.hod@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '112', '11/01/2017', '11/01/2017', '3571594562', '2017-11-30 10:25:33', 1, 1, 1),
(13, 1, 'Yogesh', 'yogesh@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '119', '12/01/2017', '12/01/2017', '8447726137', '2017-12-13 04:31:25', 1, 1, 1),
(14, 1, 'R sharma', 'r.sharma@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '120', '12/01/2017', '12/01/2011', '1234567890', '2017-12-13 04:34:01', 1, 1, 1),
(15, 2, 'PRAKASH CHANDRA UPADHYAY', 'engineer.mechanical@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '122', '12/01/2017', '12/07/2010', '1311616113', '2017-12-14 11:32:42', 1, 1, 1),
(16, 1, 'HO Mech', 'ho.mechanical@nkc.com', '827ccb0eea8a706c4c34a16891f84e7b', '123', '12/01/2017', '12/01/2010', '1122336655', '2017-12-14 11:44:10', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `emp_role`
--

CREATE TABLE IF NOT EXISTS `emp_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empid` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_emp_role_1_idx` (`role_id`),
  KEY `fk_emp_role_2_idx` (`empid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `emp_role`
--

INSERT INTO `emp_role` (`id`, `empid`, `role_id`) VALUES
(8, 7, 7),
(15, 10, 11),
(18, 3, 1),
(32, 13, 7),
(33, 14, 1),
(39, 15, 1),
(40, 6, 1),
(41, 6, 2),
(42, 16, 10),
(45, 9, 1),
(46, 9, 2),
(47, 1, 1),
(48, 1, 2),
(61, 8, 9),
(62, 11, 6),
(63, 5, 3),
(64, 5, 12),
(65, 5, 13),
(72, 4, 3),
(73, 4, 4),
(74, 4, 12),
(75, 4, 13),
(76, 4, 14),
(77, 12, 1),
(78, 12, 2),
(79, 2, 1),
(80, 2, 5),
(81, 2, 14);

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE IF NOT EXISTS `equipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `asset_code` varchar(50) DEFAULT NULL,
  `engine_no` varchar(100) DEFAULT NULL,
  `chasis_no` varchar(100) DEFAULT NULL,
  `reg_no` varchar(100) DEFAULT NULL,
  `insurance_from` varchar(20) DEFAULT NULL,
  `insurance_to` varchar(20) DEFAULT NULL,
  `road_tax_from` varchar(20) DEFAULT NULL,
  `road_tax_to` varchar(20) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL DEFAULT '1',
  `hsn_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`id`, `company_id`, `name`, `asset_code`, `engine_no`, `chasis_no`, `reg_no`, `insurance_from`, `insurance_to`, `road_tax_from`, `road_tax_to`, `brand`, `model`, `created_on`, `status`, `hsn_code`) VALUES
(1, 1, 'Tipper ', 'NKC/CE-07/TP-01', '50A62380693', '396095AUZ200391', 'RJ14GC 7550', '2001-01-17', '2031-12-17', '2001-01-17', '2031-12-17', 'Tata', '2516', '2017-12-21 11:53:35', 1, '303'),
(2, 1, 'Tipper ', 'NKC/CE-08/TP-02', NULL, '396095AUZ200409', 'RJ14GC 7552', '2001-01-17', '2031-12-17', '2001-01-17', '2031-12-17', 'Tata', '2516', '2017-12-21 11:53:35', 1, '303'),
(3, 1, 'Tipper ', 'NKC/CE-9/TP-03', '50A62380181', '396095AUZ200457', 'RJ14GC 7553', '2001-01-17', '2031-12-17', '2001-01-17', '2031-12-17', 'Tata', '2516', '2017-12-21 11:53:35', 1, '303'),
(4, 1, 'Tipper ', 'NKC/CE-10/TP-04', '50A62380528', '396095AUZ200469', 'RJ14GC 7546', '2001-01-17', '2031-12-17', '2001-01-17', '2031-12-17', 'Tata', '2516', '2017-12-21 11:53:35', 1, '303'),
(5, 1, 'Tipper ', 'NKC/CE-11/TP-05', NULL, '396095AUZ200468', 'RJ14GC 7556', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(6, 1, 'Tipper ', 'NKC/CE-12/TP-06', '40J62356375', '396095JVZ211625', 'RJ14GC 7776', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(7, 1, 'Tipper ', 'NKC/CE-13/TP-07', '40J62357184', '3976095JVZ211573', 'RJ14GC 7779', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(8, 1, 'Tipper ', 'NKC/CE-14/TP-08', '40J62357266', '396095JVZ211593', 'RJ14GC 7781', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(9, 1, 'Tipper ', 'NKC/CE-15/TP-09', '40J62357267', '396095JVZ211587', 'RJ14GC 7784', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(10, 1, 'Tipper ', 'NKC/CE-16/TP-10', '40J62358119', '396095JVZ211761', 'RJ14GC 9151', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(11, 1, 'Tipper ', 'NKC/CE-17/TP-11', '40H62357609', '396095HVZ210722', 'RJ14GC 9148', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(12, 1, 'Tipper ', 'NKC/CE-18/TP-12', '40H62352283', '396095HVZ210721', 'RJ14GC 9150', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(13, 1, 'Tipper ', 'NKC/CE-19/TP-13', '40H62352619', '396095HVZ210723', 'RJ14GC 9153', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(14, 1, 'Tipper ', 'NKC/CE-20/TP-14', '40J62357269', '396095JVZ200571', 'RJ14GC 9142', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:35', 1, NULL),
(15, 1, 'Tipper ', 'NKC/CE-21/TP-15', '40J62357395', '396095JVZ211601', 'RJ14GC 9145', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:36', 1, NULL),
(16, 1, 'Tipper ', 'NKC/CE-22/TP-16', '40J62357001', '396095JVZ211584', 'RJ14GC 7783', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:36', 1, NULL),
(17, 1, 'Tipper ', 'NKC/CE-23/TP-17', '40J62357187', '396095JVZ211585', 'RJ14GC 9146', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:36', 1, NULL),
(18, 1, 'Tipper ', 'NKC/CE-24/TP-18', '40J62357271', '396095JVZ211592', 'RJ14GC 9152', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:36', 1, NULL),
(19, 1, 'Tipper ', 'NKC/CE-25/TP-19', '40J62358024', '396095JVZ211759', 'UP25Q 9753', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:36', 1, NULL),
(20, 1, 'Tipper ', 'NKC/CE-26/TP-20', '40A62381038', '396095AUZ200508', 'UP25Q 9935', NULL, NULL, NULL, NULL, 'Tata', '2516', '2017-12-21 11:53:36', 1, NULL),
(21, 1, 'Tipper', 'NKC/CE-422/TP-126', 'B5.91803221J63286213', 'MAT448104C3J25990', 'ML-10A-8845', NULL, NULL, NULL, NULL, NULL, NULL, '2017-12-21 11:53:36', 1, NULL),
(22, 1, 'Tipper', 'NKC/CE-423/TP-127', 'B5.91803221H63279083', 'MAT448104C3H22487', 'ML-10A-8846', NULL, NULL, NULL, NULL, NULL, NULL, '2017-12-21 11:53:36', 1, NULL),
(23, 1, 'Tipper', 'NKC/CE-424/TP-128', 'B5.91803221H63278410', 'MAT448104C3H22129', 'ML-10A-8847', NULL, NULL, NULL, NULL, NULL, NULL, '2017-12-21 11:53:36', 1, NULL),
(24, 1, 'Tipper', 'NKC/CE-425/TP-129', 'B5.91803221J63286158', 'MAT448104C3J25839', 'ML-10A-8848', NULL, NULL, NULL, NULL, NULL, NULL, '2017-12-21 11:53:36', 1, NULL),
(25, 1, 'Tipper', 'NKC/CE-426/TP-130', 'B5.91803221H63279118', 'MAT448104C3H22486', 'ML-10A-8849', NULL, NULL, NULL, NULL, NULL, NULL, '2017-12-21 11:53:36', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `indent`
--

CREATE TABLE IF NOT EXISTS `indent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `registered_on` varchar(20) NOT NULL,
  `indent_no` int(11) NOT NULL,
  `requested_by_id` int(11) DEFAULT NULL,
  `verified_by_id` int(11) DEFAULT NULL,
  `approved_by_id` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0->created 1->approved 2->reject 3->close 4-> po_created',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0->not approved 1->approved',
  `save_to_draft` int(1) NOT NULL DEFAULT '2' COMMENT '1->save to draft 2->save',
  PRIMARY KEY (`id`),
  KEY `fk_indent_1_idx` (`requisition_id`),
  KEY `fk_indent_3_idx` (`approved_by_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `indent`
--

INSERT INTO `indent` (`id`, `requisition_id`, `registered_on`, `indent_no`, `requested_by_id`, `verified_by_id`, `approved_by_id`, `status`, `created_on`, `is_approved`, `save_to_draft`) VALUES
(1, 1, '2017-12-22 06:27:03', 1, NULL, NULL, NULL, 3, '2017-12-22 06:27:03', 0, 2),
(2, 2, '2017-12-22 06:33:32', 2, NULL, NULL, NULL, 4, '2017-12-22 06:33:32', 0, 2),
(3, 3, '2017-12-22 07:23:11', 3, NULL, NULL, NULL, 4, '2017-12-22 07:23:11', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `indent_current_state`
--

CREATE TABLE IF NOT EXISTS `indent_current_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indent_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `indent_current_state`
--

INSERT INTO `indent_current_state` (`id`, `indent_id`, `state_id`, `employee_id`, `created_on`) VALUES
(1, 1, 1, 5, '2017-12-22 06:27:03'),
(2, 1, 2, 4, '2017-12-22 06:27:23'),
(3, 1, 3, 2, '2017-12-22 06:27:48'),
(4, 1, 4, 11, '2017-12-22 06:28:02'),
(5, 2, 1, 4, '2017-12-22 06:33:32'),
(6, 2, 2, 4, '2017-12-22 06:33:46'),
(7, 2, 3, 2, '2017-12-22 06:33:59'),
(8, 2, 4, 11, '2017-12-22 06:34:13'),
(9, 3, 1, 5, '2017-12-22 07:23:12'),
(10, 3, 2, 4, '2017-12-22 07:24:27'),
(11, 3, 3, 2, '2017-12-22 07:24:44'),
(12, 3, 4, 11, '2017-12-22 07:31:08');

-- --------------------------------------------------------

--
-- Table structure for table `indent_files`
--

CREATE TABLE IF NOT EXISTS `indent_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indent_id` int(11) NOT NULL,
  `file` text,
  `original_name` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `indent_items`
--

CREATE TABLE IF NOT EXISTS `indent_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indent_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `quantity_requested` int(11) NOT NULL,
  `quantity_approved` int(11) NOT NULL,
  `previous_purchase_rate` float(11,2) DEFAULT NULL,
  `place_of_use` varchar(50) DEFAULT NULL,
  `remarks` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_indent_items_1_idx` (`indent_id`),
  KEY `fk_indent_items_2_idx` (`material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `indent_items`
--

INSERT INTO `indent_items` (`id`, `indent_id`, `material_id`, `equipment_id`, `quantity_requested`, `quantity_approved`, `previous_purchase_rate`, `place_of_use`, `remarks`, `created_on`) VALUES
(1, 1, 8, NULL, 1500, 1500, 0.00, 'hbdfsj', 'JCVNK', '2017-12-22 06:27:03'),
(2, 1, 9, NULL, 1000, 1000, 0.00, 'sdafkjsd', 'kljvgl', '2017-12-22 06:27:03'),
(3, 2, 8, NULL, 500, 500, 0.00, 'dsfj', 'kjdsvhf', '2017-12-22 06:33:32'),
(4, 2, 9, NULL, 1000, 1000, 0.00, 'sdfkjh`', 'dksfj', '2017-12-22 06:33:32'),
(5, 3, 10, NULL, 1000, 1000, 0.00, 'dsfkjs', 'kjdsnfkjs', '2017-12-22 07:23:11'),
(6, 3, 15, NULL, 2000, 2000, 0.00, 'asfk', 'klasdf', '2017-12-22 07:23:12');

-- --------------------------------------------------------

--
-- Table structure for table `indent_po_mapping`
--

CREATE TABLE IF NOT EXISTS `indent_po_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `indent_id` int(11) NOT NULL,
  `po_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `indent_state`
--

CREATE TABLE IF NOT EXISTS `indent_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indent_state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `indent_state`
--

INSERT INTO `indent_state` (`id`, `indent_state`) VALUES
(1, 'create'),
(2, 'checked'),
(3, 'verify'),
(4, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `indent_state_mapping`
--

CREATE TABLE IF NOT EXISTS `indent_state_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `next_state_id` int(11) NOT NULL,
  `next_role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `indent_state_mapping`
--

INSERT INTO `indent_state_mapping` (`id`, `state`, `role_id`, `next_state_id`, `next_role_id`) VALUES
(1, 1, 3, 2, 4),
(2, 2, 4, 3, 5),
(3, 3, 5, 4, 6),
(4, 4, 6, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `indent_track`
--

CREATE TABLE IF NOT EXISTS `indent_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indent_id` int(11) NOT NULL,
  `status` enum('indent_created','indent_approved','indent_rejected','indent_RFI','po_created','po_approved','po_rejected','mrn_created','po_issued','mrn_partially_generated') NOT NULL,
  `employee_id` int(11) NOT NULL,
  `comment` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `indent_track`
--

INSERT INTO `indent_track` (`id`, `indent_id`, `status`, `employee_id`, `comment`, `created_on`) VALUES
(1, 1, 'indent_created', 5, NULL, '2017-12-22 06:27:03'),
(2, 1, 'indent_approved', 4, NULL, '2017-12-22 06:27:23'),
(3, 1, 'indent_approved', 2, NULL, '2017-12-22 06:27:48'),
(4, 1, 'indent_approved', 11, NULL, '2017-12-22 06:28:02'),
(5, 1, 'po_created', 7, NULL, '2017-12-22 06:29:41'),
(6, 1, 'po_approved', 8, NULL, '2017-12-22 06:30:05'),
(7, 1, 'po_issued', 7, NULL, '2017-12-22 06:30:27'),
(8, 1, 'mrn_created', 5, NULL, '2017-12-22 06:31:10'),
(9, 2, 'indent_created', 4, NULL, '2017-12-22 06:33:32'),
(10, 2, 'indent_approved', 4, NULL, '2017-12-22 06:33:46'),
(11, 2, 'indent_approved', 2, NULL, '2017-12-22 06:33:59'),
(12, 2, 'indent_approved', 11, NULL, '2017-12-22 06:34:13'),
(13, 2, 'po_created', 7, NULL, '2017-12-22 06:35:48'),
(14, 2, 'po_approved', 8, NULL, '2017-12-22 06:36:10'),
(15, 2, 'po_issued', 7, NULL, '2017-12-22 06:36:34'),
(16, 2, 'mrn_partially_generated', 4, NULL, '2017-12-22 06:37:33'),
(17, 2, 'mrn_created', 4, NULL, '2017-12-22 06:39:55'),
(18, 3, 'indent_created', 5, NULL, '2017-12-22 07:23:12'),
(19, 3, 'indent_approved', 4, NULL, '2017-12-22 07:24:27'),
(20, 3, 'indent_approved', 2, NULL, '2017-12-22 07:24:44'),
(21, 3, 'indent_approved', 11, NULL, '2017-12-22 07:31:08'),
(22, 3, 'po_created', 7, NULL, '2017-12-22 07:34:09'),
(23, 3, 'po_approved', 8, NULL, '2017-12-22 07:34:43'),
(24, 3, 'po_issued', 7, NULL, '2017-12-22 07:35:32'),
(25, 3, 'mrn_created', 5, NULL, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `code`, `created_on`) VALUES
(1, 'Delhi', '32543', '2017-10-04 11:53:07'),
(2, 'Haryana', '10098', '2017-10-04 11:53:07');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE IF NOT EXISTS `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_group_id` int(11) DEFAULT NULL,
  `material_sub_group_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `material_name` varchar(255) DEFAULT NULL,
  `specifications` text,
  `descriptions` text,
  `part_no` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `loss_percentage` float(6,2) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `rate` float(11,2) DEFAULT NULL,
  `value` varchar(35) DEFAULT NULL,
  `material_type_id` int(11) NOT NULL COMMENT '1->civil,2->mechanical,3->hr',
  `company_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `hsn_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_material_1_idx` (`material_group_id`),
  KEY `fk_material_unit_id_idx` (`unit_id`),
  KEY `fk_material_mat_type_idx` (`material_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=668 ;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`id`, `material_group_id`, `material_sub_group_id`, `equipment_id`, `material_name`, `specifications`, `descriptions`, `part_no`, `product_code`, `loss_percentage`, `unit_id`, `brand`, `quantity`, `rate`, `value`, `material_type_id`, `company_id`, `created_on`, `status`, `hsn_code`) VALUES
(1, 1, 2, NULL, 'Bitumen-85/25', '', NULL, NULL, 'NKC/CE/Bi/1', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:12', 1, NULL),
(2, 1, 2, NULL, 'Bitumen VG -30', '', NULL, NULL, 'NKC/CE/Bi/2', NULL, 5, NULL, 10, 0.00, '0', 1, 1, '2017-12-21 11:50:12', 1, NULL),
(3, 1, 2, NULL, 'Bitumen VG-10', '', NULL, NULL, 'NKC/CE/Bi/3', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:12', 1, NULL),
(4, 1, 2, NULL, 'CRMB', '', NULL, NULL, 'NKC/CE/CR/4', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:12', 1, NULL),
(5, 1, 3, NULL, 'Boulder', '', NULL, NULL, 'NKC/CE/Bo/5', NULL, 5, NULL, 20, 0.00, '0', 1, 1, '2017-12-21 11:50:12', 1, NULL),
(6, 1, 4, NULL, 'Emulssion SS1', '', NULL, NULL, 'NKC/CE/Em/6', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:13', 1, NULL),
(7, 1, 4, NULL, 'Emulssion RS1', '', NULL, NULL, 'NKC/CE/Em/7', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:13', 1, NULL),
(8, 1, 5, NULL, 'Aggregate 10mm', '', NULL, NULL, 'NKC/CE/Ag/8', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:13', 1, NULL),
(9, 1, 5, NULL, 'Aggregate 20mm', '', NULL, NULL, 'NKC/CE/Ag/9', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:13', 1, NULL),
(10, 1, 5, NULL, 'Aggregate 40mm', '', NULL, NULL, 'NKC/CE/Ag/10', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:13', 1, NULL),
(11, 1, 5, NULL, 'Aggregate 27mm', '', NULL, NULL, 'NKC/CE/Ag/11', NULL, 5, NULL, 20, 0.00, '0', 1, 1, '2017-12-21 11:50:13', 1, NULL),
(12, 1, 6, NULL, 'GSB', '', NULL, NULL, 'NKC/CE/GS/12', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:14', 1, NULL),
(13, 1, 7, NULL, 'Sand', '', NULL, NULL, 'NKC/CE/Sa/13', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:14', 1, NULL),
(14, 1, 8, NULL, 'Stone Dust', '', NULL, NULL, 'NKC/CE/St/14', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:14', 1, NULL),
(15, 1, 9, NULL, 'Admixture Auramix 300', '', NULL, NULL, 'NKC/CE/Ad/15', NULL, 1, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:14', 1, NULL),
(16, 1, 9, NULL, 'Admixture conplast', '', NULL, NULL, 'NKC/CE/Ad/16', NULL, 1, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:14', 1, NULL),
(17, 1, 9, NULL, 'Admixture Sikamet P14', '', NULL, NULL, 'NKC/CE/Ad/17', NULL, 1, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:15', 1, NULL),
(18, 1, 10, NULL, 'Cement 43 Grade', '', NULL, NULL, 'NKC/CE/Ce/18', NULL, 6, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:15', 1, NULL),
(19, 1, 10, NULL, 'Cement 53 Grade', '', NULL, NULL, 'NKC/CE/Ce/19', NULL, 6, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:15', 1, NULL),
(20, 1, 11, NULL, 'TMT 08mm', '', NULL, NULL, 'NKC/CE/TM/20', NULL, 5, NULL, 10, 0.00, '0', 1, 1, '2017-12-21 11:50:15', 1, NULL),
(21, 1, 11, NULL, 'TMT 10mm', '', NULL, NULL, 'NKC/CE/TM/21', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:15', 1, NULL),
(22, 1, 11, NULL, 'TMT 12mm', '', NULL, NULL, 'NKC/CE/TM/22', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:15', 1, NULL),
(23, 1, 11, NULL, 'TMT 16mm', '', NULL, NULL, 'NKC/CE/TM/23', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:16', 1, NULL),
(24, 1, 11, NULL, 'TMT 20mm', '', NULL, NULL, 'NKC/CE/TM/24', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:16', 1, NULL),
(25, 1, 11, NULL, 'TMT 25mm', '', NULL, NULL, 'NKC/CE/TM/25', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:16', 1, NULL),
(26, 1, 11, NULL, 'TMT 32mm', '', NULL, NULL, 'NKC/CE/TM/26', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:16', 1, NULL),
(27, 1, 11, NULL, 'MS Scarp', '', NULL, NULL, 'NKC/CE/MS/27', NULL, 5, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:16', 1, NULL),
(28, 1, 12, NULL, 'RCC Hume Pipe 1200x2.5mtr', '', NULL, NULL, 'NKC/CE/RC/28', NULL, 7, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:17', 1, NULL),
(29, 1, 12, NULL, 'RCC Hume Pipe 1800x1.5mtr', '', NULL, NULL, 'NKC/CE/RC/29', NULL, 7, NULL, 0, 0.00, '0', 1, 1, '2017-12-21 11:50:17', 1, NULL),
(30, 13, 14, NULL, 'Bed 3.5''X6.5''', '', NULL, NULL, 'NKC/HR/Be/30', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:02', 1, NULL),
(31, 13, 14, NULL, 'Bed 4''X6.5''', '', NULL, NULL, 'NKC/HR/Be/31', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:02', 1, NULL),
(32, 13, 14, NULL, 'Bed Doble Decor Cot', '', NULL, NULL, 'NKC/HR/Be/32', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:03', 1, NULL),
(33, 13, 14, NULL, 'Bed Wrought Iron', '', NULL, NULL, 'NKC/HR/Be/33', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:03', 1, NULL),
(34, 13, 14, NULL, 'Carpet', '', NULL, NULL, 'NKC/HR/Ca/34', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:03', 1, NULL),
(35, 13, 14, NULL, 'CARRY BAG', '', NULL, NULL, 'NKC/HR/CA/35', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:03', 1, NULL),
(36, 13, 14, NULL, 'COFESET', '', NULL, NULL, 'NKC/HR/CO/36', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:04', 1, NULL),
(37, 13, 14, NULL, 'Dining Table PVC', '', NULL, NULL, 'NKC/HR/Di/37', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:04', 1, NULL),
(38, 13, 14, NULL, 'Dining Table PVC BIg', '', NULL, NULL, 'NKC/HR/Di/38', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:04', 1, NULL),
(39, 13, 14, NULL, 'Dining Table Set', '', NULL, NULL, 'NKC/HR/Di/39', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:04', 1, NULL),
(40, 13, 14, NULL, 'Door Mat', '', NULL, NULL, 'NKC/HR/Do/40', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:04', 1, NULL),
(41, 13, 14, NULL, 'Executive Chair with Arm', '', NULL, NULL, 'NKC/HR/Ex/41', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:05', 1, NULL),
(42, 13, 14, NULL, 'Folding Bed 6''x3''', '', NULL, NULL, 'NKC/HR/Fo/42', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:05', 1, NULL),
(43, 13, 14, NULL, 'HOMECROCKER', '', NULL, NULL, 'NKC/HR/HO/43', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:05', 1, NULL),
(44, 13, 14, NULL, 'Jug(Steel)', '', NULL, NULL, 'NKC/HR/Ju/44', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:05', 1, NULL),
(45, 13, 14, NULL, 'Karai (Alumunium)', '', NULL, NULL, 'NKC/HR/Ka/45', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:05', 1, NULL),
(46, 13, 14, NULL, 'Mattress 78x48x3''''', '', NULL, NULL, 'NKC/HR/Ma/46', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:05', 1, NULL),
(47, 13, 14, NULL, 'Mosquito Net', '', NULL, NULL, 'NKC/HR/Mo/47', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(48, 13, 14, NULL, 'Plastic Bucket', '', NULL, NULL, 'NKC/HR/Pl/48', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(49, 13, 14, NULL, 'Plastic Table', '', NULL, NULL, 'NKC/HR/Pl/49', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(50, 13, 14, NULL, 'PVC Chair', '', NULL, NULL, 'NKC/HR/PV/50', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(51, 13, 14, NULL, 'Quilt Cover', '', NULL, NULL, 'NKC/HR/Qu/51', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(52, 13, 14, NULL, 'Rewalving Chair with Arm', '', NULL, NULL, 'NKC/HR/Re/52', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(53, 13, 14, NULL, 'Room Blower (Heat)', '', NULL, NULL, 'NKC/HR/Ro/53', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:06', 1, NULL),
(54, 13, 14, NULL, 'Samsung Galaxy Star-02 Mobile', '', NULL, NULL, 'NKC/HR/Sa/54', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(55, 13, 14, NULL, 'Sofa Set', '', NULL, NULL, 'NKC/HR/So/55', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(56, 13, 14, NULL, 'Steel Thalli', '', NULL, NULL, 'NKC/HR/St/56', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(57, 13, 14, NULL, 'Table 2.5x4''''', '', NULL, NULL, 'NKC/HR/Ta/57', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(58, 13, 14, NULL, 'Table for Manager', '', NULL, NULL, 'NKC/HR/Ta/58', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(59, 13, 14, NULL, 'Table for Office', '', NULL, NULL, 'NKC/HR/Ta/59', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(60, 13, 14, NULL, 'VISION GLASS', '', NULL, NULL, 'NKC/HR/VI/60', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(61, 13, 15, NULL, 'Absolate Viscocity Tube(Qc)', '', NULL, NULL, 'NKC/HR/Ab/61', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(62, 13, 15, NULL, 'Absoultc Viscometer', '', NULL, NULL, 'NKC/HR/Ab/62', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(63, 13, 15, NULL, 'Aggregate Impect VAlve', '', NULL, NULL, 'NKC/HR/Ag/63', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(64, 13, 15, NULL, 'AIV CAP', '', NULL, NULL, 'NKC/HR/AI/64', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(65, 13, 15, NULL, 'AIV Machine', '', NULL, NULL, 'NKC/HR/AI/65', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(66, 13, 15, NULL, 'Alterberg Machine', '', NULL, NULL, 'NKC/HR/Al/66', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(67, 13, 15, NULL, 'Aluminium Sieves', '', NULL, NULL, 'NKC/HR/Al/67', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(68, 13, 15, NULL, 'Appartus Softing Point', '', NULL, NULL, 'NKC/HR/Ap/68', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:07', 1, NULL),
(69, 13, 15, NULL, 'AT-134-1 Flexural Beam Streangth Testing (QC)', '', NULL, NULL, 'NKC/HR/AT/69', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(70, 13, 15, NULL, 'AT-174 Vibratory Hammer Electrically Opreated (QC )', '', NULL, NULL, 'NKC/HR/AT/70', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(71, 13, 15, NULL, 'Balance Counter (Pan Ball 30Kgs)', '', NULL, NULL, 'NKC/HR/Ba/71', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(72, 13, 15, NULL, 'Balance Machanical Cap20Kg', '', NULL, NULL, 'NKC/HR/Ba/72', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(73, 13, 15, NULL, 'Beaker 600ml Cap', '', NULL, NULL, 'NKC/HR/Be/73', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(74, 13, 15, NULL, 'Beam Mould D.60X10X15cum', '', NULL, NULL, 'NKC/HR/Be/74', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(75, 13, 15, NULL, 'Beam Mould D.75X15X15cum', '', NULL, NULL, 'NKC/HR/Be/75', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(76, 13, 15, NULL, 'BItumen Extactor', '', NULL, NULL, 'NKC/HR/BI/76', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(77, 13, 15, NULL, 'BItumen Pentrometer Electocity', '', NULL, NULL, 'NKC/HR/BI/77', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(78, 13, 15, NULL, 'Borosil 1000ml', '', NULL, NULL, 'NKC/HR/Bo/78', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(79, 13, 15, NULL, 'Borosil 100ml', '', NULL, NULL, 'NKC/HR/Bo/79', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(80, 13, 15, NULL, 'Borosil 250ml', '', NULL, NULL, 'NKC/HR/Bo/80', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(81, 13, 15, NULL, 'Brass Sieves', '', NULL, NULL, 'NKC/HR/Br/81', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:08', 1, NULL),
(82, 13, 15, NULL, 'Breaking Head ( Lab Instrument)', '', NULL, NULL, 'NKC/HR/Br/82', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(83, 13, 15, NULL, 'Bull Dencity Cly 5-1', '', NULL, NULL, 'NKC/HR/Bu/83', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(84, 13, 15, NULL, 'CBR Displacer Disk 5kgs', '', NULL, NULL, 'NKC/HR/CB/84', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(85, 13, 15, NULL, 'CBR Machine', '', NULL, NULL, 'NKC/HR/CB/85', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(86, 13, 15, NULL, 'CBR Mould', '', NULL, NULL, 'NKC/HR/CB/86', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(87, 13, 15, NULL, 'CBR Perforated Plate', '', NULL, NULL, 'NKC/HR/CB/87', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(88, 13, 15, NULL, 'Cbr Plunger', '', NULL, NULL, 'NKC/HR/Cb/88', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(89, 13, 15, NULL, 'CBR Rammer 4.89 Kg', '', NULL, NULL, 'NKC/HR/CB/89', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(90, 13, 15, NULL, 'CBR Slotted/Annual Weight', '', NULL, NULL, 'NKC/HR/CB/90', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:09', 1, NULL),
(91, 13, 15, NULL, 'CBR Surcharge Slotted Weight 2.5Kgs', '', NULL, NULL, 'NKC/HR/CB/91', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:10', 1, NULL),
(92, 13, 15, NULL, 'Cointainer Small', '', NULL, NULL, 'NKC/HR/Co/92', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:10', 1, NULL),
(93, 13, 15, NULL, 'Compectiom Mould 100cc', '', NULL, NULL, 'NKC/HR/Co/93', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:10', 1, NULL),
(94, 13, 15, NULL, 'Cone BIt 100mm', '', NULL, NULL, 'NKC/HR/Co/94', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:10', 1, NULL),
(95, 13, 15, NULL, 'Cone Pentrometer', '', NULL, NULL, 'NKC/HR/Co/95', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:10', 1, NULL),
(96, 13, 15, NULL, 'Core BIt 100mm', '', NULL, NULL, 'NKC/HR/Co/96', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(97, 13, 15, NULL, 'Core Cutter With Dolly & HAmmer 100mm', '', NULL, NULL, 'NKC/HR/Co/97', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(98, 13, 15, NULL, 'Core Cutting Machine', '', NULL, NULL, 'NKC/HR/Co/98', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(99, 13, 15, NULL, 'Cube Mould 100mm', '', NULL, NULL, 'NKC/HR/Cu/99', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(100, 13, 15, NULL, 'Cube Mould 150X150X150 Cm', '', NULL, NULL, 'NKC/HR/Cu/100', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(101, 13, 15, NULL, 'Cube Mould 50X50X50 Cm', '', NULL, NULL, 'NKC/HR/Cu/101', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(102, 13, 15, NULL, 'Cube Mould 7.06X7.06X7.06 Cm', '', NULL, NULL, 'NKC/HR/Cu/102', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:11', 1, NULL),
(103, 13, 15, NULL, 'Cube Mould 70X70X70 cm', '', NULL, NULL, 'NKC/HR/Cu/103', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(104, 13, 15, NULL, 'Cube Testing Machine', '', NULL, NULL, 'NKC/HR/Cu/104', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(105, 13, 15, NULL, 'Cube Vibrator Machine', '', NULL, NULL, 'NKC/HR/Cu/105', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(106, 13, 15, NULL, 'DBM Mixture Machine', '', NULL, NULL, 'NKC/HR/DB/106', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(107, 13, 15, NULL, 'Depth Gaudge', '', NULL, NULL, 'NKC/HR/De/107', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(108, 13, 15, NULL, 'Digital Load Disply (Repair QC Item)', '', NULL, NULL, 'NKC/HR/Di/108', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(109, 13, 15, NULL, 'Direct Shear Test Machine', '', NULL, NULL, 'NKC/HR/Di/109', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(110, 13, 15, NULL, 'Ducting Machine Ductility Test Apparatus', '', NULL, NULL, 'NKC/HR/Du/110', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(111, 13, 15, NULL, 'Ducting Mould', '', NULL, NULL, 'NKC/HR/Du/111', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(112, 13, 15, NULL, 'Elctronic Balance 15kgs', '', NULL, NULL, 'NKC/HR/El/112', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(113, 13, 15, NULL, 'Elecronic Balance 75kg', '', NULL, NULL, 'NKC/HR/El/113', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(114, 13, 15, NULL, 'Electonic Balance 15kgs', '', NULL, NULL, 'NKC/HR/El/114', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(115, 13, 15, NULL, 'Electronic Balance .002grm TO 30kgs', '', NULL, NULL, 'NKC/HR/El/115', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(116, 13, 15, NULL, 'Electronic Balance 10kgs', '', NULL, NULL, 'NKC/HR/El/116', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(117, 13, 15, NULL, 'Electronic Balance 20kgs', '', NULL, NULL, 'NKC/HR/El/117', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(118, 13, 15, NULL, 'Electronic Balance 30kgs', '', NULL, NULL, 'NKC/HR/El/118', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(119, 13, 15, NULL, 'Electronic Balance 3kgs', '', NULL, NULL, 'NKC/HR/El/119', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(120, 13, 15, NULL, 'Electronic Balance .500grm TO 1kgs', '', NULL, NULL, 'NKC/HR/El/120', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:12', 1, NULL),
(121, 13, 15, NULL, 'Electronic Balance 5kgs', '', NULL, NULL, 'NKC/HR/El/121', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(122, 13, 15, NULL, 'Electronic Balance 600grm', '', NULL, NULL, 'NKC/HR/El/122', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(123, 13, 15, NULL, 'Electronic Balance 600grm To 10mg', '', NULL, NULL, 'NKC/HR/El/123', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(124, 13, 15, NULL, 'Electronic Balance 7.5kgs', '', NULL, NULL, 'NKC/HR/El/124', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(125, 13, 15, NULL, 'Electronic Recovery Mould', '', NULL, NULL, 'NKC/HR/El/125', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(126, 13, 15, NULL, 'Element (Qc Lab )', '', NULL, NULL, 'NKC/HR/El/126', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(127, 13, 15, NULL, 'Fine Valve Test Appartus', '', NULL, NULL, 'NKC/HR/Fi/127', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(128, 13, 15, NULL, 'Fine Valve Test Appartus 10%', '', NULL, NULL, 'NKC/HR/Fi/128', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(129, 13, 15, NULL, 'Flank Ness Gaudge', '', NULL, NULL, 'NKC/HR/Fl/129', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(130, 13, 15, NULL, 'Flash Point Test Appartus', '', NULL, NULL, 'NKC/HR/Fl/130', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(131, 13, 15, NULL, 'Flexune Testing Attachedment', '', NULL, NULL, 'NKC/HR/Fl/131', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(132, 13, 15, NULL, 'GI Try 18''''X24''''', '', NULL, NULL, 'NKC/HR/GI/132', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(133, 13, 15, NULL, 'GI Try 26''''X36''''', '', NULL, NULL, 'NKC/HR/GI/133', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(134, 13, 15, NULL, 'GI Try 8''''X12''''', '', NULL, NULL, 'NKC/HR/GI/134', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:13', 1, NULL),
(135, 13, 15, NULL, 'GI Try Small & Big', '', NULL, NULL, 'NKC/HR/GI/135', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(136, 13, 15, NULL, 'Hammer', '', NULL, NULL, 'NKC/HR/Ha/136', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(137, 13, 15, NULL, 'Heater', '', NULL, NULL, 'NKC/HR/He/137', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(138, 13, 15, NULL, 'Hote Plate 200wattX150mm Dia', '', NULL, NULL, 'NKC/HR/Ho/138', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(139, 13, 15, NULL, 'Hydro Meter Heavey Liquid 1000-1500', '', NULL, NULL, 'NKC/HR/Hy/139', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(140, 13, 15, NULL, 'Hydro Meter (Rang .0095 to 1.030', '', NULL, NULL, 'NKC/HR/Hy/140', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(141, 13, 15, NULL, 'Hydroulic Extractor', '', NULL, NULL, 'NKC/HR/Hy/141', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(142, 13, 15, NULL, 'INFRA RED THERMOMETER (QC LAB)', '', NULL, NULL, 'NKC/HR/IN/142', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(143, 13, 15, NULL, 'Kinematic Visocity Tube(Qc)', '', NULL, NULL, 'NKC/HR/Ki/143', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(144, 13, 15, NULL, 'Le Chattlier Test Appartus Sound Less', '', NULL, NULL, 'NKC/HR/Le/144', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(145, 13, 15, NULL, 'Liquid Limit Divice Hand Opt', '', NULL, NULL, 'NKC/HR/Li/145', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:14', 1, NULL),
(146, 13, 15, NULL, 'Liquid Limit with Counter', '', NULL, NULL, 'NKC/HR/Li/146', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(147, 13, 15, NULL, 'Loss Angeles  Abrasion Testing Machine', '', NULL, NULL, 'NKC/HR/Lo/147', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(148, 13, 15, NULL, 'Loss on Heating Appartus', '', NULL, NULL, 'NKC/HR/Lo/148', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(149, 13, 15, NULL, 'March Cone Viscometer', '', NULL, NULL, 'NKC/HR/Ma/149', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(150, 13, 15, NULL, 'Marshall Cly 100ml', '', NULL, NULL, 'NKC/HR/Ma/150', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(151, 13, 15, NULL, 'Marshall Hammer', '', NULL, NULL, 'NKC/HR/Ma/151', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(152, 13, 15, NULL, 'Marshall Moud with Coller', '', NULL, NULL, 'NKC/HR/Ma/152', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(153, 13, 15, NULL, 'Marshall Mould 150mm Dia', '', NULL, NULL, 'NKC/HR/Ma/153', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(154, 13, 15, NULL, 'Marshall Mould with Coller 100mm', '', NULL, NULL, 'NKC/HR/Ma/154', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(155, 13, 15, NULL, 'Marshall Mould with Coller 150mm', '', NULL, NULL, 'NKC/HR/Ma/155', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:15', 1, NULL),
(156, 13, 15, NULL, 'Marshall Pedestal Machine', '', NULL, NULL, 'NKC/HR/Ma/156', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(157, 13, 15, NULL, 'Marshall Rammer 150mm', '', NULL, NULL, 'NKC/HR/Ma/157', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(158, 13, 15, NULL, 'Mashall Stabiliy Test Appartus', '', NULL, NULL, 'NKC/HR/Ma/158', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(159, 13, 15, NULL, 'Mashall Testing Machine', '', NULL, NULL, 'NKC/HR/Ma/159', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(160, 13, 15, NULL, 'Matel Measur Set Density Bucket 15ltr to 381ltr', '', NULL, NULL, 'NKC/HR/Ma/160', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(161, 13, 15, NULL, 'MDD Mould 1000cc', '', NULL, NULL, 'NKC/HR/MD/161', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(162, 13, 15, NULL, 'Mechanical Balance 5kgs', '', NULL, NULL, 'NKC/HR/Me/162', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(163, 13, 15, NULL, 'Mesuring Cylinder', '', NULL, NULL, 'NKC/HR/Me/163', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:16', 1, NULL),
(164, 13, 15, NULL, 'Moisture Tins 75mm Dia 50mm Lenth', '', NULL, NULL, 'NKC/HR/Mo/164', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:17', 1, NULL),
(165, 13, 15, NULL, 'Motor Cube Casing Machine', '', NULL, NULL, 'NKC/HR/Mo/165', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:17', 1, NULL),
(166, 13, 15, NULL, 'Motor Fan Testing Instrument', '', NULL, NULL, 'NKC/HR/Mo/166', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:17', 1, NULL),
(167, 13, 15, NULL, 'Mould Lever', '', NULL, NULL, 'NKC/HR/Mo/167', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:17', 1, NULL),
(168, 13, 15, NULL, 'Niddle for Bitumen Pentrometer', '', NULL, NULL, 'NKC/HR/Ni/168', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:17', 1, NULL),
(169, 13, 15, NULL, 'Oven Machine 18''''X18''''X18''''', '', NULL, NULL, 'NKC/HR/Ov/169', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:17', 1, NULL),
(170, 13, 15, NULL, 'Oven Machine 36''''X36''''X36''''', '', NULL, NULL, 'NKC/HR/Ov/170', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(171, 13, 15, NULL, 'Perfected Plate with Stand', '', NULL, NULL, 'NKC/HR/Pe/171', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(172, 13, 15, NULL, 'Plastik Hammer', '', NULL, NULL, 'NKC/HR/Pl/172', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(173, 13, 15, NULL, 'Plastik Limit Appartus', '', NULL, NULL, 'NKC/HR/Pl/173', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(174, 13, 15, NULL, 'Plateform Balance 300kgs', '', NULL, NULL, 'NKC/HR/Pl/174', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(175, 13, 15, NULL, 'Poring Ring 50kn', '', NULL, NULL, 'NKC/HR/Po/175', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(176, 13, 15, NULL, 'Primier Try', '', NULL, NULL, 'NKC/HR/Pr/176', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:18', 1, NULL),
(177, 13, 15, NULL, 'Protector Hammer', '', NULL, NULL, 'NKC/HR/Pr/177', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:19', 1, NULL),
(178, 13, 15, NULL, 'Proving Ring Qc Lab (Repaired)', '', NULL, NULL, 'NKC/HR/Pr/178', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:19', 1, NULL),
(179, 13, 15, NULL, 'Pvc Measuring Cly 100ml', '', NULL, NULL, 'NKC/HR/Pv/179', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:19', 1, NULL),
(180, 13, 15, NULL, 'Pyconmeter', '', NULL, NULL, 'NKC/HR/Py/180', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:19', 1, NULL),
(181, 13, 15, NULL, 'Rain Gaudge Cly 20mm', '', NULL, NULL, 'NKC/HR/Ra/181', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:19', 1, NULL),
(182, 13, 15, NULL, 'Rain Gaudge Non Recoreling Wish Brass Ring', '', NULL, NULL, 'NKC/HR/Ra/182', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:19', 1, NULL),
(183, 13, 15, NULL, 'Rapid Moisture Meter', '', NULL, NULL, 'NKC/HR/Ra/183', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:20', 1, NULL),
(184, 13, 15, NULL, 'Riffile Box', '', NULL, NULL, 'NKC/HR/Ri/184', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:20', 1, NULL),
(185, 13, 15, NULL, 'Ring & Ballappartus', '', NULL, NULL, 'NKC/HR/Ri/185', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:20', 1, NULL),
(186, 13, 15, NULL, 'Sand Bags Grade 1', '', NULL, NULL, 'NKC/HR/Sa/186', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:20', 1, NULL),
(187, 13, 15, NULL, 'Sand Bags Grade 2', '', NULL, NULL, 'NKC/HR/Sa/187', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:20', 1, NULL),
(188, 13, 15, NULL, 'Sand Bags Grade 3', '', NULL, NULL, 'NKC/HR/Sa/188', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:21', 1, NULL),
(189, 13, 15, NULL, 'Sand Equipment Appartus', '', NULL, NULL, 'NKC/HR/Sa/189', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:21', 1, NULL),
(190, 13, 15, NULL, 'Sand Pouring Cly 100mm', '', NULL, NULL, 'NKC/HR/Sa/190', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:21', 1, NULL),
(191, 13, 15, NULL, 'Sand Pouring Cly 150mm', '', NULL, NULL, 'NKC/HR/Sa/191', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:21', 1, NULL),
(192, 13, 15, NULL, 'Sand Pouring Cly 200mm', '', NULL, NULL, 'NKC/HR/Sa/192', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:21', 1, NULL),
(193, 13, 15, NULL, 'Saybolt Surol', '', NULL, NULL, 'NKC/HR/Sa/193', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:22', 1, NULL),
(194, 13, 15, NULL, 'Scoop Small 1kgs', '', NULL, NULL, 'NKC/HR/Sc/194', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:22', 1, NULL),
(195, 13, 15, NULL, 'Scoop Small 2kgs', '', NULL, NULL, 'NKC/HR/Sc/195', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:22', 1, NULL),
(196, 13, 15, NULL, 'Sieve 200mm', '', NULL, NULL, 'NKC/HR/Si/196', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:22', 1, NULL),
(197, 13, 15, NULL, 'Sieve 300mm Dia', '', NULL, NULL, 'NKC/HR/Si/197', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:22', 1, NULL),
(198, 13, 15, NULL, 'Sieve 300mm Dia Bar', '', NULL, NULL, 'NKC/HR/Si/198', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:22', 1, NULL),
(199, 13, 15, NULL, 'Sieve 450mm Dia', '', NULL, NULL, 'NKC/HR/Si/199', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:23', 1, NULL),
(200, 13, 15, NULL, 'Sieve Brass 8''''X1.0mm', '', NULL, NULL, 'NKC/HR/Si/200', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:23', 1, NULL),
(201, 13, 15, NULL, 'Sieve Brass 8''''X1.18mm', '', NULL, NULL, 'NKC/HR/Si/201', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:23', 1, NULL),
(202, 13, 15, NULL, 'Sieve Brass 8''''X1.4mm', '', NULL, NULL, 'NKC/HR/Si/202', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:23', 1, NULL),
(203, 13, 15, NULL, 'Sieve Brass 8''''X150micron', '', NULL, NULL, 'NKC/HR/Si/203', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:23', 1, NULL),
(204, 13, 15, NULL, 'Sieve Brass 8''''X1.7mm', '', NULL, NULL, 'NKC/HR/Si/204', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:23', 1, NULL),
(205, 13, 15, NULL, 'Sieve Brass 8''''X180micron', '', NULL, NULL, 'NKC/HR/Si/205', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:24', 1, NULL),
(206, 13, 15, NULL, 'Sieve Brass 8''''X2.0mm', '', NULL, NULL, 'NKC/HR/Si/206', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:24', 1, NULL),
(207, 13, 15, NULL, 'Sieve Brass 8''''X2.36mm', '', NULL, NULL, 'NKC/HR/Si/207', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:24', 1, NULL),
(208, 13, 15, NULL, 'Sieve Brass 8''''X2.80mm', '', NULL, NULL, 'NKC/HR/Si/208', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:24', 1, NULL),
(209, 13, 15, NULL, 'Sieve Brass 8''''X300micron', '', NULL, NULL, 'NKC/HR/Si/209', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:24', 1, NULL),
(210, 13, 15, NULL, 'Sieve Brass 8''''X355micron', '', NULL, NULL, 'NKC/HR/Si/210', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:25', 1, NULL),
(211, 13, 15, NULL, 'Sieve Brass 8''''X425micron', '', NULL, NULL, 'NKC/HR/Si/211', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:25', 1, NULL),
(212, 13, 15, NULL, 'Sieve Brass 8''''X4.75mm', '', NULL, NULL, 'NKC/HR/Si/212', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:25', 1, NULL),
(213, 13, 15, NULL, 'Sieve Brass 8''''X600micron', '', NULL, NULL, 'NKC/HR/Si/213', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:25', 1, NULL),
(214, 13, 15, NULL, 'Sieve Brass 8''''X75micron', '', NULL, NULL, 'NKC/HR/Si/214', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:25', 1, NULL),
(215, 13, 15, NULL, 'Sieve Brass 8''''Xlid', '', NULL, NULL, 'NKC/HR/Si/215', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:26', 1, NULL),
(216, 13, 15, NULL, 'Sieve GI 18''''X11.02mm', '', NULL, NULL, 'NKC/HR/Si/216', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:26', 1, NULL),
(217, 13, 15, NULL, 'Sieve GI 18''''X12.05mm', '', NULL, NULL, 'NKC/HR/Si/217', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:26', 1, NULL),
(218, 13, 15, NULL, 'SIeve GI 18''''X14mm', '', NULL, NULL, 'NKC/HR/SI/218', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:26', 1, NULL),
(219, 13, 15, NULL, 'Sieve GI 18''''X19mm', '', NULL, NULL, 'NKC/HR/Si/219', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:26', 1, NULL),
(220, 13, 15, NULL, 'Sieve GI 18''''X22.04mm', '', NULL, NULL, 'NKC/HR/Si/220', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:26', 1, NULL),
(221, 13, 15, NULL, 'Sieve GI 18''''X25mm', '', NULL, NULL, 'NKC/HR/Si/221', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(222, 13, 15, NULL, 'Sieve GI 18''''X31.05mm', '', NULL, NULL, 'NKC/HR/Si/222', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(223, 13, 15, NULL, 'Sieve GI 18''''X4.07mm', '', NULL, NULL, 'NKC/HR/Si/223', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(224, 13, 15, NULL, 'Sieve GI 18''''X5.6mm', '', NULL, NULL, 'NKC/HR/Si/224', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(225, 13, 15, NULL, 'Sieve GI 18''''X6.3mm', '', NULL, NULL, 'NKC/HR/Si/225', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(226, 13, 15, NULL, 'Sieve GI 18''''X80mm', '', NULL, NULL, 'NKC/HR/Si/226', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(227, 13, 15, NULL, 'Sieve GI 18''''Xlid', '', NULL, NULL, 'NKC/HR/Si/227', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(228, 13, 15, NULL, 'Sieve GI 18''''Xpan', '', NULL, NULL, 'NKC/HR/Si/228', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(229, 13, 15, NULL, 'Sieve GI 4.75X300mm', '', NULL, NULL, 'NKC/HR/Si/229', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(230, 13, 15, NULL, 'Sieve GI 50.45X300mm', '', NULL, NULL, 'NKC/HR/Si/230', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(231, 13, 15, NULL, 'Sieves Brass 8''''X710micron', '', NULL, NULL, 'NKC/HR/Si/231', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(232, 13, 15, NULL, 'Sieve Shacker 18''''X450mm', '', NULL, NULL, 'NKC/HR/Si/232', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(233, 13, 15, NULL, 'Slamp Cone Rod', '', NULL, NULL, 'NKC/HR/Sl/233', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(234, 13, 15, NULL, 'Slump Rod', '', NULL, NULL, 'NKC/HR/Sl/234', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:27', 1, NULL),
(235, 13, 15, NULL, 'Slump Test Appartur 60cm Long', '', NULL, NULL, 'NKC/HR/Sl/235', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(236, 13, 15, NULL, 'Soil Testing Machine', '', NULL, NULL, 'NKC/HR/So/236', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(237, 13, 15, NULL, 'Spatula 8''''X1'''' with Handle', '', NULL, NULL, 'NKC/HR/Sp/237', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(238, 13, 15, NULL, 'Specer Disk', '', NULL, NULL, 'NKC/HR/Sp/238', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(239, 13, 15, NULL, 'Specific Gravity Bottle 100ml', '', NULL, NULL, 'NKC/HR/Sp/239', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(240, 13, 15, NULL, 'Specific Gravity Bottle 50ml', '', NULL, NULL, 'NKC/HR/Sp/240', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(241, 13, 15, NULL, 'Specific Gravity Bucket', '', NULL, NULL, 'NKC/HR/Sp/241', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(242, 13, 15, NULL, 'Standared Tar Viscometer', '', NULL, NULL, 'NKC/HR/St/242', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(243, 13, 15, NULL, 'Stating Edge 3mtr', '', NULL, NULL, 'NKC/HR/St/243', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(244, 13, 15, NULL, 'Stop Watch', '', NULL, NULL, 'NKC/HR/St/244', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(245, 13, 15, NULL, 'Straigh Edge Large 12''''', '', NULL, NULL, 'NKC/HR/St/245', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(246, 13, 15, NULL, 'Surcharge Weight Annular', '', NULL, NULL, 'NKC/HR/Su/246', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(247, 13, 15, NULL, 'Surcharge Weight Slotted', '', NULL, NULL, 'NKC/HR/Su/247', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(248, 13, 15, NULL, 'Tar Viscometer (Bitumen)', '', NULL, NULL, 'NKC/HR/Ta/248', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(249, 13, 15, NULL, 'Testing Insrumen Spare', '', NULL, NULL, 'NKC/HR/Te/249', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:28', 1, NULL),
(250, 13, 15, NULL, 'Testing Insrument Spare', '', NULL, NULL, 'NKC/HR/Te/250', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(251, 13, 15, NULL, 'Testing Instrumen Spare (Qc LAb)', '', NULL, NULL, 'NKC/HR/Te/251', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(252, 13, 15, NULL, 'Testing Instrument Spair Conical Flask 2000ml', '', NULL, NULL, 'NKC/HR/Te/252', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(253, 13, 15, NULL, 'Testing Instrument Spair Emulssion Viscometer 1206', '', NULL, NULL, 'NKC/HR/Te/253', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(254, 13, 15, NULL, 'Testing Instrument Spair Porcellan Pot 50mm', '', NULL, NULL, 'NKC/HR/Te/254', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(255, 13, 15, NULL, 'Testing Instrument Spair Rubber Mallet', '', NULL, NULL, 'NKC/HR/Te/255', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(256, 13, 15, NULL, 'Testing Instrument Spair Volumatric Flash 250ml', '', NULL, NULL, 'NKC/HR/Te/256', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(257, 13, 15, NULL, 'Testing Instrument Spair Volumatric Flask 50ml', '', NULL, NULL, 'NKC/HR/Te/257', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(258, 13, 15, NULL, 'Testing Instrument Spare', '', NULL, NULL, 'NKC/HR/Te/258', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(259, 13, 15, NULL, 'Thermo Hydro Clock', '', NULL, NULL, 'NKC/HR/Th/259', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(260, 13, 15, NULL, 'Thermometer Digital 0.300centi Grade', '', NULL, NULL, 'NKC/HR/Th/260', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:29', 1, NULL),
(261, 13, 15, NULL, 'Thermometer Glass', '', NULL, NULL, 'NKC/HR/Th/261', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(262, 13, 15, NULL, 'Thermometer Min & Max', '', NULL, NULL, 'NKC/HR/Th/262', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(263, 13, 15, NULL, 'Thermometer (Qc Lab)', '', NULL, NULL, 'NKC/HR/Th/263', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(264, 13, 15, NULL, 'Thin Film Oven', '', NULL, NULL, 'NKC/HR/Th/264', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(265, 13, 15, NULL, 'THIN FILM OVEN (QC LAB)', '', NULL, NULL, 'NKC/HR/TH/265', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(266, 13, 15, NULL, 'Vaccum Pump Elecrticity', '', NULL, NULL, 'NKC/HR/Va/266', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(267, 13, 15, NULL, 'Vernier Caliper 12'''' QC', '', NULL, NULL, 'NKC/HR/Ve/267', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(268, 13, 15, NULL, 'Vernier Caliper (QC)', '', NULL, NULL, 'NKC/HR/Ve/268', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(269, 13, 15, NULL, 'Vibrating Machine', '', NULL, NULL, 'NKC/HR/Vi/269', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(270, 13, 15, NULL, 'Vicat Niddle Appartus', '', NULL, NULL, 'NKC/HR/Vi/270', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:30', 1, NULL),
(271, 13, 15, NULL, 'Vicat Test Appartus', '', NULL, NULL, 'NKC/HR/Vi/271', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(272, 13, 15, NULL, 'Viscometer (IS 3117)', '', NULL, NULL, 'NKC/HR/Vi/272', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(273, 13, 15, NULL, 'Viscometer with Acce.', '', NULL, NULL, 'NKC/HR/Vi/273', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(274, 13, 15, NULL, 'Water Bath 16X10X25Cm', '', NULL, NULL, 'NKC/HR/Wa/274', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(275, 13, 15, NULL, 'Weight Box 100grm', '', NULL, NULL, 'NKC/HR/We/275', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(276, 13, 16, NULL, 'Air Conditioner 1.5 Ton Ac', '', NULL, NULL, 'NKC/HR/Ai/276', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(277, 13, 16, NULL, 'Almirah Steel', '', NULL, NULL, 'NKC/HR/Al/277', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(278, 13, 16, NULL, 'Almirah Steel 3/6', '', NULL, NULL, 'NKC/HR/Al/278', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:31', 1, NULL),
(279, 13, 16, NULL, 'Almirh 3/6 Big', '', NULL, NULL, 'NKC/HR/Al/279', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:32', 1, NULL),
(280, 13, 16, NULL, 'Attendance Register', '', NULL, NULL, 'NKC/HR/At/280', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:32', 1, NULL),
(281, 13, 16, NULL, 'Camera Sony', '', NULL, NULL, 'NKC/HR/Ca/281', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:32', 1, NULL),
(282, 13, 16, NULL, 'Ceiling Fan', '', NULL, NULL, 'NKC/HR/Ce/282', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:32', 1, NULL),
(283, 13, 16, NULL, 'Ceiling Fan 600 mm', '', NULL, NULL, 'NKC/HR/Ce/283', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:32', 1, NULL),
(284, 13, 16, NULL, 'Computer Set', '', NULL, NULL, 'NKC/HR/Co/284', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:32', 1, NULL),
(285, 13, 16, NULL, 'Container for Office', '', NULL, NULL, 'NKC/HR/Co/285', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:33', 1, NULL),
(286, 13, 16, NULL, 'Desktop Lenova HS 20-3559', '', NULL, NULL, 'NKC/HR/De/286', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:33', 1, NULL),
(287, 13, 16, NULL, 'Drinking Water Filter (Manual)', '', NULL, NULL, 'NKC/HR/Dr/287', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:33', 1, NULL),
(288, 13, 16, NULL, 'Exhaust Fan', '', NULL, NULL, 'NKC/HR/Ex/288', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:33', 1, NULL),
(289, 13, 16, NULL, 'Flexural Form Book', '', NULL, NULL, 'NKC/HR/Fl/289', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:33', 1, NULL),
(290, 13, 16, NULL, 'Hard Disk 500 GB', '', NULL, NULL, 'NKC/HR/Ha/290', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:34', 1, NULL),
(291, 13, 16, NULL, 'Laptop', '', NULL, NULL, 'NKC/HR/La/291', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:34', 1, NULL),
(292, 13, 16, NULL, 'Micro Phone', '', NULL, NULL, 'NKC/HR/Mi/292', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:34', 1, NULL),
(293, 13, 16, NULL, 'Mobile -Nokia', '', NULL, NULL, 'NKC/HR/Mo/293', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:34', 1, NULL),
(294, 13, 16, NULL, 'Modem 3G (Data Card )', '', NULL, NULL, 'NKC/HR/Mo/294', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:34', 1, NULL),
(295, 13, 16, NULL, 'Monitor for Computer', '', NULL, NULL, 'NKC/HR/Mo/295', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:35', 1, NULL),
(296, 13, 16, NULL, 'Mouse(PC)', '', NULL, NULL, 'NKC/HR/Mo/296', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:35', 1, NULL),
(297, 13, 16, NULL, 'MR Amplifier MDA650', '', NULL, NULL, 'NKC/HR/MR/297', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:35', 1, NULL),
(298, 13, 16, NULL, 'MR Unit', '', NULL, NULL, 'NKC/HR/MR/298', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:35', 1, NULL),
(299, 13, 16, NULL, 'Pendrive', '', NULL, NULL, 'NKC/HR/Pe/299', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:35', 1, NULL),
(300, 13, 16, NULL, 'Printer Dot Matrix Tvs', '', NULL, NULL, 'NKC/HR/Pr/300', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:35', 1, NULL),
(301, 13, 16, NULL, 'Printer Hp 1005 Leserjet', '', NULL, NULL, 'NKC/HR/Pr/301', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:36', 1, NULL),
(302, 13, 16, NULL, 'Printer HP1020 Laserjet', '', NULL, NULL, 'NKC/HR/Pr/302', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:36', 1, NULL),
(303, 13, 16, NULL, 'Printer HPinkjet', '', NULL, NULL, 'NKC/HR/Pr/303', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:36', 1, NULL),
(304, 13, 16, NULL, 'Printer-HP-M1136', '', NULL, NULL, 'NKC/HR/Pr/304', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:36', 1, NULL),
(305, 13, 16, NULL, 'Printer Samsung Ml108 Laserjet', '', NULL, NULL, 'NKC/HR/Pr/305', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:36', 1, NULL),
(306, 13, 16, NULL, 'Projector Machine', '', NULL, NULL, 'NKC/HR/Pr/306', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(307, 13, 16, NULL, 'Rack Steel', '', NULL, NULL, 'NKC/HR/Ra/307', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(308, 13, 16, NULL, 'Rack Steel 6/3''', '', NULL, NULL, 'NKC/HR/Ra/308', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(309, 13, 16, NULL, 'Refrigerator', '', NULL, NULL, 'NKC/HR/Re/309', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(310, 13, 16, NULL, 'RO Cant', '', NULL, NULL, 'NKC/HR/RO/310', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(311, 13, 16, NULL, 'Samsung Galaxy J7-2016', '', NULL, NULL, 'NKC/HR/Sa/311', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(312, 13, 16, NULL, 'Scaner Canon', '', NULL, NULL, 'NKC/HR/Sc/312', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(313, 13, 16, NULL, 'SOFTWARE TALLY 9', '', NULL, NULL, 'NKC/HR/SO/313', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(314, 13, 16, NULL, 'Speed Governer(1607233170)', '', NULL, NULL, 'NKC/HR/Sp/314', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(315, 13, 16, NULL, 'Spiral Bending Machine', '', NULL, NULL, 'NKC/HR/Sp/315', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(316, 13, 16, NULL, 'Stapler Pin Small', '', NULL, NULL, 'NKC/HR/St/316', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(317, 13, 16, NULL, 'Table 2''X4''', '', NULL, NULL, 'NKC/HR/Ta/317', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(318, 13, 16, NULL, 'Table 2.5x4''', '', NULL, NULL, 'NKC/HR/Ta/318', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:37', 1, NULL),
(319, 13, 16, NULL, 'Table Fan', '', NULL, NULL, 'NKC/HR/Ta/319', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(320, 13, 16, NULL, 'Table Steel 5''X3'' with Drayer', '', NULL, NULL, 'NKC/HR/Ta/320', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(321, 13, 16, NULL, 'Table Steel 5''X3'' with Out Droyer', '', NULL, NULL, 'NKC/HR/Ta/321', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(322, 13, 16, NULL, 'Table Steel 5X3''', '', NULL, NULL, 'NKC/HR/Ta/322', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(323, 13, 16, NULL, 'Tata Sky', '', NULL, NULL, 'NKC/HR/Ta/323', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(324, 13, 16, NULL, 'Telephone Set', '', NULL, NULL, 'NKC/HR/Te/324', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(325, 13, 16, NULL, 'TV', '', NULL, NULL, 'NKC/HR/TV/325', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(326, 13, 16, NULL, 'TV-LCD', '', NULL, NULL, 'NKC/HR/TV/326', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(327, 13, 16, NULL, 'TV Troly', '', NULL, NULL, 'NKC/HR/TV/327', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(328, 13, 16, NULL, 'UPS-600 KVA', '', NULL, NULL, 'NKC/HR/UP/328', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(329, 13, 16, NULL, 'Ups 800va', '', NULL, NULL, 'NKC/HR/Up/329', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:38', 1, NULL),
(330, 13, 16, NULL, 'UPS Battery New', '', NULL, NULL, 'NKC/HR/UP/330', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(331, 13, 16, NULL, 'Wall Clock', '', NULL, NULL, 'NKC/HR/Wa/331', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(332, 13, 16, NULL, 'Wireless Base Unit', '', NULL, NULL, 'NKC/HR/Wi/332', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(333, 13, 16, NULL, 'Wireless Hand Set(Motorola)', '', NULL, NULL, 'NKC/HR/Wi/333', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(334, 13, 16, NULL, 'Wooden Table', '', NULL, NULL, 'NKC/HR/Wo/334', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(335, 13, 16, NULL, 'Xerox Machine Cannon', '', NULL, NULL, 'NKC/HR/Xe/335', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(336, 13, 17, NULL, 'SHUTTERING PLATE(1250X600)ASSET', '', NULL, NULL, 'NKC/HR/SH/336', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(337, 13, 17, NULL, 'ANGLE BRACKET FABRICATED', '', NULL, NULL, 'NKC/HR/AN/337', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(338, 13, 17, NULL, 'Base Jack 14''''', '', NULL, NULL, 'NKC/HR/Ba/338', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(339, 13, 17, NULL, 'Biult Up Beam/i Girder 1000x6.600(Fabricated)', '', NULL, NULL, 'NKC/HR/Bi/339', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(340, 13, 17, NULL, 'Blister Block (Fabricated)', '', NULL, NULL, 'NKC/HR/Bl/340', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:39', 1, NULL),
(341, 13, 17, NULL, 'Bottom Plate 2100x950 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bo/341', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(342, 13, 17, NULL, 'Bracket Ms. Plate 1250x300x300x200 (Fabricated)', '', NULL, NULL, 'NKC/HR/Br/342', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(343, 13, 17, NULL, 'Bracket Plate-1250X100X250X250', '', NULL, NULL, 'NKC/HR/Br/343', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(344, 13, 17, NULL, 'Built Ub Beam/ I Girder 1000x6.100(Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/344', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(345, 13, 17, NULL, 'Built Up Beam/ I Girder 1000x10.300 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/345', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(346, 13, 17, NULL, 'Built Up Beam/I Girder 1000X12.00(Febricated)', '', NULL, NULL, 'NKC/HR/Bu/346', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(347, 13, 17, NULL, 'Built Up Beam/ I Girder 1000x7.800(Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/347', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL);
INSERT INTO `material` (`id`, `material_group_id`, `material_sub_group_id`, `equipment_id`, `material_name`, `specifications`, `descriptions`, `part_no`, `product_code`, `loss_percentage`, `unit_id`, `brand`, `quantity`, `rate`, `value`, `material_type_id`, `company_id`, `created_on`, `status`, `hsn_code`) VALUES
(348, 13, 17, NULL, 'Built Up Girder/ I Girder 1000x10.000 (Fabficated)', '', NULL, NULL, 'NKC/HR/Bu/348', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(349, 13, 17, NULL, 'Built Up Girder / I Girder 1000x4.000 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/349', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(350, 13, 17, NULL, 'Built Up Girder / I Girder 1000x5.000 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/350', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(351, 13, 17, NULL, 'Built Up Girder/ I Girder 1000x7.100 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/351', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:40', 1, NULL),
(352, 13, 17, NULL, 'Built Up Girder / I Girder 1000x7.300 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/352', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:41', 1, NULL),
(353, 13, 17, NULL, 'Built Up Girder / I Girder 1000x7.500 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/353', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:41', 1, NULL),
(354, 13, 17, NULL, 'Bulit Up Beam/ I Girder 1000x8.600 (Fabricated)', '', NULL, NULL, 'NKC/HR/Bu/354', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:41', 1, NULL),
(355, 13, 17, NULL, 'C Clamp 100X50mm', '', NULL, NULL, 'NKC/HR/C /355', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:41', 1, NULL),
(356, 13, 17, NULL, 'COLLER CAP 100X600X600(FABRICATED)', '', NULL, NULL, 'NKC/HR/CO/356', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:41', 1, NULL),
(357, 13, 17, NULL, 'COLLER CAP 600X600X200 (FABRICATED)', '', NULL, NULL, 'NKC/HR/CO/357', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:41', 1, NULL),
(358, 13, 17, NULL, 'Concrete Box .300x.250x.350(Fabricated)', '', NULL, NULL, 'NKC/HR/Co/358', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:42', 1, NULL),
(359, 13, 17, NULL, 'Coupling', '', NULL, NULL, 'NKC/HR/Co/359', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:42', 1, NULL),
(360, 13, 17, NULL, 'CROSS BAREAR PLATE 1250X1080', '', NULL, NULL, 'NKC/HR/CR/360', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:42', 1, NULL),
(361, 13, 17, NULL, 'CROSS BAREAR PLATE 1250x1130', '', NULL, NULL, 'NKC/HR/CR/361', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:42', 1, NULL),
(362, 13, 17, NULL, 'Cross Barrier Plate 1250x1000 (Fabricated)', '', NULL, NULL, 'NKC/HR/Cr/362', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:42', 1, NULL),
(363, 13, 17, NULL, 'Cross Barrier Plate 150x300x570x2500 (Fabricated)', '', NULL, NULL, 'NKC/HR/Cr/363', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:42', 1, NULL),
(364, 13, 17, NULL, 'Cross Barrier Plate 220x300x650x1250', '', NULL, NULL, 'NKC/HR/Cr/364', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:43', 1, NULL),
(365, 13, 17, NULL, 'Doble Channel-3mtr', '', NULL, NULL, 'NKC/HR/Do/365', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:43', 1, NULL),
(366, 13, 17, NULL, 'Drop Head', '', NULL, NULL, 'NKC/HR/Dr/366', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:43', 1, NULL),
(367, 13, 17, NULL, 'End Block Shuttring (Fabricated)', '', NULL, NULL, 'NKC/HR/En/367', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:43', 1, NULL),
(368, 13, 17, NULL, 'End Plate', '', NULL, NULL, 'NKC/HR/En/368', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:43', 1, NULL),
(369, 13, 17, NULL, 'Fixed Span 1.3mtr', '', NULL, NULL, 'NKC/HR/Fi/369', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:44', 1, NULL),
(370, 13, 17, NULL, 'Fixed Span 1.8mtr', '', NULL, NULL, 'NKC/HR/Fi/370', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:44', 1, NULL),
(371, 13, 17, NULL, 'Foot Path Shuttring (Fabricated)', '', NULL, NULL, 'NKC/HR/Fo/371', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:44', 1, NULL),
(372, 13, 17, NULL, 'HIUNCH PLATE 950X750', '', NULL, NULL, 'NKC/HR/HI/372', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:44', 1, NULL),
(373, 13, 17, NULL, 'HUNCH PLATE 1010X520', '', NULL, NULL, 'NKC/HR/HU/373', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:44', 1, NULL),
(374, 13, 17, NULL, 'HUNCH PLATE 1030X760', '', NULL, NULL, 'NKC/HR/HU/374', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:44', 1, NULL),
(375, 13, 17, NULL, 'HUNCH PLATE 1250X210', '', NULL, NULL, 'NKC/HR/HU/375', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:45', 1, NULL),
(376, 13, 17, NULL, 'Hunch Plate 1250x280 (Fabrication Yard)', '', NULL, NULL, 'NKC/HR/Hu/376', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:45', 1, NULL),
(377, 13, 17, NULL, 'HUNCH PLATE 1250X350', '', NULL, NULL, 'NKC/HR/HU/377', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:45', 1, NULL),
(378, 13, 17, NULL, 'HUNCH PLATE 1250X720', '', NULL, NULL, 'NKC/HR/HU/378', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:45', 1, NULL),
(379, 13, 17, NULL, 'HUNCH PLATE 1380X350', '', NULL, NULL, 'NKC/HR/HU/379', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:45', 1, NULL),
(380, 13, 17, NULL, 'HUNCH PLATE 1860X1000', '', NULL, NULL, 'NKC/HR/HU/380', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:46', 1, NULL),
(381, 13, 17, NULL, 'HUNCH PLATE 2000X1000', '', NULL, NULL, 'NKC/HR/HU/381', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:46', 1, NULL),
(382, 13, 17, NULL, 'HUNCH PLATE  2070x1000', '', NULL, NULL, 'NKC/HR/HU/382', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:46', 1, NULL),
(383, 13, 17, NULL, 'Hunch Plate -240X340X210X1250', '', NULL, NULL, 'NKC/HR/Hu/383', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:46', 1, NULL),
(384, 13, 17, NULL, 'HUNCH PLATE 540X300', '', NULL, NULL, 'NKC/HR/HU/384', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:46', 1, NULL),
(385, 13, 17, NULL, 'HUNCH PLATE 720X300', '', NULL, NULL, 'NKC/HR/HU/385', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:46', 1, NULL),
(386, 13, 17, NULL, 'I Girder Shuttering-1250X200X350X150', '', NULL, NULL, 'NKC/HR/I /386', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:47', 1, NULL),
(387, 13, 17, NULL, 'I Girder Shuttering Plate-1100X100X700X300X200', '', NULL, NULL, 'NKC/HR/I /387', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:47', 1, NULL),
(388, 13, 17, NULL, 'I Girder Shuttering-Plate 1200X400', '', NULL, NULL, 'NKC/HR/I /388', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:47', 1, NULL),
(389, 13, 17, NULL, 'I Girder Shuttering Plate-1250X100X250X250', '', NULL, NULL, 'NKC/HR/I /389', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:47', 1, NULL),
(390, 13, 17, NULL, 'I Girder Shuttering Plate-1250X200X150', '', NULL, NULL, 'NKC/HR/I /390', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:47', 1, NULL),
(391, 13, 17, NULL, 'I Girder Shuttering Plate-1250X200X250', '', NULL, NULL, 'NKC/HR/I /391', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:48', 1, NULL),
(392, 13, 17, NULL, 'I Girder Shuttering Plate-1250X200X450X150', '', NULL, NULL, 'NKC/HR/I /392', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:48', 1, NULL),
(393, 13, 17, NULL, 'I Girder Shuttering Plate-1250X230X250', '', NULL, NULL, 'NKC/HR/I /393', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:48', 1, NULL),
(394, 13, 17, NULL, 'I Girder Shuttering Plate-1250X250X250', '', NULL, NULL, 'NKC/HR/I /394', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:48', 1, NULL),
(395, 13, 17, NULL, 'I Girder Shuttering Plate-1250X250X300X250', '', NULL, NULL, 'NKC/HR/I /395', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:48', 1, NULL),
(396, 13, 17, NULL, 'I Girder Shuttering Plate-1250X280X500X200', '', NULL, NULL, 'NKC/HR/I /396', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:48', 1, NULL),
(397, 13, 17, NULL, 'I Girder Shuttering Plate-1250X300X200X250', '', NULL, NULL, 'NKC/HR/I /397', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:49', 1, NULL),
(398, 13, 17, NULL, 'I Girder Shuttering Plate-1250X800', '', NULL, NULL, 'NKC/HR/I /398', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:49', 1, NULL),
(399, 13, 17, NULL, 'I Girder Shuttering Plate-150X250X200X1250', '', NULL, NULL, 'NKC/HR/I /399', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:49', 1, NULL),
(400, 13, 17, NULL, 'I Girder Shuttering Plate-1750X250X400', '', NULL, NULL, 'NKC/HR/I /400', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:49', 1, NULL),
(401, 13, 17, NULL, 'I Girder Shuttering Plate-300X200X300X250', '', NULL, NULL, 'NKC/HR/I /401', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:49', 1, NULL),
(402, 13, 17, NULL, 'I Girder Shuttering-Plate 400X400', '', NULL, NULL, 'NKC/HR/I /402', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:49', 1, NULL),
(403, 13, 17, NULL, 'I Girder Shuttering Plate-500X100X300X200', '', NULL, NULL, 'NKC/HR/I /403', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:50', 1, NULL),
(404, 13, 17, NULL, 'I Girder Shuttering-Plate 700X400', '', NULL, NULL, 'NKC/HR/I /404', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:50', 1, NULL),
(405, 13, 17, NULL, 'I Girder Shuttering Plate-900X200X150X100', '', NULL, NULL, 'NKC/HR/I /405', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:50', 1, NULL),
(406, 13, 17, NULL, 'I Girder Shuttering-Plate 900X400', '', NULL, NULL, 'NKC/HR/I /406', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:50', 1, NULL),
(407, 13, 17, NULL, 'I Girder Shuttering Plate-900x500', '', NULL, NULL, 'NKC/HR/I /407', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:50', 1, NULL),
(408, 13, 17, NULL, 'I Girder Shuttering-Plate 900X600', '', NULL, NULL, 'NKC/HR/I /408', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:51', 1, NULL),
(409, 13, 17, NULL, 'ISMB 100MMX6MTR', '', NULL, NULL, 'NKC/HR/IS/409', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:51', 1, NULL),
(410, 13, 17, NULL, 'ISMB 175X100X 5''-6''', '', NULL, NULL, 'NKC/HR/IS/410', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:51', 1, NULL),
(411, 13, 17, NULL, 'ISMB 175X100X 6''-7''', '', NULL, NULL, 'NKC/HR/IS/411', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:51', 1, NULL),
(412, 13, 17, NULL, 'Ismb 175x100x6mtr', '', NULL, NULL, 'NKC/HR/Is/412', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:51', 1, NULL),
(413, 13, 17, NULL, 'ISMB 175X100X 9''-10''', '', NULL, NULL, 'NKC/HR/IS/413', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(414, 13, 17, NULL, 'ISMB-1.8mtr.', '', NULL, NULL, 'NKC/HR/IS/414', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(415, 13, 17, NULL, 'ISMB-200X100X6MTR', '', NULL, NULL, 'NKC/HR/IS/415', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(416, 13, 17, NULL, 'ISMB 200X11.200MTR (FABRICATED)', '', NULL, NULL, 'NKC/HR/IS/416', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(417, 13, 17, NULL, 'ISMB 250x6MTR', '', NULL, NULL, 'NKC/HR/IS/417', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(418, 13, 17, NULL, 'ISMB 6mtr NOS 175MM', '', NULL, NULL, 'NKC/HR/IS/418', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(419, 13, 17, NULL, 'ISMB (GIRDER)2.5MTR', '', NULL, NULL, 'NKC/HR/IS/419', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(420, 13, 17, NULL, 'ISMB (GIRDER)3.5MTR', '', NULL, NULL, 'NKC/HR/IS/420', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(421, 13, 17, NULL, 'ISMB (GIRDER)3MTR', '', NULL, NULL, 'NKC/HR/IS/421', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(422, 13, 17, NULL, 'ISMB (GIRDER)4.5MTR', '', NULL, NULL, 'NKC/HR/IS/422', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(423, 13, 17, NULL, 'ISMB (GIRDER)4MTR', '', NULL, NULL, 'NKC/HR/IS/423', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(424, 13, 17, NULL, 'ISMB (GIRDER)5MTR', '', NULL, NULL, 'NKC/HR/IS/424', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(425, 13, 17, NULL, 'ISMB (GIRDER)6MTR', '', NULL, NULL, 'NKC/HR/IS/425', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(426, 13, 17, NULL, 'Joint Pin Ms', '', NULL, NULL, 'NKC/HR/Jo/426', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:52', 1, NULL),
(427, 13, 17, NULL, 'Landing Mat 2500x300x25', '', NULL, NULL, 'NKC/HR/La/427', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(428, 13, 17, NULL, 'Landing Mat .600 Mt', '', NULL, NULL, 'NKC/HR/La/428', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(429, 13, 17, NULL, 'Landing Mats', '', NULL, NULL, 'NKC/HR/La/429', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(430, 13, 17, NULL, 'LANDING MATS 450X300', '', NULL, NULL, 'NKC/HR/LA/430', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(431, 13, 17, NULL, 'Ms Channel 100x1.3mtr', '', NULL, NULL, 'NKC/HR/Ms/431', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(432, 13, 17, NULL, 'Ms Channel 100x 5mtr', '', NULL, NULL, 'NKC/HR/Ms/432', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(433, 13, 17, NULL, 'Ms Channel 125MMX6MTR', '', NULL, NULL, 'NKC/HR/Ms/433', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(434, 13, 17, NULL, 'Ms Channel-2'' to 3''', '', NULL, NULL, 'NKC/HR/Ms/434', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(435, 13, 17, NULL, 'Ms Channel 3''to4''', '', NULL, NULL, 'NKC/HR/Ms/435', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(436, 13, 17, NULL, 'Ms Channel 3mtr (Approx)', '', NULL, NULL, 'NKC/HR/Ms/436', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(437, 13, 17, NULL, 'Ms Channel 4-5''', '', NULL, NULL, 'NKC/HR/Ms/437', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(438, 13, 17, NULL, 'Ms Channel-4mtr', '', NULL, NULL, 'NKC/HR/Ms/438', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(439, 13, 17, NULL, 'Ms Channel (5-6) Feet', '', NULL, NULL, 'NKC/HR/Ms/439', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:53', 1, NULL),
(440, 13, 17, NULL, 'MS CHANNEL 6MTR', '', NULL, NULL, 'NKC/HR/MS/440', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(441, 13, 17, NULL, 'Ms Channel (7-8) Feet', '', NULL, NULL, 'NKC/HR/Ms/441', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(442, 13, 17, NULL, 'Ms Channel (9-10) Feet', '', NULL, NULL, 'NKC/HR/Ms/442', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(443, 13, 17, NULL, 'Ms Clamp 100X50', '', NULL, NULL, 'NKC/HR/Ms/443', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(444, 13, 17, NULL, 'Ms Couplock 1.25mtr', '', NULL, NULL, 'NKC/HR/Ms/444', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(445, 13, 17, NULL, 'Ms Couplock 1.5mtr', '', NULL, NULL, 'NKC/HR/Ms/445', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(446, 13, 17, NULL, 'MS COUPLOCK 1 MTR', '', NULL, NULL, 'NKC/HR/MS/446', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(447, 13, 17, NULL, 'Ms Couplock 2.5mt', '', NULL, NULL, 'NKC/HR/Ms/447', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(448, 13, 17, NULL, 'Ms Couplock 2mtr', '', NULL, NULL, 'NKC/HR/Ms/448', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(449, 13, 17, NULL, 'Ms Couplock 3mtr', '', NULL, NULL, 'NKC/HR/Ms/449', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(450, 13, 17, NULL, 'Ms Couplock .5mtr to .7mtr(Cutpices)', '', NULL, NULL, 'NKC/HR/Ms/450', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:54', 1, NULL),
(451, 13, 17, NULL, 'Ms Crips 2mtrX600X600mm', '', NULL, NULL, 'NKC/HR/Ms/451', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(452, 13, 17, NULL, 'Ms Hunch Plate', '', NULL, NULL, 'NKC/HR/Ms/452', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(453, 13, 17, NULL, 'Ms Hunch Plate 100X200X100', '', NULL, NULL, 'NKC/HR/Ms/453', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(454, 13, 17, NULL, 'Ms Hunch Plate 100X400X100', '', NULL, NULL, 'NKC/HR/Ms/454', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(455, 13, 17, NULL, 'Ms ISMB 125X70X3mtr', '', NULL, NULL, 'NKC/HR/Ms/455', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(456, 13, 17, NULL, 'Ms ISMB 150X80X3mtr', '', NULL, NULL, 'NKC/HR/Ms/456', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(457, 13, 17, NULL, 'MS Landing Mat 2.5 Mtr.', '', NULL, NULL, 'NKC/HR/MS/457', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(458, 13, 17, NULL, 'MS Landing Mat 2 Mtr.', '', NULL, NULL, 'NKC/HR/MS/458', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(459, 13, 17, NULL, 'MS Landing Mat 3Mtr.', '', NULL, NULL, 'NKC/HR/MS/459', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(460, 13, 17, NULL, 'Ms Ledger 1.25mtr', '', NULL, NULL, 'NKC/HR/Ms/460', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(461, 13, 17, NULL, 'Ms Ledger 1.2mt', '', NULL, NULL, 'NKC/HR/Ms/461', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:55', 1, NULL),
(462, 13, 17, NULL, 'Ms Ledger 1.3mtr', '', NULL, NULL, 'NKC/HR/Ms/462', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(463, 13, 17, NULL, 'Ms Ledger 1.5mtr', '', NULL, NULL, 'NKC/HR/Ms/463', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(464, 13, 17, NULL, 'Ms Ledger 1.8mtr', '', NULL, NULL, 'NKC/HR/Ms/464', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(465, 13, 17, NULL, 'Ms Ledger 1mtr', '', NULL, NULL, 'NKC/HR/Ms/465', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(466, 13, 17, NULL, 'Ms Ledger 2mtr', '', NULL, NULL, 'NKC/HR/Ms/466', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(467, 13, 17, NULL, 'Ms Ledger .650mtr', '', NULL, NULL, 'NKC/HR/Ms/467', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(468, 13, 17, NULL, 'Ms Ledger .7mtr', '', NULL, NULL, 'NKC/HR/Ms/468', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(469, 13, 17, NULL, 'MS Lugs 100x400 (Fabricated)', '', NULL, NULL, 'NKC/HR/MS/469', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(470, 13, 17, NULL, 'MS PIPE 1.5MTR', '', NULL, NULL, 'NKC/HR/MS/470', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(471, 13, 17, NULL, 'Ms Pipe 40mmx1 Mtr', '', NULL, NULL, 'NKC/HR/Ms/471', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:56', 1, NULL),
(472, 13, 17, NULL, 'MS Pipe 40mmX2Mtr', '', NULL, NULL, 'NKC/HR/MS/472', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:57', 1, NULL),
(473, 13, 17, NULL, 'MS Pipe 40mmX3Mtr.', '', NULL, NULL, 'NKC/HR/MS/473', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:57', 1, NULL),
(474, 13, 17, NULL, 'MS PIPE 40MMX4MTR', '', NULL, NULL, 'NKC/HR/MS/474', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:57', 1, NULL),
(475, 13, 17, NULL, 'M.S Pipe 40mmX6mtr', '', NULL, NULL, 'NKC/HR/M./475', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:57', 1, NULL),
(476, 13, 17, NULL, 'Ms Pipe 40x5 Mtr', '', NULL, NULL, 'NKC/HR/Ms/476', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:57', 1, NULL),
(477, 13, 17, NULL, 'MS PLATE FOR END DIAFROM', '', NULL, NULL, 'NKC/HR/MS/477', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:58', 1, NULL),
(478, 13, 17, NULL, 'Ms Plate (Insert Plate 600x600)', '', NULL, NULL, 'NKC/HR/Ms/478', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:58', 1, NULL),
(479, 13, 17, NULL, 'Ms Props Jack 1.5 Mtr.', '', NULL, NULL, 'NKC/HR/Ms/479', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:58', 1, NULL),
(480, 13, 17, NULL, 'Ms Soldger 1.25mtr', '', NULL, NULL, 'NKC/HR/Ms/480', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:58', 1, NULL),
(481, 13, 17, NULL, 'Ms Soldger 1.3mtr', '', NULL, NULL, 'NKC/HR/Ms/481', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:58', 1, NULL),
(482, 13, 17, NULL, 'MS SOLDGER 1.5MTR', '', NULL, NULL, 'NKC/HR/MS/482', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:58', 1, NULL),
(483, 13, 17, NULL, 'Ms Soldger 1.8 Mt', '', NULL, NULL, 'NKC/HR/Ms/483', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:59', 1, NULL),
(484, 13, 17, NULL, 'Ms Soldger 2.5 Mt', '', NULL, NULL, 'NKC/HR/Ms/484', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:59', 1, NULL),
(485, 13, 17, NULL, 'PIER SHUTTER 1300x1000', '', NULL, NULL, 'NKC/HR/PI/485', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:59', 1, NULL),
(486, 13, 17, NULL, 'Piling Shutter Casing 1200mm', '', NULL, NULL, 'NKC/HR/Pi/486', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:59', 1, NULL),
(487, 13, 17, NULL, 'PIPE CLAMP (40X40)', '', NULL, NULL, 'NKC/HR/PI/487', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:51:59', 1, NULL),
(488, 13, 17, NULL, 'Plain Gi Sheet', '', NULL, NULL, 'NKC/HR/Pl/488', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:00', 1, NULL),
(489, 13, 17, NULL, 'Prop Jack 1.5mtr Outer', '', NULL, NULL, 'NKC/HR/Pr/489', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:00', 1, NULL),
(490, 13, 17, NULL, 'Prop Jack  2 Mtr Outer', '', NULL, NULL, 'NKC/HR/Pr/490', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:00', 1, NULL),
(491, 13, 17, NULL, 'PROPS JACK 1.5MM INNER PIPE', '', NULL, NULL, 'NKC/HR/PR/491', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:00', 1, NULL),
(492, 13, 17, NULL, 'PROPS JACK 1.5MTR', '', NULL, NULL, 'NKC/HR/PR/492', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:00', 1, NULL),
(493, 13, 17, NULL, 'Props Jack 2.5mtr', '', NULL, NULL, 'NKC/HR/Pr/493', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:00', 1, NULL),
(494, 13, 17, NULL, 'PROPS JACK 2.5MTR INNER', '', NULL, NULL, 'NKC/HR/PR/494', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:01', 1, NULL),
(495, 13, 17, NULL, 'Props Jack 2mtr', '', NULL, NULL, 'NKC/HR/Pr/495', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:01', 1, NULL),
(496, 13, 17, NULL, 'PROPS JACK 2MTR INNER', '', NULL, NULL, 'NKC/HR/PR/496', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:01', 1, NULL),
(497, 13, 17, NULL, 'Props Jack Inner Pipe', '', NULL, NULL, 'NKC/HR/Pr/497', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:01', 1, NULL),
(498, 13, 17, NULL, 'Props Jack Outer Pipe', '', NULL, NULL, 'NKC/HR/Pr/498', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:01', 1, NULL),
(499, 13, 17, NULL, 'PSC GIRDER SET', '', NULL, NULL, 'NKC/HR/PS/499', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:01', 1, NULL),
(500, 13, 17, NULL, 'RCC GIRDER SET', '', NULL, NULL, 'NKC/HR/RC/500', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:02', 1, NULL),
(501, 13, 17, NULL, 'Round Channel (Shuttering Yard)', '', NULL, NULL, 'NKC/HR/Ro/501', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:02', 1, NULL),
(502, 13, 17, NULL, 'Shutering Plate-1750X600', '', NULL, NULL, 'NKC/HR/Sh/502', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:02', 1, NULL),
(503, 13, 17, NULL, 'Shutring Plate (Fabricated)430x940', '', NULL, NULL, 'NKC/HR/Sh/503', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:02', 1, NULL),
(504, 13, 17, NULL, 'Shuttering Palte 1300X1350', '', NULL, NULL, 'NKC/HR/Sh/504', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:02', 1, NULL),
(505, 13, 17, NULL, 'Shuttering Plate 1000X1000', '', NULL, NULL, 'NKC/HR/Sh/505', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:03', 1, NULL),
(506, 13, 17, NULL, 'SHUTTERING PLATE(1000X150X470)SP3E', '', NULL, NULL, 'NKC/HR/SH/506', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:03', 1, NULL),
(507, 13, 17, NULL, 'SHUTTERING PLATE(1000X150X470X460)SP 1', '', NULL, NULL, 'NKC/HR/SH/507', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:03', 1, NULL),
(508, 13, 17, NULL, 'SHUTTERING PLATE 1000X200X470(SP3E', '', NULL, NULL, 'NKC/HR/SH/508', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:03', 1, NULL),
(509, 13, 17, NULL, 'SHUTTERING PLATE (1000X2450)SP 3B', '', NULL, NULL, 'NKC/HR/SH/509', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:03', 1, NULL),
(510, 13, 17, NULL, 'SHUTTERING PLATE (1000X600X1100)SP3H', '', NULL, NULL, 'NKC/HR/SH/510', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(511, 13, 17, NULL, 'Shuttering Plate 1000X620', '', NULL, NULL, 'NKC/HR/Sh/511', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(512, 13, 17, NULL, 'Shuttering Plate-1000X700', '', NULL, NULL, 'NKC/HR/Sh/512', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(513, 13, 17, NULL, 'SHUTTERING PLATE (1100X600X570X130)SP4H', '', NULL, NULL, 'NKC/HR/SH/513', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(514, 13, 17, NULL, 'Shuttering Plate-110X850', '', NULL, NULL, 'NKC/HR/Sh/514', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(515, 13, 17, NULL, 'Shuttering Plate-1200X800', '', NULL, NULL, 'NKC/HR/Sh/515', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(516, 13, 17, NULL, 'Shuttering Plate 1240X330', '', NULL, NULL, 'NKC/HR/Sh/516', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:04', 1, NULL),
(517, 13, 17, NULL, 'Shuttering Plate 1250X1000', '', NULL, NULL, 'NKC/HR/Sh/517', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(518, 13, 17, NULL, 'SHUTTERING PLATE(1250X1000)SP3', '', NULL, NULL, 'NKC/HR/SH/518', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(519, 13, 17, NULL, 'SHUTTERING PLATE 1250X150X150', '', NULL, NULL, 'NKC/HR/SH/519', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(520, 13, 17, NULL, 'Shuttering Plate 1250X200', '', NULL, NULL, 'NKC/HR/Sh/520', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(521, 13, 17, NULL, 'SHUTTERING PLATE(1250X210X540X260)SP4', '', NULL, NULL, 'NKC/HR/SH/521', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(522, 13, 17, NULL, 'Shuttering Plate 1250X240', '', NULL, NULL, 'NKC/HR/Sh/522', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(523, 13, 17, NULL, 'SHUTTERING PLATE(1250X260X330X200)SP2', '', NULL, NULL, 'NKC/HR/SH/523', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:05', 1, NULL),
(524, 13, 17, NULL, 'Shuttering Plate 1250X300', '', NULL, NULL, 'NKC/HR/Sh/524', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:06', 1, NULL),
(525, 13, 17, NULL, 'Shuttering Plate 1250X400', '', NULL, NULL, 'NKC/HR/Sh/525', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:06', 1, NULL),
(526, 13, 17, NULL, 'SHUTTERING PLATE 1250X500', '', NULL, NULL, 'NKC/HR/SH/526', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:06', 1, NULL),
(527, 13, 17, NULL, 'Shuttering Plate 1250X600', '', NULL, NULL, 'NKC/HR/Sh/527', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:06', 1, NULL),
(528, 13, 17, NULL, 'Shuttering Plate 1250X680', '', NULL, NULL, 'NKC/HR/Sh/528', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:06', 1, NULL),
(529, 13, 17, NULL, 'Shuttering Plate 1250x780', '', NULL, NULL, 'NKC/HR/Sh/529', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(530, 13, 17, NULL, 'Shuttering Plate 1250X800', '', NULL, NULL, 'NKC/HR/Sh/530', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(531, 13, 17, NULL, 'Shuttering Plate 1250X860', '', NULL, NULL, 'NKC/HR/Sh/531', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(532, 13, 17, NULL, 'Shuttering Plate 1250X900', '', NULL, NULL, 'NKC/HR/Sh/532', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(533, 13, 17, NULL, 'SHUTTERING PLATE (1250X940)SP1', '', NULL, NULL, 'NKC/HR/SH/533', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(534, 13, 17, NULL, 'Shuttering Plate-1250X950', '', NULL, NULL, 'NKC/HR/Sh/534', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(535, 13, 17, NULL, 'Shuttering Plate 1300X1000', '', NULL, NULL, 'NKC/HR/Sh/535', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(536, 13, 17, NULL, 'Shuttering Plate 1300X1340', '', NULL, NULL, 'NKC/HR/Sh/536', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(537, 13, 17, NULL, 'Shuttering Plate 1300X450', '', NULL, NULL, 'NKC/HR/Sh/537', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(538, 13, 17, NULL, 'Shuttering Plate 1300X680', '', NULL, NULL, 'NKC/HR/Sh/538', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(539, 13, 17, NULL, 'Shuttering Plate 1300X800', '', NULL, NULL, 'NKC/HR/Sh/539', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(540, 13, 17, NULL, 'Shuttering Plate 1350X1000', '', NULL, NULL, 'NKC/HR/Sh/540', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(541, 13, 17, NULL, 'Shuttering Plate 1380X610', '', NULL, NULL, 'NKC/HR/Sh/541', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(542, 13, 17, NULL, 'SHUTTERING PLATE 1580X235X330X200)SP2H', '', NULL, NULL, 'NKC/HR/SH/542', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(543, 13, 17, NULL, 'Shuttering Plate-1700X450', '', NULL, NULL, 'NKC/HR/Sh/543', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(544, 13, 17, NULL, 'Shuttering Plate 1800X1000', '', NULL, NULL, 'NKC/HR/Sh/544', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(545, 13, 17, NULL, 'Shuttering Plate 1800X240', '', NULL, NULL, 'NKC/HR/Sh/545', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(546, 13, 17, NULL, 'Shuttering Plate 1800X400', '', NULL, NULL, 'NKC/HR/Sh/546', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:07', 1, NULL),
(547, 13, 17, NULL, 'Shuttering Plate 1870X760', '', NULL, NULL, 'NKC/HR/Sh/547', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(548, 13, 17, NULL, 'Shuttering Plate 1950X750', '', NULL, NULL, 'NKC/HR/Sh/548', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(549, 13, 17, NULL, 'Shuttering Plate -1950X900', '', NULL, NULL, 'NKC/HR/Sh/549', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(550, 13, 17, NULL, 'SHUTTERING PLATE 1960x750', '', NULL, NULL, 'NKC/HR/SH/550', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(551, 13, 17, NULL, 'Shuttering Plate 2000X240', '', NULL, NULL, 'NKC/HR/Sh/551', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(552, 13, 17, NULL, 'Shuttering Plate 2000X800', '', NULL, NULL, 'NKC/HR/Sh/552', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(553, 13, 17, NULL, 'SHUTTERING PLATE(200X320X260X650X2450)SP2B', '', NULL, NULL, 'NKC/HR/SH/553', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(554, 13, 17, NULL, 'Shuttering Plate  2040X330', '', NULL, NULL, 'NKC/HR/Sh/554', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(555, 13, 17, NULL, 'Shuttering Plate 2050X730', '', NULL, NULL, 'NKC/HR/Sh/555', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(556, 13, 17, NULL, 'Shuttering Plate 2060X1080', '', NULL, NULL, 'NKC/HR/Sh/556', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(557, 13, 17, NULL, 'Shuttering Plate 2100X600', '', NULL, NULL, 'NKC/HR/Sh/557', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(558, 13, 17, NULL, 'Shuttering Plate 2100X700', '', NULL, NULL, 'NKC/HR/Sh/558', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(559, 13, 17, NULL, 'Shuttering Plate 2100X800', '', NULL, NULL, 'NKC/HR/Sh/559', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(560, 13, 17, NULL, 'Shuttering Plate-2200X400', '', NULL, NULL, 'NKC/HR/Sh/560', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:08', 1, NULL),
(561, 13, 17, NULL, 'SHUTTERING PLATE (2210X400)SP4J', '', NULL, NULL, 'NKC/HR/SH/561', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(562, 13, 17, NULL, 'Shuttering Plate-2250X1250', '', NULL, NULL, 'NKC/HR/Sh/562', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(563, 13, 17, NULL, 'Shuttering Plate 2250X300', '', NULL, NULL, 'NKC/HR/Sh/563', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(564, 13, 17, NULL, 'Shuttering Plate-2250X600', '', NULL, NULL, 'NKC/HR/Sh/564', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(565, 13, 17, NULL, 'Shuttering Plate 2500X1000', '', NULL, NULL, 'NKC/HR/Sh/565', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(566, 13, 17, NULL, 'Shuttering Plate 2500X300', '', NULL, NULL, 'NKC/HR/Sh/566', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(567, 13, 17, NULL, 'Shuttering Plate 2500X320', '', NULL, NULL, 'NKC/HR/Sh/567', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(568, 13, 17, NULL, 'SHUTTERING PLATE (260X500X200X2470)SP4B', '', NULL, NULL, 'NKC/HR/SH/568', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:09', 1, NULL),
(569, 13, 17, NULL, 'Shuttering Plate 2900X300', '', NULL, NULL, 'NKC/HR/Sh/569', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(570, 13, 17, NULL, 'SHUTTERING PLATE 3000X500', '', NULL, NULL, 'NKC/HR/SH/570', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(571, 13, 17, NULL, 'SHUTTERING PLATE 400X1000(SP3A)', '', NULL, NULL, 'NKC/HR/SH/571', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(572, 13, 17, NULL, 'SHUTTERING PLATE(400X200X240X270)SP4A', '', NULL, NULL, 'NKC/HR/SH/572', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(573, 13, 17, NULL, 'SHUTTERING PLATE(400X200X490X260)SP2A', '', NULL, NULL, 'NKC/HR/SH/573', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(574, 13, 17, NULL, 'Shuttering Plate 500X300mm', '', NULL, NULL, 'NKC/HR/Sh/574', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(575, 13, 17, NULL, 'Shuttering Plate-500X300X160X1000', '', NULL, NULL, 'NKC/HR/Sh/575', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(576, 13, 17, NULL, 'Shuttering Plate 550X600mm', '', NULL, NULL, 'NKC/HR/Sh/576', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(577, 13, 17, NULL, 'SHUTTERING PLATE 560X570 (SP4I', '', NULL, NULL, 'NKC/HR/SH/577', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(578, 13, 17, NULL, 'SHUTTERING PLATE 570X210X250X210(SP4D SP4E)', '', NULL, NULL, 'NKC/HR/SH/578', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:10', 1, NULL),
(579, 13, 17, NULL, 'Shuttering Plate-570X580', '', NULL, NULL, 'NKC/HR/Sh/579', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:11', 1, NULL),
(580, 13, 17, NULL, 'SHUTTERING PLATE 580X215X260)SP4F', '', NULL, NULL, 'NKC/HR/SH/580', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:11', 1, NULL),
(581, 13, 17, NULL, 'Shuttering Plate 600X400', '', NULL, NULL, 'NKC/HR/Sh/581', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:11', 1, NULL),
(582, 13, 17, NULL, 'SHUTTERING PLATE 650X140X460X500(SP2E)', '', NULL, NULL, 'NKC/HR/SH/582', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:11', 1, NULL),
(583, 13, 17, NULL, 'SHUTTERING PLATE 650X475X200(SP2F)', '', NULL, NULL, 'NKC/HR/SH/583', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:11', 1, NULL),
(584, 13, 17, NULL, 'Shuttering Plate 800X700', '', NULL, NULL, 'NKC/HR/Sh/584', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:12', 1, NULL),
(585, 13, 17, NULL, 'Shuttering Plate-850X400', '', NULL, NULL, 'NKC/HR/Sh/585', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:12', 1, NULL),
(586, 13, 17, NULL, 'Shuttering Plate-850X850', '', NULL, NULL, 'NKC/HR/Sh/586', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:12', 1, NULL),
(587, 13, 17, NULL, 'SHUTTERING PLATE (880X1000)SP3C', '', NULL, NULL, 'NKC/HR/SH/587', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:12', 1, NULL),
(588, 13, 17, NULL, 'SHUTTERING PLATE (880X250X220X270(SP4C', '', NULL, NULL, 'NKC/HR/SH/588', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:12', 1, NULL),
(589, 13, 17, NULL, 'SHUTTERING PLATE (880X650)SP2C', '', NULL, NULL, 'NKC/HR/SH/589', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:12', 1, NULL),
(590, 13, 17, NULL, 'SHUTTERING PLATE (900X1000)SP3D', '', NULL, NULL, 'NKC/HR/SH/590', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:13', 1, NULL),
(591, 13, 17, NULL, 'Shuttering Plate-900X400', '', NULL, NULL, 'NKC/HR/Sh/591', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:13', 1, NULL),
(592, 13, 17, NULL, 'Shuttering Plate 900x600', '', NULL, NULL, 'NKC/HR/Sh/592', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:13', 1, NULL),
(593, 13, 17, NULL, 'SHUTTERING PLATE (900X650)SP2D', '', NULL, NULL, 'NKC/HR/SH/593', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:13', 1, NULL),
(594, 13, 17, NULL, 'SHUTTERING PLATE (SP2G,SP3G,SP4G)', '', NULL, NULL, 'NKC/HR/SH/594', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:13', 1, NULL),
(595, 13, 17, NULL, 'SHUTTERING SCRAP MATERIAL', '', NULL, NULL, 'NKC/HR/SH/595', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:13', 1, NULL),
(596, 13, 17, NULL, 'SHUTTERING SENTER CROSS GIRDER UPPER HANCH (960X110', '', NULL, NULL, 'NKC/HR/SH/596', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(597, 13, 17, NULL, 'Shuttring Bottom Plate 1250x936 (SP1)', '', NULL, NULL, 'NKC/HR/Sh/597', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(598, 13, 17, NULL, 'Shuttring Bottom Plate 428x830(SP1A)', '', NULL, NULL, 'NKC/HR/Sh/598', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(599, 13, 17, NULL, 'Shuttring Center Cross End Plate 2214x406 (SP4J)', '', NULL, NULL, 'NKC/HR/Sh/599', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(600, 13, 17, NULL, 'Shuttring Center Plate 1250x1000 (SP3)', '', NULL, NULL, 'NKC/HR/Sh/600', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(601, 13, 17, NULL, 'Shuttring Channel', '', NULL, NULL, 'NKC/HR/Sh/601', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(602, 13, 17, NULL, 'Shuttring Cross Center Plate 1000x594(SP3E)', '', NULL, NULL, 'NKC/HR/Sh/602', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:14', 1, NULL),
(603, 13, 17, NULL, 'Shuttring Cross Plate 1100x1000x600x700(SP3H)', '', NULL, NULL, 'NKC/HR/Sh/603', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(604, 13, 17, NULL, 'Shuttring Hunch Bottom Plate 1250x783 (SP2)', '', NULL, NULL, 'NKC/HR/Sh/604', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(605, 13, 17, NULL, 'Shuttring Nut 1/2''''', '', NULL, NULL, 'NKC/HR/Sh/605', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(606, 13, 17, NULL, 'SHUTTRING PLATE 1150X200(SCRAP PLATE)', '', NULL, NULL, 'NKC/HR/SH/606', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(607, 13, 17, NULL, 'Shuttring Plate 1250x175 (Fabrication Yard)', '', NULL, NULL, 'NKC/HR/Sh/607', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(608, 13, 17, NULL, 'SHUTTRING PLATE 1250X560 (SCRAP PLATE)', '', NULL, NULL, 'NKC/HR/SH/608', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(609, 13, 17, NULL, 'Shuttring Plate 1250x950 (Fabricated)', '', NULL, NULL, 'NKC/HR/Sh/609', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:15', 1, NULL),
(610, 13, 17, NULL, 'Shuttring Plate 1320x1450x650 (Fabricated)', '', NULL, NULL, 'NKC/HR/Sh/610', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:16', 1, NULL),
(611, 13, 17, NULL, 'Shuttring Plate 1350x1450x600(Fabricated)', '', NULL, NULL, 'NKC/HR/Sh/611', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:16', 1, NULL),
(612, 13, 17, NULL, 'SHUTTRING PLATE 1450X650X1330X670X150X750X300', '', NULL, NULL, 'NKC/HR/SH/612', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:16', 1, NULL),
(613, 13, 17, NULL, 'Shuttring Plate 1700x100(Fabrication Yard)', '', NULL, NULL, 'NKC/HR/Sh/613', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:16', 1, NULL),
(614, 13, 17, NULL, 'SHUTTRING PLATE 1750X580X1790 (FABRICATED)', '', NULL, NULL, 'NKC/HR/SH/614', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:16', 1, NULL),
(615, 13, 17, NULL, 'Shuttring Plate 2230x500 (Fabricated)', '', NULL, NULL, 'NKC/HR/Sh/615', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:16', 1, NULL),
(616, 13, 17, NULL, 'Shuttring Plate 2620x600 (Fabricated)', '', NULL, NULL, 'NKC/HR/Sh/616', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:17', 1, NULL),
(617, 13, 17, NULL, 'Shuttring Plate 450x1700', '', NULL, NULL, 'NKC/HR/Sh/617', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:17', 1, NULL),
(618, 13, 17, NULL, 'SHUTTRING PLATE 600X500 (SCRAP PLATE)', '', NULL, NULL, 'NKC/HR/SH/618', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:17', 1, NULL),
(619, 13, 17, NULL, 'SHUTTRING PLATE 600X800 (SCRAP PLATE)', '', NULL, NULL, 'NKC/HR/SH/619', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:17', 1, NULL),
(620, 13, 17, NULL, 'SHUTTRING PLATE 870X670X1020X660X290X300X140', '', NULL, NULL, 'NKC/HR/SH/620', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:17', 1, NULL),
(621, 13, 17, NULL, 'Shuttring Plate 890x1000x650 (Fabricated)', '', NULL, NULL, 'NKC/HR/Sh/621', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:18', 1, NULL),
(622, 13, 17, NULL, 'SHUTTRING PLATE 900X200 (SCRAP PLATE)', '', NULL, NULL, 'NKC/HR/SH/622', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:18', 1, NULL),
(623, 13, 17, NULL, 'Shuttring Plate (Fabricated)2220x400', '', NULL, NULL, 'NKC/HR/Sh/623', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:18', 1, NULL),
(624, 13, 17, NULL, 'Shuttring Plate (Fabricated)570x560', '', NULL, NULL, 'NKC/HR/Sh/624', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:18', 1, NULL),
(625, 13, 17, NULL, 'Shuttring Upper End Hunch Plate900x735', '', NULL, NULL, 'NKC/HR/Sh/625', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:18', 1, NULL),
(626, 13, 17, NULL, 'Shuttring Upper Hunch End Plate 831x735 (SP4C)', '', NULL, NULL, 'NKC/HR/Sh/626', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:18', 1, NULL),
(627, 13, 17, NULL, 'Shuttring Upper Hunch Plate 1250x960 (SP4)', '', NULL, NULL, 'NKC/HR/Sh/627', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:19', 1, NULL),
(628, 13, 17, NULL, 'SIKANJA', '', NULL, NULL, 'NKC/HR/SI/628', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:19', 1, NULL),
(629, 13, 17, NULL, 'Stoper 75X75X300MMX3MTR', '', NULL, NULL, 'NKC/HR/St/629', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:19', 1, NULL),
(630, 13, 17, NULL, 'Stoper 75X75X300MMX5MTR', '', NULL, NULL, 'NKC/HR/St/630', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:19', 1, NULL),
(631, 13, 17, NULL, 'TURN BUCKLE WITH TIL UP', '', NULL, NULL, 'NKC/HR/TU/631', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:19', 1, NULL),
(632, 13, 17, NULL, 'U Head Jack 18''''', '', NULL, NULL, 'NKC/HR/U /632', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:20', 1, NULL),
(633, 13, 17, NULL, 'Wallers 3050x100x50 (Channel Type)', '', NULL, NULL, 'NKC/HR/Wa/633', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:20', 1, NULL),
(634, 13, 17, NULL, 'WELL SHURTTING', '', NULL, NULL, 'NKC/HR/WE/634', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:20', 1, NULL),
(635, 13, 18, NULL, 'Aluminium Stand', '', NULL, NULL, 'NKC/HR/Al/635', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:20', 1, NULL),
(636, 13, 18, NULL, 'Auto Level Machine', '', NULL, NULL, 'NKC/HR/Au/636', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:20', 1, NULL),
(637, 13, 18, NULL, 'AUTO LEVEL STAND', '', NULL, NULL, 'NKC/HR/AU/637', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:21', 1, NULL),
(638, 13, 18, NULL, 'Battery Charger with Cable', '', NULL, NULL, 'NKC/HR/Ba/638', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:21', 1, NULL),
(639, 13, 18, NULL, 'Battery Charger with Cable BDC-46B', '', NULL, NULL, 'NKC/HR/Ba/639', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:21', 1, NULL),
(640, 13, 18, NULL, 'Germin GPS76CSX', '', NULL, NULL, 'NKC/HR/Ge/640', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:21', 1, NULL),
(641, 13, 18, NULL, 'Leveling Staff', '', NULL, NULL, 'NKC/HR/Le/641', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:21', 1, NULL),
(642, 13, 18, NULL, 'Prism', '', NULL, NULL, 'NKC/HR/Pr/642', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:21', 1, NULL),
(643, 13, 18, NULL, 'Prism Mini', '', NULL, NULL, 'NKC/HR/Pr/643', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:22', 1, NULL),
(644, 13, 18, NULL, 'Prism Pole', '', NULL, NULL, 'NKC/HR/Pr/644', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:22', 1, NULL),
(645, 13, 18, NULL, 'Prism Single 83287', '', NULL, NULL, 'NKC/HR/Pr/645', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:22', 1, NULL),
(646, 13, 18, NULL, 'Target', '', NULL, NULL, 'NKC/HR/Ta/646', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:22', 1, NULL),
(647, 13, 18, NULL, 'Target Machine', '', NULL, NULL, 'NKC/HR/Ta/647', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:22', 1, NULL),
(648, 13, 18, NULL, 'Thedolight Set', '', NULL, NULL, 'NKC/HR/Th/648', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:23', 1, NULL),
(649, 13, 18, NULL, 'Total Station', '', NULL, NULL, 'NKC/HR/To/649', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:23', 1, NULL),
(650, 13, 18, NULL, 'Tripod', '', NULL, NULL, 'NKC/HR/Tr/650', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:23', 1, NULL),
(651, 13, 18, NULL, 'Wooden Stand for Ts', '', NULL, NULL, 'NKC/HR/Wo/651', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:23', 1, NULL),
(652, 13, 19, NULL, 'D.A Cylinder', '', NULL, NULL, 'NKC/HR/D./652', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:23', 1, NULL),
(653, 13, 19, NULL, 'Electronic Balance 100kgs', '', NULL, NULL, 'NKC/HR/El/653', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:24', 1, NULL),
(654, 13, 19, NULL, 'Gas Stove With Regulator', '', NULL, NULL, 'NKC/HR/Ga/654', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:24', 1, NULL),
(655, 13, 19, NULL, 'GEYSER 6LTR', '', NULL, NULL, 'NKC/HR/GE/655', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:24', 1, NULL),
(656, 13, 19, NULL, 'LPG Cylinder 14 Kg Security', '', NULL, NULL, 'NKC/HR/LP/656', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:24', 1, NULL),
(657, 13, 19, NULL, 'LPG Cylinder 19 Kg Security', '', NULL, NULL, 'NKC/HR/LP/657', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:24', 1, NULL),
(658, 13, 19, NULL, 'Mixture Grinder', '', NULL, NULL, 'NKC/HR/Mi/658', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:24', 1, NULL),
(659, 13, 19, NULL, 'Ms Rack', '', NULL, NULL, 'NKC/HR/Ms/659', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:25', 1, NULL),
(660, 13, 19, NULL, 'Oxygen Cylinder Security', '', NULL, NULL, 'NKC/HR/Ox/660', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:25', 1, NULL),
(661, 13, 19, NULL, 'PRINTER (5440D) FOR HMP', '', NULL, NULL, 'NKC/HR/PR/661', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:25', 1, NULL),
(662, 13, 19, NULL, 'Shutter Vibrator', '', NULL, NULL, 'NKC/HR/Sh/662', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:25', 1, NULL),
(663, 13, 19, NULL, 'Wire Rope Sealing 25mmX5mtr', '', NULL, NULL, 'NKC/HR/Wi/663', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:25', 1, NULL),
(664, 13, 19, NULL, 'Wire Rope Sealing 5X8X6mtr', '', NULL, NULL, 'NKC/HR/Wi/664', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:25', 1, NULL),
(665, 13, 19, NULL, 'Wodden Patta (Ms Rack)', '', NULL, NULL, 'NKC/HR/Wo/665', NULL, 7, NULL, 0, 0.00, '0', 3, 1, '2017-12-21 11:52:26', 1, NULL),
(666, NULL, NULL, 2, NULL, 'Eicher tractor', 'tractor', '12', NULL, NULL, NULL, NULL, 12, 100.00, '1200', 2, 1, '2017-12-21 11:53:58', 1, '303'),
(667, NULL, NULL, 3, NULL, 'JCB', 'JCB', '1234', NULL, NULL, NULL, NULL, 100, 100.00, '10000', 2, 1, '2017-12-21 11:53:58', 1, '103');

-- --------------------------------------------------------

--
-- Table structure for table `material_brand`
--

CREATE TABLE IF NOT EXISTS `material_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `material_brand`
--

INSERT INTO `material_brand` (`id`, `material_id`, `brand`, `created_on`) VALUES
(1, 0, 'Any', '2017-12-15 12:50:15'),
(2, 8, 'Lafarge', '2017-12-15 14:02:16'),
(3, 8, 'Altratech', '2017-12-15 14:02:16');

-- --------------------------------------------------------

--
-- Table structure for table `material_group`
--

CREATE TABLE IF NOT EXISTS `material_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `material_group`
--

INSERT INTO `material_group` (`id`, `parent_id`, `name`, `created_on`, `status`) VALUES
(1, 0, 'Construction Material', '2017-12-21 11:50:12', 1),
(2, 1, 'Bitumen', '2017-12-21 11:50:12', 1),
(3, 1, 'Boulder', '2017-12-21 11:50:12', 1),
(4, 1, 'Emulssion', '2017-12-21 11:50:13', 1),
(5, 1, 'Aggregate', '2017-12-21 11:50:13', 1),
(6, 1, 'GSB', '2017-12-21 11:50:13', 1),
(7, 1, 'Sand', '2017-12-21 11:50:14', 1),
(8, 1, 'Stone Dust', '2017-12-21 11:50:14', 1),
(9, 1, 'Admixture', '2017-12-21 11:50:14', 1),
(10, 1, 'Cement', '2017-12-21 11:50:15', 1),
(11, 1, 'Steel', '2017-12-21 11:50:15', 1),
(12, 1, 'Hume Pipe', '2017-12-21 11:50:17', 1),
(13, 0, 'Construction fixed assets', '2017-12-21 11:51:02', 1),
(14, 13, 'Furniture & Fixture', '2017-12-21 11:51:02', 1),
(15, 13, 'Lab Equipment', '2017-12-21 11:51:07', 1),
(16, 13, 'OFFICE EQUIPMENT', '2017-12-21 11:51:31', 1),
(17, 13, 'Shuttering Material', '2017-12-21 11:51:39', 1),
(18, 13, 'Survey Instruments', '2017-12-21 11:52:20', 1),
(19, 13, 'Temporary Assets', '2017-12-21 11:52:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `material_receipt`
--

CREATE TABLE IF NOT EXISTS `material_receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` varchar(50) NOT NULL,
  `site_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `mrn_no` varchar(50) NOT NULL,
  `mrn_date` varchar(20) NOT NULL,
  `bill_number` varchar(255) NOT NULL,
  `bill_date` varchar(20) DEFAULT NULL,
  `truck_no` varchar(20) DEFAULT NULL,
  `transport_no` varchar(255) DEFAULT NULL,
  `po_id` int(11) NOT NULL,
  `freight` double NOT NULL DEFAULT '0',
  `requested_store_keeper_id` int(11) DEFAULT NULL,
  `received_store_incharge_id` int(11) NOT NULL,
  `accountant_id` int(11) DEFAULT NULL,
  `project_manager_id` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1->created 2->partial_approved 3->full approved 4->reject',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_material_issue_slip_1_idx` (`site_id`),
  KEY `fk_material_issue_slip_4_idx` (`requested_store_keeper_id`),
  KEY `fk_material_issue_slip_5_idx` (`received_store_incharge_id`),
  KEY `fk_material_issue_slip_6_idx` (`accountant_id`),
  KEY `fk_material_issue_slip_7_idx` (`project_manager_id`),
  KEY `fk_material_issue_slip_3_idx` (`po_id`),
  KEY `fk_material_issue_slip_2_idx` (`supplier_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `material_receipt`
--

INSERT INTO `material_receipt` (`id`, `serial_no`, `site_id`, `supplier_id`, `mrn_no`, `mrn_date`, `bill_number`, `bill_date`, `truck_no`, `transport_no`, `po_id`, `freight`, `requested_store_keeper_id`, `received_store_incharge_id`, `accountant_id`, `project_manager_id`, `status`, `created_on`) VALUES
(1, '1', 1, 1, 'NKC/32543-01/01', '12/22/2017', '31', '12/22/2017', 'asfasdf', 'sdfasdf', 1, 1000, 5, 4, NULL, NULL, 1, '2017-12-22 06:31:10'),
(2, '2', 1, 1, 'NKC/32543-01/02', '12/22/2017', '123', '12/22/2017', 'HR1234', 'dfasf', 2, 1000, 5, 4, NULL, NULL, 1, '2017-12-22 06:37:33'),
(3, '3', 1, 1, 'NKC/32543-01/03', '12/22/2017', '111', '12/22/2017', '12345', 'asdf', 2, 1000, 5, 4, NULL, NULL, 1, '2017-12-22 06:39:55'),
(9, '4', 1, 1, 'NKC/32543-01/04', '12/22/2017', '1234', '12/22/2017', 'asdfasf', 'asdfasdf', 3, 1000, 5, 4, NULL, NULL, 1, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `material_receipt_items`
--

CREATE TABLE IF NOT EXISTS `material_receipt_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_receipt_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `received_quantity` int(11) NOT NULL,
  `accepted_quantity` int(11) NOT NULL,
  `price` float(11,2) NOT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `gst` double NOT NULL DEFAULT '0',
  `remarks` text,
  PRIMARY KEY (`id`),
  KEY `fk_material_slip_items_1_idx` (`material_receipt_id`),
  KEY `fk_material_slip_items_2_idx` (`material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `material_receipt_items`
--

INSERT INTO `material_receipt_items` (`id`, `material_receipt_id`, `material_id`, `equipment_id`, `received_quantity`, `accepted_quantity`, `price`, `discount`, `gst`, `remarks`) VALUES
(1, 1, 8, NULL, 1500, 1500, 10.00, 1, 1, 'DFGSGSD'),
(2, 1, 9, NULL, 1000, 1000, 10.00, 2, 2, 'SDGSG'),
(3, 2, 8, NULL, 500, 50, 100.00, 10, 5, 'ghdfh'),
(4, 2, 9, NULL, 1000, 100, 100.00, 10, 5, 'dfghh'),
(5, 3, 8, NULL, 450, 450, 100.00, 10, 5, 'dsfasf'),
(6, 3, 9, NULL, 900, 900, 100.00, 10, 5, 'sdfasf'),
(11, 9, 10, NULL, 1200, 1200, 10.00, 5, 5, 'dfgdsgf'),
(12, 9, 15, NULL, 2000, 2000, 10.00, 5, 5, 'dfgdsfg');

-- --------------------------------------------------------

--
-- Table structure for table `material_stock`
--

CREATE TABLE IF NOT EXISTS `material_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `requisition_id` int(11) NOT NULL DEFAULT '0',
  `material_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `type` int(1) NOT NULL COMMENT 'opening->1,2->po,3->issue',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=688 ;

--
-- Dumping data for table `material_stock`
--

INSERT INTO `material_stock` (`id`, `site_id`, `requisition_id`, `material_id`, `quantity`, `type`, `created_on`) VALUES
(1, 1, 0, 1, 0, 1, '2017-12-21 11:50:12'),
(2, 1, 0, 2, 10, 1, '2017-12-21 11:50:12'),
(3, 1, 0, 3, 0, 1, '2017-12-21 11:50:12'),
(4, 1, 0, 4, 0, 1, '2017-12-21 11:50:12'),
(5, 1, 0, 5, 20, 1, '2017-12-21 11:50:13'),
(6, 1, 0, 6, 0, 1, '2017-12-21 11:50:13'),
(7, 1, 0, 7, 0, 1, '2017-12-21 11:50:13'),
(8, 1, 0, 8, 0, 1, '2017-12-21 11:50:13'),
(9, 1, 0, 9, 0, 1, '2017-12-21 11:50:13'),
(10, 1, 0, 10, 0, 1, '2017-12-21 11:50:13'),
(11, 1, 0, 11, 20, 1, '2017-12-21 11:50:13'),
(12, 1, 0, 12, 0, 1, '2017-12-21 11:50:14'),
(13, 1, 0, 13, 0, 1, '2017-12-21 11:50:14'),
(14, 1, 0, 14, 0, 1, '2017-12-21 11:50:14'),
(15, 1, 0, 15, 0, 1, '2017-12-21 11:50:14'),
(16, 1, 0, 16, 0, 1, '2017-12-21 11:50:14'),
(17, 1, 0, 17, 0, 1, '2017-12-21 11:50:15'),
(18, 1, 0, 18, 0, 1, '2017-12-21 11:50:15'),
(19, 1, 0, 19, 0, 1, '2017-12-21 11:50:15'),
(20, 1, 0, 20, 10, 1, '2017-12-21 11:50:15'),
(21, 1, 0, 21, 0, 1, '2017-12-21 11:50:15'),
(22, 1, 0, 22, 0, 1, '2017-12-21 11:50:16'),
(23, 1, 0, 23, 0, 1, '2017-12-21 11:50:16'),
(24, 1, 0, 24, 0, 1, '2017-12-21 11:50:16'),
(25, 1, 0, 25, 0, 1, '2017-12-21 11:50:16'),
(26, 1, 0, 26, 0, 1, '2017-12-21 11:50:16'),
(27, 1, 0, 27, 0, 1, '2017-12-21 11:50:17'),
(28, 1, 0, 28, 0, 1, '2017-12-21 11:50:17'),
(29, 1, 0, 29, 0, 1, '2017-12-21 11:50:17'),
(30, 1, 0, 30, 0, 1, '2017-12-21 11:51:02'),
(31, 1, 0, 31, 0, 1, '2017-12-21 11:51:03'),
(32, 1, 0, 32, 0, 1, '2017-12-21 11:51:03'),
(33, 1, 0, 33, 0, 1, '2017-12-21 11:51:03'),
(34, 1, 0, 34, 0, 1, '2017-12-21 11:51:03'),
(35, 1, 0, 35, 0, 1, '2017-12-21 11:51:03'),
(36, 1, 0, 36, 0, 1, '2017-12-21 11:51:04'),
(37, 1, 0, 37, 0, 1, '2017-12-21 11:51:04'),
(38, 1, 0, 38, 0, 1, '2017-12-21 11:51:04'),
(39, 1, 0, 39, 0, 1, '2017-12-21 11:51:04'),
(40, 1, 0, 40, 0, 1, '2017-12-21 11:51:04'),
(41, 1, 0, 41, 0, 1, '2017-12-21 11:51:05'),
(42, 1, 0, 42, 0, 1, '2017-12-21 11:51:05'),
(43, 1, 0, 43, 0, 1, '2017-12-21 11:51:05'),
(44, 1, 0, 44, 0, 1, '2017-12-21 11:51:05'),
(45, 1, 0, 45, 0, 1, '2017-12-21 11:51:05'),
(46, 1, 0, 46, 0, 1, '2017-12-21 11:51:06'),
(47, 1, 0, 47, 0, 1, '2017-12-21 11:51:06'),
(48, 1, 0, 48, 0, 1, '2017-12-21 11:51:06'),
(49, 1, 0, 49, 0, 1, '2017-12-21 11:51:06'),
(50, 1, 0, 50, 0, 1, '2017-12-21 11:51:06'),
(51, 1, 0, 51, 0, 1, '2017-12-21 11:51:06'),
(52, 1, 0, 52, 0, 1, '2017-12-21 11:51:06'),
(53, 1, 0, 53, 0, 1, '2017-12-21 11:51:07'),
(54, 1, 0, 54, 0, 1, '2017-12-21 11:51:07'),
(55, 1, 0, 55, 0, 1, '2017-12-21 11:51:07'),
(56, 1, 0, 56, 0, 1, '2017-12-21 11:51:07'),
(57, 1, 0, 57, 0, 1, '2017-12-21 11:51:07'),
(58, 1, 0, 58, 0, 1, '2017-12-21 11:51:07'),
(59, 1, 0, 59, 0, 1, '2017-12-21 11:51:07'),
(60, 1, 0, 60, 0, 1, '2017-12-21 11:51:07'),
(61, 1, 0, 61, 0, 1, '2017-12-21 11:51:07'),
(62, 1, 0, 62, 0, 1, '2017-12-21 11:51:07'),
(63, 1, 0, 63, 0, 1, '2017-12-21 11:51:07'),
(64, 1, 0, 64, 0, 1, '2017-12-21 11:51:07'),
(65, 1, 0, 65, 0, 1, '2017-12-21 11:51:07'),
(66, 1, 0, 66, 0, 1, '2017-12-21 11:51:07'),
(67, 1, 0, 67, 0, 1, '2017-12-21 11:51:07'),
(68, 1, 0, 68, 0, 1, '2017-12-21 11:51:07'),
(69, 1, 0, 69, 0, 1, '2017-12-21 11:51:08'),
(70, 1, 0, 70, 0, 1, '2017-12-21 11:51:08'),
(71, 1, 0, 71, 0, 1, '2017-12-21 11:51:08'),
(72, 1, 0, 72, 0, 1, '2017-12-21 11:51:08'),
(73, 1, 0, 73, 0, 1, '2017-12-21 11:51:08'),
(74, 1, 0, 74, 0, 1, '2017-12-21 11:51:08'),
(75, 1, 0, 75, 0, 1, '2017-12-21 11:51:08'),
(76, 1, 0, 76, 0, 1, '2017-12-21 11:51:08'),
(77, 1, 0, 77, 0, 1, '2017-12-21 11:51:08'),
(78, 1, 0, 78, 0, 1, '2017-12-21 11:51:08'),
(79, 1, 0, 79, 0, 1, '2017-12-21 11:51:08'),
(80, 1, 0, 80, 0, 1, '2017-12-21 11:51:08'),
(81, 1, 0, 81, 0, 1, '2017-12-21 11:51:09'),
(82, 1, 0, 82, 0, 1, '2017-12-21 11:51:09'),
(83, 1, 0, 83, 0, 1, '2017-12-21 11:51:09'),
(84, 1, 0, 84, 0, 1, '2017-12-21 11:51:09'),
(85, 1, 0, 85, 0, 1, '2017-12-21 11:51:09'),
(86, 1, 0, 86, 0, 1, '2017-12-21 11:51:09'),
(87, 1, 0, 87, 0, 1, '2017-12-21 11:51:09'),
(88, 1, 0, 88, 0, 1, '2017-12-21 11:51:09'),
(89, 1, 0, 89, 0, 1, '2017-12-21 11:51:09'),
(90, 1, 0, 90, 0, 1, '2017-12-21 11:51:10'),
(91, 1, 0, 91, 0, 1, '2017-12-21 11:51:10'),
(92, 1, 0, 92, 0, 1, '2017-12-21 11:51:10'),
(93, 1, 0, 93, 0, 1, '2017-12-21 11:51:10'),
(94, 1, 0, 94, 0, 1, '2017-12-21 11:51:10'),
(95, 1, 0, 95, 0, 1, '2017-12-21 11:51:10'),
(96, 1, 0, 96, 0, 1, '2017-12-21 11:51:11'),
(97, 1, 0, 97, 0, 1, '2017-12-21 11:51:11'),
(98, 1, 0, 98, 0, 1, '2017-12-21 11:51:11'),
(99, 1, 0, 99, 0, 1, '2017-12-21 11:51:11'),
(100, 1, 0, 100, 0, 1, '2017-12-21 11:51:11'),
(101, 1, 0, 101, 0, 1, '2017-12-21 11:51:11'),
(102, 1, 0, 102, 0, 1, '2017-12-21 11:51:12'),
(103, 1, 0, 103, 0, 1, '2017-12-21 11:51:12'),
(104, 1, 0, 104, 0, 1, '2017-12-21 11:51:12'),
(105, 1, 0, 105, 0, 1, '2017-12-21 11:51:12'),
(106, 1, 0, 106, 0, 1, '2017-12-21 11:51:12'),
(107, 1, 0, 107, 0, 1, '2017-12-21 11:51:12'),
(108, 1, 0, 108, 0, 1, '2017-12-21 11:51:12'),
(109, 1, 0, 109, 0, 1, '2017-12-21 11:51:12'),
(110, 1, 0, 110, 0, 1, '2017-12-21 11:51:12'),
(111, 1, 0, 111, 0, 1, '2017-12-21 11:51:12'),
(112, 1, 0, 112, 0, 1, '2017-12-21 11:51:12'),
(113, 1, 0, 113, 0, 1, '2017-12-21 11:51:12'),
(114, 1, 0, 114, 0, 1, '2017-12-21 11:51:12'),
(115, 1, 0, 115, 0, 1, '2017-12-21 11:51:12'),
(116, 1, 0, 116, 0, 1, '2017-12-21 11:51:12'),
(117, 1, 0, 117, 0, 1, '2017-12-21 11:51:12'),
(118, 1, 0, 118, 0, 1, '2017-12-21 11:51:12'),
(119, 1, 0, 119, 0, 1, '2017-12-21 11:51:12'),
(120, 1, 0, 120, 0, 1, '2017-12-21 11:51:13'),
(121, 1, 0, 121, 0, 1, '2017-12-21 11:51:13'),
(122, 1, 0, 122, 0, 1, '2017-12-21 11:51:13'),
(123, 1, 0, 123, 0, 1, '2017-12-21 11:51:13'),
(124, 1, 0, 124, 0, 1, '2017-12-21 11:51:13'),
(125, 1, 0, 125, 0, 1, '2017-12-21 11:51:13'),
(126, 1, 0, 126, 0, 1, '2017-12-21 11:51:13'),
(127, 1, 0, 127, 0, 1, '2017-12-21 11:51:13'),
(128, 1, 0, 128, 0, 1, '2017-12-21 11:51:13'),
(129, 1, 0, 129, 0, 1, '2017-12-21 11:51:13'),
(130, 1, 0, 130, 0, 1, '2017-12-21 11:51:13'),
(131, 1, 0, 131, 0, 1, '2017-12-21 11:51:13'),
(132, 1, 0, 132, 0, 1, '2017-12-21 11:51:13'),
(133, 1, 0, 133, 0, 1, '2017-12-21 11:51:13'),
(134, 1, 0, 134, 0, 1, '2017-12-21 11:51:14'),
(135, 1, 0, 135, 0, 1, '2017-12-21 11:51:14'),
(136, 1, 0, 136, 0, 1, '2017-12-21 11:51:14'),
(137, 1, 0, 137, 0, 1, '2017-12-21 11:51:14'),
(138, 1, 0, 138, 0, 1, '2017-12-21 11:51:14'),
(139, 1, 0, 139, 0, 1, '2017-12-21 11:51:14'),
(140, 1, 0, 140, 0, 1, '2017-12-21 11:51:14'),
(141, 1, 0, 141, 0, 1, '2017-12-21 11:51:14'),
(142, 1, 0, 142, 0, 1, '2017-12-21 11:51:14'),
(143, 1, 0, 143, 0, 1, '2017-12-21 11:51:14'),
(144, 1, 0, 144, 0, 1, '2017-12-21 11:51:14'),
(145, 1, 0, 145, 0, 1, '2017-12-21 11:51:15'),
(146, 1, 0, 146, 0, 1, '2017-12-21 11:51:15'),
(147, 1, 0, 147, 0, 1, '2017-12-21 11:51:15'),
(148, 1, 0, 148, 0, 1, '2017-12-21 11:51:15'),
(149, 1, 0, 149, 0, 1, '2017-12-21 11:51:15'),
(150, 1, 0, 150, 0, 1, '2017-12-21 11:51:15'),
(151, 1, 0, 151, 0, 1, '2017-12-21 11:51:15'),
(152, 1, 0, 152, 0, 1, '2017-12-21 11:51:15'),
(153, 1, 0, 153, 0, 1, '2017-12-21 11:51:15'),
(154, 1, 0, 154, 0, 1, '2017-12-21 11:51:15'),
(155, 1, 0, 155, 0, 1, '2017-12-21 11:51:15'),
(156, 1, 0, 156, 0, 1, '2017-12-21 11:51:16'),
(157, 1, 0, 157, 0, 1, '2017-12-21 11:51:16'),
(158, 1, 0, 158, 0, 1, '2017-12-21 11:51:16'),
(159, 1, 0, 159, 0, 1, '2017-12-21 11:51:16'),
(160, 1, 0, 160, 0, 1, '2017-12-21 11:51:16'),
(161, 1, 0, 161, 0, 1, '2017-12-21 11:51:16'),
(162, 1, 0, 162, 0, 1, '2017-12-21 11:51:16'),
(163, 1, 0, 163, 0, 1, '2017-12-21 11:51:17'),
(164, 1, 0, 164, 0, 1, '2017-12-21 11:51:17'),
(165, 1, 0, 165, 0, 1, '2017-12-21 11:51:17'),
(166, 1, 0, 166, 0, 1, '2017-12-21 11:51:17'),
(167, 1, 0, 167, 0, 1, '2017-12-21 11:51:17'),
(168, 1, 0, 168, 0, 1, '2017-12-21 11:51:17'),
(169, 1, 0, 169, 0, 1, '2017-12-21 11:51:18'),
(170, 1, 0, 170, 0, 1, '2017-12-21 11:51:18'),
(171, 1, 0, 171, 0, 1, '2017-12-21 11:51:18'),
(172, 1, 0, 172, 0, 1, '2017-12-21 11:51:18'),
(173, 1, 0, 173, 0, 1, '2017-12-21 11:51:18'),
(174, 1, 0, 174, 0, 1, '2017-12-21 11:51:18'),
(175, 1, 0, 175, 0, 1, '2017-12-21 11:51:18'),
(176, 1, 0, 176, 0, 1, '2017-12-21 11:51:19'),
(177, 1, 0, 177, 0, 1, '2017-12-21 11:51:19'),
(178, 1, 0, 178, 0, 1, '2017-12-21 11:51:19'),
(179, 1, 0, 179, 0, 1, '2017-12-21 11:51:19'),
(180, 1, 0, 180, 0, 1, '2017-12-21 11:51:19'),
(181, 1, 0, 181, 0, 1, '2017-12-21 11:51:19'),
(182, 1, 0, 182, 0, 1, '2017-12-21 11:51:20'),
(183, 1, 0, 183, 0, 1, '2017-12-21 11:51:20'),
(184, 1, 0, 184, 0, 1, '2017-12-21 11:51:20'),
(185, 1, 0, 185, 0, 1, '2017-12-21 11:51:20'),
(186, 1, 0, 186, 0, 1, '2017-12-21 11:51:20'),
(187, 1, 0, 187, 0, 1, '2017-12-21 11:51:21'),
(188, 1, 0, 188, 0, 1, '2017-12-21 11:51:21'),
(189, 1, 0, 189, 0, 1, '2017-12-21 11:51:21'),
(190, 1, 0, 190, 0, 1, '2017-12-21 11:51:21'),
(191, 1, 0, 191, 0, 1, '2017-12-21 11:51:21'),
(192, 1, 0, 192, 0, 1, '2017-12-21 11:51:21'),
(193, 1, 0, 193, 0, 1, '2017-12-21 11:51:22'),
(194, 1, 0, 194, 0, 1, '2017-12-21 11:51:22'),
(195, 1, 0, 195, 0, 1, '2017-12-21 11:51:22'),
(196, 1, 0, 196, 0, 1, '2017-12-21 11:51:22'),
(197, 1, 0, 197, 0, 1, '2017-12-21 11:51:22'),
(198, 1, 0, 198, 0, 1, '2017-12-21 11:51:23'),
(199, 1, 0, 199, 0, 1, '2017-12-21 11:51:23'),
(200, 1, 0, 200, 0, 1, '2017-12-21 11:51:23'),
(201, 1, 0, 201, 0, 1, '2017-12-21 11:51:23'),
(202, 1, 0, 202, 0, 1, '2017-12-21 11:51:23'),
(203, 1, 0, 203, 0, 1, '2017-12-21 11:51:23'),
(204, 1, 0, 204, 0, 1, '2017-12-21 11:51:24'),
(205, 1, 0, 205, 0, 1, '2017-12-21 11:51:24'),
(206, 1, 0, 206, 0, 1, '2017-12-21 11:51:24'),
(207, 1, 0, 207, 0, 1, '2017-12-21 11:51:24'),
(208, 1, 0, 208, 0, 1, '2017-12-21 11:51:24'),
(209, 1, 0, 209, 0, 1, '2017-12-21 11:51:25'),
(210, 1, 0, 210, 0, 1, '2017-12-21 11:51:25'),
(211, 1, 0, 211, 0, 1, '2017-12-21 11:51:25'),
(212, 1, 0, 212, 0, 1, '2017-12-21 11:51:25'),
(213, 1, 0, 213, 0, 1, '2017-12-21 11:51:25'),
(214, 1, 0, 214, 0, 1, '2017-12-21 11:51:26'),
(215, 1, 0, 215, 0, 1, '2017-12-21 11:51:26'),
(216, 1, 0, 216, 0, 1, '2017-12-21 11:51:26'),
(217, 1, 0, 217, 0, 1, '2017-12-21 11:51:26'),
(218, 1, 0, 218, 0, 1, '2017-12-21 11:51:26'),
(219, 1, 0, 219, 0, 1, '2017-12-21 11:51:26'),
(220, 1, 0, 220, 0, 1, '2017-12-21 11:51:27'),
(221, 1, 0, 221, 0, 1, '2017-12-21 11:51:27'),
(222, 1, 0, 222, 0, 1, '2017-12-21 11:51:27'),
(223, 1, 0, 223, 0, 1, '2017-12-21 11:51:27'),
(224, 1, 0, 224, 0, 1, '2017-12-21 11:51:27'),
(225, 1, 0, 225, 0, 1, '2017-12-21 11:51:27'),
(226, 1, 0, 226, 0, 1, '2017-12-21 11:51:27'),
(227, 1, 0, 227, 0, 1, '2017-12-21 11:51:27'),
(228, 1, 0, 228, 0, 1, '2017-12-21 11:51:27'),
(229, 1, 0, 229, 0, 1, '2017-12-21 11:51:27'),
(230, 1, 0, 230, 0, 1, '2017-12-21 11:51:27'),
(231, 1, 0, 231, 0, 1, '2017-12-21 11:51:27'),
(232, 1, 0, 232, 0, 1, '2017-12-21 11:51:27'),
(233, 1, 0, 233, 0, 1, '2017-12-21 11:51:27'),
(234, 1, 0, 234, 0, 1, '2017-12-21 11:51:28'),
(235, 1, 0, 235, 0, 1, '2017-12-21 11:51:28'),
(236, 1, 0, 236, 0, 1, '2017-12-21 11:51:28'),
(237, 1, 0, 237, 0, 1, '2017-12-21 11:51:28'),
(238, 1, 0, 238, 0, 1, '2017-12-21 11:51:28'),
(239, 1, 0, 239, 0, 1, '2017-12-21 11:51:28'),
(240, 1, 0, 240, 0, 1, '2017-12-21 11:51:28'),
(241, 1, 0, 241, 0, 1, '2017-12-21 11:51:28'),
(242, 1, 0, 242, 0, 1, '2017-12-21 11:51:28'),
(243, 1, 0, 243, 0, 1, '2017-12-21 11:51:28'),
(244, 1, 0, 244, 0, 1, '2017-12-21 11:51:28'),
(245, 1, 0, 245, 0, 1, '2017-12-21 11:51:28'),
(246, 1, 0, 246, 0, 1, '2017-12-21 11:51:28'),
(247, 1, 0, 247, 0, 1, '2017-12-21 11:51:28'),
(248, 1, 0, 248, 0, 1, '2017-12-21 11:51:28'),
(249, 1, 0, 249, 0, 1, '2017-12-21 11:51:29'),
(250, 1, 0, 250, 0, 1, '2017-12-21 11:51:29'),
(251, 1, 0, 251, 0, 1, '2017-12-21 11:51:29'),
(252, 1, 0, 252, 0, 1, '2017-12-21 11:51:29'),
(253, 1, 0, 253, 0, 1, '2017-12-21 11:51:29'),
(254, 1, 0, 254, 0, 1, '2017-12-21 11:51:29'),
(255, 1, 0, 255, 0, 1, '2017-12-21 11:51:29'),
(256, 1, 0, 256, 0, 1, '2017-12-21 11:51:29'),
(257, 1, 0, 257, 0, 1, '2017-12-21 11:51:29'),
(258, 1, 0, 258, 0, 1, '2017-12-21 11:51:29'),
(259, 1, 0, 259, 0, 1, '2017-12-21 11:51:29'),
(260, 1, 0, 260, 0, 1, '2017-12-21 11:51:30'),
(261, 1, 0, 261, 0, 1, '2017-12-21 11:51:30'),
(262, 1, 0, 262, 0, 1, '2017-12-21 11:51:30'),
(263, 1, 0, 263, 0, 1, '2017-12-21 11:51:30'),
(264, 1, 0, 264, 0, 1, '2017-12-21 11:51:30'),
(265, 1, 0, 265, 0, 1, '2017-12-21 11:51:30'),
(266, 1, 0, 266, 0, 1, '2017-12-21 11:51:30'),
(267, 1, 0, 267, 0, 1, '2017-12-21 11:51:30'),
(268, 1, 0, 268, 0, 1, '2017-12-21 11:51:30'),
(269, 1, 0, 269, 0, 1, '2017-12-21 11:51:30'),
(270, 1, 0, 270, 0, 1, '2017-12-21 11:51:31'),
(271, 1, 0, 271, 0, 1, '2017-12-21 11:51:31'),
(272, 1, 0, 272, 0, 1, '2017-12-21 11:51:31'),
(273, 1, 0, 273, 0, 1, '2017-12-21 11:51:31'),
(274, 1, 0, 274, 0, 1, '2017-12-21 11:51:31'),
(275, 1, 0, 275, 0, 1, '2017-12-21 11:51:31'),
(276, 1, 0, 276, 0, 1, '2017-12-21 11:51:31'),
(277, 1, 0, 277, 0, 1, '2017-12-21 11:51:31'),
(278, 1, 0, 278, 0, 1, '2017-12-21 11:51:32'),
(279, 1, 0, 279, 0, 1, '2017-12-21 11:51:32'),
(280, 1, 0, 280, 0, 1, '2017-12-21 11:51:32'),
(281, 1, 0, 281, 0, 1, '2017-12-21 11:51:32'),
(282, 1, 0, 282, 0, 1, '2017-12-21 11:51:32'),
(283, 1, 0, 283, 0, 1, '2017-12-21 11:51:32'),
(284, 1, 0, 284, 0, 1, '2017-12-21 11:51:33'),
(285, 1, 0, 285, 0, 1, '2017-12-21 11:51:33'),
(286, 1, 0, 286, 0, 1, '2017-12-21 11:51:33'),
(287, 1, 0, 287, 0, 1, '2017-12-21 11:51:33'),
(288, 1, 0, 288, 0, 1, '2017-12-21 11:51:33'),
(289, 1, 0, 289, 0, 1, '2017-12-21 11:51:34'),
(290, 1, 0, 290, 0, 1, '2017-12-21 11:51:34'),
(291, 1, 0, 291, 0, 1, '2017-12-21 11:51:34'),
(292, 1, 0, 292, 0, 1, '2017-12-21 11:51:34'),
(293, 1, 0, 293, 0, 1, '2017-12-21 11:51:34'),
(294, 1, 0, 294, 0, 1, '2017-12-21 11:51:34'),
(295, 1, 0, 295, 0, 1, '2017-12-21 11:51:35'),
(296, 1, 0, 296, 0, 1, '2017-12-21 11:51:35'),
(297, 1, 0, 297, 0, 1, '2017-12-21 11:51:35'),
(298, 1, 0, 298, 0, 1, '2017-12-21 11:51:35'),
(299, 1, 0, 299, 0, 1, '2017-12-21 11:51:35'),
(300, 1, 0, 300, 0, 1, '2017-12-21 11:51:36'),
(301, 1, 0, 301, 0, 1, '2017-12-21 11:51:36'),
(302, 1, 0, 302, 0, 1, '2017-12-21 11:51:36'),
(303, 1, 0, 303, 0, 1, '2017-12-21 11:51:36'),
(304, 1, 0, 304, 0, 1, '2017-12-21 11:51:36'),
(305, 1, 0, 305, 0, 1, '2017-12-21 11:51:37'),
(306, 1, 0, 306, 0, 1, '2017-12-21 11:51:37'),
(307, 1, 0, 307, 0, 1, '2017-12-21 11:51:37'),
(308, 1, 0, 308, 0, 1, '2017-12-21 11:51:37'),
(309, 1, 0, 309, 0, 1, '2017-12-21 11:51:37'),
(310, 1, 0, 310, 0, 1, '2017-12-21 11:51:37'),
(311, 1, 0, 311, 0, 1, '2017-12-21 11:51:37'),
(312, 1, 0, 312, 0, 1, '2017-12-21 11:51:37'),
(313, 1, 0, 313, 0, 1, '2017-12-21 11:51:37'),
(314, 1, 0, 314, 0, 1, '2017-12-21 11:51:37'),
(315, 1, 0, 315, 0, 1, '2017-12-21 11:51:37'),
(316, 1, 0, 316, 0, 1, '2017-12-21 11:51:37'),
(317, 1, 0, 317, 0, 1, '2017-12-21 11:51:37'),
(318, 1, 0, 318, 0, 1, '2017-12-21 11:51:38'),
(319, 1, 0, 319, 0, 1, '2017-12-21 11:51:38'),
(320, 1, 0, 320, 0, 1, '2017-12-21 11:51:38'),
(321, 1, 0, 321, 0, 1, '2017-12-21 11:51:38'),
(322, 1, 0, 322, 0, 1, '2017-12-21 11:51:38'),
(323, 1, 0, 323, 0, 1, '2017-12-21 11:51:38'),
(324, 1, 0, 324, 0, 1, '2017-12-21 11:51:38'),
(325, 1, 0, 325, 0, 1, '2017-12-21 11:51:38'),
(326, 1, 0, 326, 0, 1, '2017-12-21 11:51:38'),
(327, 1, 0, 327, 0, 1, '2017-12-21 11:51:38'),
(328, 1, 0, 328, 0, 1, '2017-12-21 11:51:38'),
(329, 1, 0, 329, 0, 1, '2017-12-21 11:51:39'),
(330, 1, 0, 330, 0, 1, '2017-12-21 11:51:39'),
(331, 1, 0, 331, 0, 1, '2017-12-21 11:51:39'),
(332, 1, 0, 332, 0, 1, '2017-12-21 11:51:39'),
(333, 1, 0, 333, 0, 1, '2017-12-21 11:51:39'),
(334, 1, 0, 334, 0, 1, '2017-12-21 11:51:39'),
(335, 1, 0, 335, 0, 1, '2017-12-21 11:51:39'),
(336, 1, 0, 336, 0, 1, '2017-12-21 11:51:39'),
(337, 1, 0, 337, 0, 1, '2017-12-21 11:51:39'),
(338, 1, 0, 338, 0, 1, '2017-12-21 11:51:39'),
(339, 1, 0, 339, 0, 1, '2017-12-21 11:51:39'),
(340, 1, 0, 340, 0, 1, '2017-12-21 11:51:40'),
(341, 1, 0, 341, 0, 1, '2017-12-21 11:51:40'),
(342, 1, 0, 342, 0, 1, '2017-12-21 11:51:40'),
(343, 1, 0, 343, 0, 1, '2017-12-21 11:51:40'),
(344, 1, 0, 344, 0, 1, '2017-12-21 11:51:40'),
(345, 1, 0, 345, 0, 1, '2017-12-21 11:51:40'),
(346, 1, 0, 346, 0, 1, '2017-12-21 11:51:40'),
(347, 1, 0, 347, 0, 1, '2017-12-21 11:51:40'),
(348, 1, 0, 348, 0, 1, '2017-12-21 11:51:40'),
(349, 1, 0, 349, 0, 1, '2017-12-21 11:51:40'),
(350, 1, 0, 350, 0, 1, '2017-12-21 11:51:40'),
(351, 1, 0, 351, 0, 1, '2017-12-21 11:51:41'),
(352, 1, 0, 352, 0, 1, '2017-12-21 11:51:41'),
(353, 1, 0, 353, 0, 1, '2017-12-21 11:51:41'),
(354, 1, 0, 354, 0, 1, '2017-12-21 11:51:41'),
(355, 1, 0, 355, 0, 1, '2017-12-21 11:51:41'),
(356, 1, 0, 356, 0, 1, '2017-12-21 11:51:41'),
(357, 1, 0, 357, 0, 1, '2017-12-21 11:51:42'),
(358, 1, 0, 358, 0, 1, '2017-12-21 11:51:42'),
(359, 1, 0, 359, 0, 1, '2017-12-21 11:51:42'),
(360, 1, 0, 360, 0, 1, '2017-12-21 11:51:42'),
(361, 1, 0, 361, 0, 1, '2017-12-21 11:51:42'),
(362, 1, 0, 362, 0, 1, '2017-12-21 11:51:42'),
(363, 1, 0, 363, 0, 1, '2017-12-21 11:51:43'),
(364, 1, 0, 364, 0, 1, '2017-12-21 11:51:43'),
(365, 1, 0, 365, 0, 1, '2017-12-21 11:51:43'),
(366, 1, 0, 366, 0, 1, '2017-12-21 11:51:43'),
(367, 1, 0, 367, 0, 1, '2017-12-21 11:51:43'),
(368, 1, 0, 368, 0, 1, '2017-12-21 11:51:44'),
(369, 1, 0, 369, 0, 1, '2017-12-21 11:51:44'),
(370, 1, 0, 370, 0, 1, '2017-12-21 11:51:44'),
(371, 1, 0, 371, 0, 1, '2017-12-21 11:51:44'),
(372, 1, 0, 372, 0, 1, '2017-12-21 11:51:44'),
(373, 1, 0, 373, 0, 1, '2017-12-21 11:51:44'),
(374, 1, 0, 374, 0, 1, '2017-12-21 11:51:45'),
(375, 1, 0, 375, 0, 1, '2017-12-21 11:51:45'),
(376, 1, 0, 376, 0, 1, '2017-12-21 11:51:45'),
(377, 1, 0, 377, 0, 1, '2017-12-21 11:51:45'),
(378, 1, 0, 378, 0, 1, '2017-12-21 11:51:45'),
(379, 1, 0, 379, 0, 1, '2017-12-21 11:51:46'),
(380, 1, 0, 380, 0, 1, '2017-12-21 11:51:46'),
(381, 1, 0, 381, 0, 1, '2017-12-21 11:51:46'),
(382, 1, 0, 382, 0, 1, '2017-12-21 11:51:46'),
(383, 1, 0, 383, 0, 1, '2017-12-21 11:51:46'),
(384, 1, 0, 384, 0, 1, '2017-12-21 11:51:46'),
(385, 1, 0, 385, 0, 1, '2017-12-21 11:51:47'),
(386, 1, 0, 386, 0, 1, '2017-12-21 11:51:47'),
(387, 1, 0, 387, 0, 1, '2017-12-21 11:51:47'),
(388, 1, 0, 388, 0, 1, '2017-12-21 11:51:47'),
(389, 1, 0, 389, 0, 1, '2017-12-21 11:51:47'),
(390, 1, 0, 390, 0, 1, '2017-12-21 11:51:47'),
(391, 1, 0, 391, 0, 1, '2017-12-21 11:51:48'),
(392, 1, 0, 392, 0, 1, '2017-12-21 11:51:48'),
(393, 1, 0, 393, 0, 1, '2017-12-21 11:51:48'),
(394, 1, 0, 394, 0, 1, '2017-12-21 11:51:48'),
(395, 1, 0, 395, 0, 1, '2017-12-21 11:51:48'),
(396, 1, 0, 396, 0, 1, '2017-12-21 11:51:49'),
(397, 1, 0, 397, 0, 1, '2017-12-21 11:51:49'),
(398, 1, 0, 398, 0, 1, '2017-12-21 11:51:49'),
(399, 1, 0, 399, 0, 1, '2017-12-21 11:51:49'),
(400, 1, 0, 400, 0, 1, '2017-12-21 11:51:49'),
(401, 1, 0, 401, 0, 1, '2017-12-21 11:51:49'),
(402, 1, 0, 402, 0, 1, '2017-12-21 11:51:50'),
(403, 1, 0, 403, 0, 1, '2017-12-21 11:51:50'),
(404, 1, 0, 404, 0, 1, '2017-12-21 11:51:50'),
(405, 1, 0, 405, 0, 1, '2017-12-21 11:51:50'),
(406, 1, 0, 406, 0, 1, '2017-12-21 11:51:50'),
(407, 1, 0, 407, 0, 1, '2017-12-21 11:51:50'),
(408, 1, 0, 408, 0, 1, '2017-12-21 11:51:51'),
(409, 1, 0, 409, 0, 1, '2017-12-21 11:51:51'),
(410, 1, 0, 410, 0, 1, '2017-12-21 11:51:51'),
(411, 1, 0, 411, 0, 1, '2017-12-21 11:51:51'),
(412, 1, 0, 412, 0, 1, '2017-12-21 11:51:51'),
(413, 1, 0, 413, 0, 1, '2017-12-21 11:51:52'),
(414, 1, 0, 414, 0, 1, '2017-12-21 11:51:52'),
(415, 1, 0, 415, 0, 1, '2017-12-21 11:51:52'),
(416, 1, 0, 416, 0, 1, '2017-12-21 11:51:52'),
(417, 1, 0, 417, 0, 1, '2017-12-21 11:51:52'),
(418, 1, 0, 418, 0, 1, '2017-12-21 11:51:52'),
(419, 1, 0, 419, 0, 1, '2017-12-21 11:51:52'),
(420, 1, 0, 420, 0, 1, '2017-12-21 11:51:52'),
(421, 1, 0, 421, 0, 1, '2017-12-21 11:51:52'),
(422, 1, 0, 422, 0, 1, '2017-12-21 11:51:52'),
(423, 1, 0, 423, 0, 1, '2017-12-21 11:51:52'),
(424, 1, 0, 424, 0, 1, '2017-12-21 11:51:52'),
(425, 1, 0, 425, 0, 1, '2017-12-21 11:51:52'),
(426, 1, 0, 426, 0, 1, '2017-12-21 11:51:53'),
(427, 1, 0, 427, 0, 1, '2017-12-21 11:51:53'),
(428, 1, 0, 428, 0, 1, '2017-12-21 11:51:53'),
(429, 1, 0, 429, 0, 1, '2017-12-21 11:51:53'),
(430, 1, 0, 430, 0, 1, '2017-12-21 11:51:53'),
(431, 1, 0, 431, 0, 1, '2017-12-21 11:51:53'),
(432, 1, 0, 432, 0, 1, '2017-12-21 11:51:53'),
(433, 1, 0, 433, 0, 1, '2017-12-21 11:51:53'),
(434, 1, 0, 434, 0, 1, '2017-12-21 11:51:53'),
(435, 1, 0, 435, 0, 1, '2017-12-21 11:51:53'),
(436, 1, 0, 436, 0, 1, '2017-12-21 11:51:53'),
(437, 1, 0, 437, 0, 1, '2017-12-21 11:51:53'),
(438, 1, 0, 438, 0, 1, '2017-12-21 11:51:53'),
(439, 1, 0, 439, 0, 1, '2017-12-21 11:51:54'),
(440, 1, 0, 440, 0, 1, '2017-12-21 11:51:54'),
(441, 1, 0, 441, 0, 1, '2017-12-21 11:51:54'),
(442, 1, 0, 442, 0, 1, '2017-12-21 11:51:54'),
(443, 1, 0, 443, 0, 1, '2017-12-21 11:51:54'),
(444, 1, 0, 444, 0, 1, '2017-12-21 11:51:54'),
(445, 1, 0, 445, 0, 1, '2017-12-21 11:51:54'),
(446, 1, 0, 446, 0, 1, '2017-12-21 11:51:54'),
(447, 1, 0, 447, 0, 1, '2017-12-21 11:51:54'),
(448, 1, 0, 448, 0, 1, '2017-12-21 11:51:54'),
(449, 1, 0, 449, 0, 1, '2017-12-21 11:51:54'),
(450, 1, 0, 450, 0, 1, '2017-12-21 11:51:55'),
(451, 1, 0, 451, 0, 1, '2017-12-21 11:51:55'),
(452, 1, 0, 452, 0, 1, '2017-12-21 11:51:55'),
(453, 1, 0, 453, 0, 1, '2017-12-21 11:51:55'),
(454, 1, 0, 454, 0, 1, '2017-12-21 11:51:55'),
(455, 1, 0, 455, 0, 1, '2017-12-21 11:51:55'),
(456, 1, 0, 456, 0, 1, '2017-12-21 11:51:55'),
(457, 1, 0, 457, 0, 1, '2017-12-21 11:51:55'),
(458, 1, 0, 458, 0, 1, '2017-12-21 11:51:55'),
(459, 1, 0, 459, 0, 1, '2017-12-21 11:51:55'),
(460, 1, 0, 460, 0, 1, '2017-12-21 11:51:55'),
(461, 1, 0, 461, 0, 1, '2017-12-21 11:51:56'),
(462, 1, 0, 462, 0, 1, '2017-12-21 11:51:56'),
(463, 1, 0, 463, 0, 1, '2017-12-21 11:51:56'),
(464, 1, 0, 464, 0, 1, '2017-12-21 11:51:56'),
(465, 1, 0, 465, 0, 1, '2017-12-21 11:51:56'),
(466, 1, 0, 466, 0, 1, '2017-12-21 11:51:56'),
(467, 1, 0, 467, 0, 1, '2017-12-21 11:51:56'),
(468, 1, 0, 468, 0, 1, '2017-12-21 11:51:56'),
(469, 1, 0, 469, 0, 1, '2017-12-21 11:51:56'),
(470, 1, 0, 470, 0, 1, '2017-12-21 11:51:56'),
(471, 1, 0, 471, 0, 1, '2017-12-21 11:51:57'),
(472, 1, 0, 472, 0, 1, '2017-12-21 11:51:57'),
(473, 1, 0, 473, 0, 1, '2017-12-21 11:51:57'),
(474, 1, 0, 474, 0, 1, '2017-12-21 11:51:57'),
(475, 1, 0, 475, 0, 1, '2017-12-21 11:51:57'),
(476, 1, 0, 476, 0, 1, '2017-12-21 11:51:57'),
(477, 1, 0, 477, 0, 1, '2017-12-21 11:51:58'),
(478, 1, 0, 478, 0, 1, '2017-12-21 11:51:58'),
(479, 1, 0, 479, 0, 1, '2017-12-21 11:51:58'),
(480, 1, 0, 480, 0, 1, '2017-12-21 11:51:58'),
(481, 1, 0, 481, 0, 1, '2017-12-21 11:51:58'),
(482, 1, 0, 482, 0, 1, '2017-12-21 11:51:59'),
(483, 1, 0, 483, 0, 1, '2017-12-21 11:51:59'),
(484, 1, 0, 484, 0, 1, '2017-12-21 11:51:59'),
(485, 1, 0, 485, 0, 1, '2017-12-21 11:51:59'),
(486, 1, 0, 486, 0, 1, '2017-12-21 11:51:59'),
(487, 1, 0, 487, 0, 1, '2017-12-21 11:51:59'),
(488, 1, 0, 488, 0, 1, '2017-12-21 11:52:00'),
(489, 1, 0, 489, 0, 1, '2017-12-21 11:52:00'),
(490, 1, 0, 490, 0, 1, '2017-12-21 11:52:00'),
(491, 1, 0, 491, 0, 1, '2017-12-21 11:52:00'),
(492, 1, 0, 492, 0, 1, '2017-12-21 11:52:00'),
(493, 1, 0, 493, 0, 1, '2017-12-21 11:52:01'),
(494, 1, 0, 494, 0, 1, '2017-12-21 11:52:01'),
(495, 1, 0, 495, 0, 1, '2017-12-21 11:52:01'),
(496, 1, 0, 496, 0, 1, '2017-12-21 11:52:01'),
(497, 1, 0, 497, 0, 1, '2017-12-21 11:52:01'),
(498, 1, 0, 498, 0, 1, '2017-12-21 11:52:01'),
(499, 1, 0, 499, 0, 1, '2017-12-21 11:52:02'),
(500, 1, 0, 500, 0, 1, '2017-12-21 11:52:02'),
(501, 1, 0, 501, 0, 1, '2017-12-21 11:52:02'),
(502, 1, 0, 502, 0, 1, '2017-12-21 11:52:02'),
(503, 1, 0, 503, 0, 1, '2017-12-21 11:52:02'),
(504, 1, 0, 504, 0, 1, '2017-12-21 11:52:03'),
(505, 1, 0, 505, 0, 1, '2017-12-21 11:52:03'),
(506, 1, 0, 506, 0, 1, '2017-12-21 11:52:03'),
(507, 1, 0, 507, 0, 1, '2017-12-21 11:52:03'),
(508, 1, 0, 508, 0, 1, '2017-12-21 11:52:03'),
(509, 1, 0, 509, 0, 1, '2017-12-21 11:52:04'),
(510, 1, 0, 510, 0, 1, '2017-12-21 11:52:04'),
(511, 1, 0, 511, 0, 1, '2017-12-21 11:52:04'),
(512, 1, 0, 512, 0, 1, '2017-12-21 11:52:04'),
(513, 1, 0, 513, 0, 1, '2017-12-21 11:52:04'),
(514, 1, 0, 514, 0, 1, '2017-12-21 11:52:04'),
(515, 1, 0, 515, 0, 1, '2017-12-21 11:52:04'),
(516, 1, 0, 516, 0, 1, '2017-12-21 11:52:05'),
(517, 1, 0, 517, 0, 1, '2017-12-21 11:52:05'),
(518, 1, 0, 518, 0, 1, '2017-12-21 11:52:05'),
(519, 1, 0, 519, 0, 1, '2017-12-21 11:52:05'),
(520, 1, 0, 520, 0, 1, '2017-12-21 11:52:05'),
(521, 1, 0, 521, 0, 1, '2017-12-21 11:52:05'),
(522, 1, 0, 522, 0, 1, '2017-12-21 11:52:05'),
(523, 1, 0, 523, 0, 1, '2017-12-21 11:52:06'),
(524, 1, 0, 524, 0, 1, '2017-12-21 11:52:06'),
(525, 1, 0, 525, 0, 1, '2017-12-21 11:52:06'),
(526, 1, 0, 526, 0, 1, '2017-12-21 11:52:06'),
(527, 1, 0, 527, 0, 1, '2017-12-21 11:52:06'),
(528, 1, 0, 528, 0, 1, '2017-12-21 11:52:06'),
(529, 1, 0, 529, 0, 1, '2017-12-21 11:52:07'),
(530, 1, 0, 530, 0, 1, '2017-12-21 11:52:07'),
(531, 1, 0, 531, 0, 1, '2017-12-21 11:52:07'),
(532, 1, 0, 532, 0, 1, '2017-12-21 11:52:07'),
(533, 1, 0, 533, 0, 1, '2017-12-21 11:52:07'),
(534, 1, 0, 534, 0, 1, '2017-12-21 11:52:07'),
(535, 1, 0, 535, 0, 1, '2017-12-21 11:52:07'),
(536, 1, 0, 536, 0, 1, '2017-12-21 11:52:07'),
(537, 1, 0, 537, 0, 1, '2017-12-21 11:52:07'),
(538, 1, 0, 538, 0, 1, '2017-12-21 11:52:07'),
(539, 1, 0, 539, 0, 1, '2017-12-21 11:52:07'),
(540, 1, 0, 540, 0, 1, '2017-12-21 11:52:07'),
(541, 1, 0, 541, 0, 1, '2017-12-21 11:52:07'),
(542, 1, 0, 542, 0, 1, '2017-12-21 11:52:07'),
(543, 1, 0, 543, 0, 1, '2017-12-21 11:52:07'),
(544, 1, 0, 544, 0, 1, '2017-12-21 11:52:07'),
(545, 1, 0, 545, 0, 1, '2017-12-21 11:52:07'),
(546, 1, 0, 546, 0, 1, '2017-12-21 11:52:08'),
(547, 1, 0, 547, 0, 1, '2017-12-21 11:52:08'),
(548, 1, 0, 548, 0, 1, '2017-12-21 11:52:08'),
(549, 1, 0, 549, 0, 1, '2017-12-21 11:52:08'),
(550, 1, 0, 550, 0, 1, '2017-12-21 11:52:08'),
(551, 1, 0, 551, 0, 1, '2017-12-21 11:52:08'),
(552, 1, 0, 552, 0, 1, '2017-12-21 11:52:08'),
(553, 1, 0, 553, 0, 1, '2017-12-21 11:52:08'),
(554, 1, 0, 554, 0, 1, '2017-12-21 11:52:08'),
(555, 1, 0, 555, 0, 1, '2017-12-21 11:52:08'),
(556, 1, 0, 556, 0, 1, '2017-12-21 11:52:08'),
(557, 1, 0, 557, 0, 1, '2017-12-21 11:52:08'),
(558, 1, 0, 558, 0, 1, '2017-12-21 11:52:08'),
(559, 1, 0, 559, 0, 1, '2017-12-21 11:52:08'),
(560, 1, 0, 560, 0, 1, '2017-12-21 11:52:09'),
(561, 1, 0, 561, 0, 1, '2017-12-21 11:52:09'),
(562, 1, 0, 562, 0, 1, '2017-12-21 11:52:09'),
(563, 1, 0, 563, 0, 1, '2017-12-21 11:52:09'),
(564, 1, 0, 564, 0, 1, '2017-12-21 11:52:09'),
(565, 1, 0, 565, 0, 1, '2017-12-21 11:52:09'),
(566, 1, 0, 566, 0, 1, '2017-12-21 11:52:09'),
(567, 1, 0, 567, 0, 1, '2017-12-21 11:52:09'),
(568, 1, 0, 568, 0, 1, '2017-12-21 11:52:09'),
(569, 1, 0, 569, 0, 1, '2017-12-21 11:52:10'),
(570, 1, 0, 570, 0, 1, '2017-12-21 11:52:10'),
(571, 1, 0, 571, 0, 1, '2017-12-21 11:52:10'),
(572, 1, 0, 572, 0, 1, '2017-12-21 11:52:10'),
(573, 1, 0, 573, 0, 1, '2017-12-21 11:52:10'),
(574, 1, 0, 574, 0, 1, '2017-12-21 11:52:10'),
(575, 1, 0, 575, 0, 1, '2017-12-21 11:52:10'),
(576, 1, 0, 576, 0, 1, '2017-12-21 11:52:10'),
(577, 1, 0, 577, 0, 1, '2017-12-21 11:52:10'),
(578, 1, 0, 578, 0, 1, '2017-12-21 11:52:11'),
(579, 1, 0, 579, 0, 1, '2017-12-21 11:52:11'),
(580, 1, 0, 580, 0, 1, '2017-12-21 11:52:11'),
(581, 1, 0, 581, 0, 1, '2017-12-21 11:52:11'),
(582, 1, 0, 582, 0, 1, '2017-12-21 11:52:11'),
(583, 1, 0, 583, 0, 1, '2017-12-21 11:52:11'),
(584, 1, 0, 584, 0, 1, '2017-12-21 11:52:12'),
(585, 1, 0, 585, 0, 1, '2017-12-21 11:52:12'),
(586, 1, 0, 586, 0, 1, '2017-12-21 11:52:12'),
(587, 1, 0, 587, 0, 1, '2017-12-21 11:52:12'),
(588, 1, 0, 588, 0, 1, '2017-12-21 11:52:12'),
(589, 1, 0, 589, 0, 1, '2017-12-21 11:52:13'),
(590, 1, 0, 590, 0, 1, '2017-12-21 11:52:13'),
(591, 1, 0, 591, 0, 1, '2017-12-21 11:52:13'),
(592, 1, 0, 592, 0, 1, '2017-12-21 11:52:13'),
(593, 1, 0, 593, 0, 1, '2017-12-21 11:52:13'),
(594, 1, 0, 594, 0, 1, '2017-12-21 11:52:13'),
(595, 1, 0, 595, 0, 1, '2017-12-21 11:52:14'),
(596, 1, 0, 596, 0, 1, '2017-12-21 11:52:14'),
(597, 1, 0, 597, 0, 1, '2017-12-21 11:52:14'),
(598, 1, 0, 598, 0, 1, '2017-12-21 11:52:14'),
(599, 1, 0, 599, 0, 1, '2017-12-21 11:52:14'),
(600, 1, 0, 600, 0, 1, '2017-12-21 11:52:14'),
(601, 1, 0, 601, 0, 1, '2017-12-21 11:52:14'),
(602, 1, 0, 602, 0, 1, '2017-12-21 11:52:14'),
(603, 1, 0, 603, 0, 1, '2017-12-21 11:52:15'),
(604, 1, 0, 604, 0, 1, '2017-12-21 11:52:15'),
(605, 1, 0, 605, 0, 1, '2017-12-21 11:52:15'),
(606, 1, 0, 606, 0, 1, '2017-12-21 11:52:15'),
(607, 1, 0, 607, 0, 1, '2017-12-21 11:52:15'),
(608, 1, 0, 608, 0, 1, '2017-12-21 11:52:15'),
(609, 1, 0, 609, 0, 1, '2017-12-21 11:52:15'),
(610, 1, 0, 610, 0, 1, '2017-12-21 11:52:16'),
(611, 1, 0, 611, 0, 1, '2017-12-21 11:52:16'),
(612, 1, 0, 612, 0, 1, '2017-12-21 11:52:16'),
(613, 1, 0, 613, 0, 1, '2017-12-21 11:52:16'),
(614, 1, 0, 614, 0, 1, '2017-12-21 11:52:16'),
(615, 1, 0, 615, 0, 1, '2017-12-21 11:52:17'),
(616, 1, 0, 616, 0, 1, '2017-12-21 11:52:17'),
(617, 1, 0, 617, 0, 1, '2017-12-21 11:52:17'),
(618, 1, 0, 618, 0, 1, '2017-12-21 11:52:17'),
(619, 1, 0, 619, 0, 1, '2017-12-21 11:52:17'),
(620, 1, 0, 620, 0, 1, '2017-12-21 11:52:17'),
(621, 1, 0, 621, 0, 1, '2017-12-21 11:52:18'),
(622, 1, 0, 622, 0, 1, '2017-12-21 11:52:18'),
(623, 1, 0, 623, 0, 1, '2017-12-21 11:52:18'),
(624, 1, 0, 624, 0, 1, '2017-12-21 11:52:18'),
(625, 1, 0, 625, 0, 1, '2017-12-21 11:52:18'),
(626, 1, 0, 626, 0, 1, '2017-12-21 11:52:19'),
(627, 1, 0, 627, 0, 1, '2017-12-21 11:52:19'),
(628, 1, 0, 628, 0, 1, '2017-12-21 11:52:19'),
(629, 1, 0, 629, 0, 1, '2017-12-21 11:52:19'),
(630, 1, 0, 630, 0, 1, '2017-12-21 11:52:19'),
(631, 1, 0, 631, 0, 1, '2017-12-21 11:52:20'),
(632, 1, 0, 632, 0, 1, '2017-12-21 11:52:20'),
(633, 1, 0, 633, 0, 1, '2017-12-21 11:52:20'),
(634, 1, 0, 634, 0, 1, '2017-12-21 11:52:20'),
(635, 1, 0, 635, 0, 1, '2017-12-21 11:52:20'),
(636, 1, 0, 636, 0, 1, '2017-12-21 11:52:21'),
(637, 1, 0, 637, 0, 1, '2017-12-21 11:52:21'),
(638, 1, 0, 638, 0, 1, '2017-12-21 11:52:21'),
(639, 1, 0, 639, 0, 1, '2017-12-21 11:52:21'),
(640, 1, 0, 640, 0, 1, '2017-12-21 11:52:21'),
(641, 1, 0, 641, 0, 1, '2017-12-21 11:52:21'),
(642, 1, 0, 642, 0, 1, '2017-12-21 11:52:22'),
(643, 1, 0, 643, 0, 1, '2017-12-21 11:52:22'),
(644, 1, 0, 644, 0, 1, '2017-12-21 11:52:22'),
(645, 1, 0, 645, 0, 1, '2017-12-21 11:52:22'),
(646, 1, 0, 646, 0, 1, '2017-12-21 11:52:22'),
(647, 1, 0, 647, 0, 1, '2017-12-21 11:52:23'),
(648, 1, 0, 648, 0, 1, '2017-12-21 11:52:23'),
(649, 1, 0, 649, 0, 1, '2017-12-21 11:52:23'),
(650, 1, 0, 650, 0, 1, '2017-12-21 11:52:23'),
(651, 1, 0, 651, 0, 1, '2017-12-21 11:52:23'),
(652, 1, 0, 652, 0, 1, '2017-12-21 11:52:23'),
(653, 1, 0, 653, 0, 1, '2017-12-21 11:52:24'),
(654, 1, 0, 654, 0, 1, '2017-12-21 11:52:24'),
(655, 1, 0, 655, 0, 1, '2017-12-21 11:52:24'),
(656, 1, 0, 656, 0, 1, '2017-12-21 11:52:24'),
(657, 1, 0, 657, 0, 1, '2017-12-21 11:52:24'),
(658, 1, 0, 658, 0, 1, '2017-12-21 11:52:25'),
(659, 1, 0, 659, 0, 1, '2017-12-21 11:52:25'),
(660, 1, 0, 660, 0, 1, '2017-12-21 11:52:25'),
(661, 1, 0, 661, 0, 1, '2017-12-21 11:52:25'),
(662, 1, 0, 662, 0, 1, '2017-12-21 11:52:25'),
(663, 1, 0, 663, 0, 1, '2017-12-21 11:52:25'),
(664, 1, 0, 664, 0, 1, '2017-12-21 11:52:26'),
(665, 1, 0, 665, 0, 1, '2017-12-21 11:52:26'),
(666, 1, 0, 666, 12, 1, '2017-12-21 11:53:58'),
(667, 1, 0, 667, 100, 1, '2017-12-21 11:53:58'),
(674, 1, 0, 8, 1500, 2, '2017-12-22 06:31:10'),
(675, 1, 0, 9, 1000, 2, '2017-12-22 06:31:10'),
(676, 1, 1, 8, 1500, 3, '2017-12-22 06:32:07'),
(677, 1, 1, 9, 1000, 3, '2017-12-22 06:32:07'),
(678, 1, 0, 8, 50, 2, '2017-12-22 06:37:33'),
(679, 1, 0, 9, 100, 2, '2017-12-22 06:37:33'),
(680, 1, 0, 8, 450, 2, '2017-12-22 06:39:55'),
(681, 1, 0, 9, 900, 2, '2017-12-22 06:39:55'),
(682, 1, 0, 10, 1300, 2, '2017-12-22 10:13:41'),
(683, 1, 0, 10, 1300, 2, '2017-12-22 10:15:27'),
(684, 1, 0, 10, 1200, 2, '2017-12-22 10:18:20'),
(685, 1, 0, 10, 1200, 2, '2017-12-22 10:19:05'),
(686, 1, 0, 10, 1200, 2, '2017-12-22 10:20:05'),
(687, 1, 0, 15, 2000, 2, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `material_type`
--

CREATE TABLE IF NOT EXISTS `material_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `material_type`
--

INSERT INTO `material_type` (`id`, `name`, `status`) VALUES
(1, 'civil', 1),
(2, 'mechanical', 1),
(3, 'hr', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mrn_current_state`
--

CREATE TABLE IF NOT EXISTS `mrn_current_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mrn_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mrn_current_state`
--

INSERT INTO `mrn_current_state` (`id`, `mrn_id`, `state_id`, `employee_id`, `created_on`) VALUES
(1, 1, 1, 5, '2017-12-22 06:31:10'),
(2, 2, 1, 4, '2017-12-22 06:37:33'),
(3, 3, 1, 4, '2017-12-22 06:39:55'),
(4, 9, 1, 5, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `mrn_state`
--

CREATE TABLE IF NOT EXISTS `mrn_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mrn_state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mrn_state`
--

INSERT INTO `mrn_state` (`id`, `mrn_state`) VALUES
(1, 'create'),
(2, 'approved'),
(3, 'check');

-- --------------------------------------------------------

--
-- Table structure for table `mrn_state_mapping`
--

CREATE TABLE IF NOT EXISTS `mrn_state_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `next_state_id` int(11) NOT NULL,
  `next_role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mrn_state_mapping`
--

INSERT INTO `mrn_state_mapping` (`id`, `state`, `role_id`, `next_state_id`, `next_role_id`) VALUES
(1, 1, 12, 3, 14),
(2, 2, 14, 0, 0),
(3, 3, 14, 2, 14);

-- --------------------------------------------------------

--
-- Table structure for table `nature`
--

CREATE TABLE IF NOT EXISTS `nature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `nature`
--

INSERT INTO `nature` (`id`, `name`, `site_id`) VALUES
(1, 'Debitable', 1),
(2, 'Returnable', 1),
(3, 'Free issue', 1);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `created_on`, `status`) VALUES
(1, 'sites', '2017-10-06 01:16:18', 0),
(2, 'Requistion Slip', '2017-10-06 01:16:18', 0),
(3, 'Indent', '2017-10-06 01:16:50', 0),
(4, 'Purchase Order', '2017-10-06 01:16:50', 0),
(5, 'Issue Slips', '2017-10-06 01:16:59', 0);

-- --------------------------------------------------------

--
-- Table structure for table `permissions_mapping`
--

CREATE TABLE IF NOT EXISTS `permissions_mapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `emp_id` bigint(20) NOT NULL,
  `permission_id` bigint(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `permissions_mapping`
--

INSERT INTO `permissions_mapping` (`id`, `emp_id`, `permission_id`, `created_on`) VALUES
(1, 1, 1, '2017-10-09 04:41:06'),
(2, 1, 2, '2017-10-09 04:41:06'),
(3, 2, 1, '2017-10-09 06:58:10'),
(4, 2, 3, '2017-10-09 06:58:10'),
(5, 2, 5, '2017-10-09 06:58:10'),
(6, 3, 1, '2017-11-01 12:02:23'),
(7, 3, 2, '2017-11-01 12:02:23'),
(8, 3, 3, '2017-11-01 12:02:23'),
(9, 3, 4, '2017-11-01 12:02:23'),
(10, 3, 5, '2017-11-01 12:02:23'),
(11, 4, 1, '2017-11-01 12:04:21'),
(12, 4, 2, '2017-11-01 12:04:21'),
(13, 4, 3, '2017-11-01 12:04:21'),
(14, 4, 4, '2017-11-01 12:04:21'),
(15, 4, 5, '2017-11-01 12:04:21'),
(16, 5, 1, '2017-11-14 04:06:02'),
(17, 5, 2, '2017-11-14 04:06:02'),
(18, 5, 3, '2017-11-14 04:06:02'),
(19, 5, 4, '2017-11-14 04:06:02'),
(20, 5, 5, '2017-11-14 04:06:02'),
(21, 6, 1, '2017-11-19 04:50:18'),
(22, 6, 2, '2017-11-19 04:50:18'),
(23, 6, 3, '2017-11-19 04:50:19'),
(24, 7, 1, '2017-11-21 06:01:40'),
(25, 7, 2, '2017-11-21 06:01:40'),
(26, 7, 3, '2017-11-21 06:01:40'),
(27, 7, 4, '2017-11-21 06:01:40'),
(28, 7, 5, '2017-11-21 06:01:40');

-- --------------------------------------------------------

--
-- Table structure for table `po_current_state`
--

CREATE TABLE IF NOT EXISTS `po_current_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `po_current_state`
--

INSERT INTO `po_current_state` (`id`, `po_id`, `state_id`, `employee_id`, `created_on`) VALUES
(1, 1, 1, 7, '2017-12-22 06:29:41'),
(2, 1, 4, 8, '2017-12-22 06:30:05'),
(3, 1, 5, 7, '2017-12-22 06:30:26'),
(4, 2, 1, 7, '2017-12-22 06:35:48'),
(5, 2, 4, 8, '2017-12-22 06:36:10'),
(6, 2, 5, 7, '2017-12-22 06:36:34'),
(7, 3, 1, 7, '2017-12-22 07:34:09'),
(8, 3, 4, 8, '2017-12-22 07:34:43'),
(9, 3, 5, 7, '2017-12-22 07:35:32');

-- --------------------------------------------------------

--
-- Table structure for table `po_state`
--

CREATE TABLE IF NOT EXISTS `po_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `po_state`
--

INSERT INTO `po_state` (`id`, `po_state`) VALUES
(1, 'create'),
(2, 'checked'),
(3, 'verified'),
(4, 'approved'),
(5, 'Issue');

-- --------------------------------------------------------

--
-- Table structure for table `po_state_mapping`
--

CREATE TABLE IF NOT EXISTS `po_state_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `next_state_id` int(11) NOT NULL,
  `next_role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `po_state_mapping`
--

INSERT INTO `po_state_mapping` (`id`, `state`, `role_id`, `next_state_id`, `next_role_id`) VALUES
(1, 1, 7, 4, 9),
(2, 4, 9, 5, 7),
(3, 5, 7, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `po_track`
--

CREATE TABLE IF NOT EXISTS `po_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `status` enum('po_created','po_approved','po_rejected','mrn_created','po_issued','mrn_partially_generated') NOT NULL,
  `employee_id` int(11) NOT NULL,
  `comment` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `po_track`
--

INSERT INTO `po_track` (`id`, `po_id`, `status`, `employee_id`, `comment`, `created_on`) VALUES
(1, 1, 'po_created', 7, NULL, '2017-12-22 06:29:41'),
(2, 1, 'po_approved', 8, NULL, '2017-12-22 06:30:05'),
(3, 1, 'po_issued', 7, NULL, '2017-12-22 06:30:27'),
(4, 1, 'mrn_created', 5, NULL, '2017-12-22 06:31:10'),
(5, 2, 'po_created', 7, NULL, '2017-12-22 06:35:48'),
(6, 2, 'po_approved', 8, NULL, '2017-12-22 06:36:10'),
(7, 2, 'po_issued', 7, NULL, '2017-12-22 06:36:34'),
(8, 2, 'mrn_partially_generated', 4, NULL, '2017-12-22 06:37:33'),
(9, 2, 'mrn_created', 4, NULL, '2017-12-22 06:39:55'),
(10, 3, 'po_created', 7, NULL, '2017-12-22 07:34:09'),
(11, 3, 'po_approved', 8, NULL, '2017-12-22 07:34:43'),
(12, 3, 'po_issued', 7, NULL, '2017-12-22 07:35:32'),
(13, 3, 'mrn_created', 5, NULL, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE IF NOT EXISTS `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(255) NOT NULL,
  `reg_date` varchar(20) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `reporting_person_id` int(11) NOT NULL,
  `exp_del_date` varchar(50) DEFAULT NULL,
  `billing_address` text,
  `delivery_address` text,
  `prepared_by_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_amount` varchar(25) NOT NULL DEFAULT '0',
  `freight` double NOT NULL DEFAULT '0',
  `terms_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `mode_of_dispatch` text,
  `forced_closed` int(11) NOT NULL DEFAULT '0' COMMENT '0->open,1->closed',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1->open 2->approved 3->reject 4->fully approved 5->mrn generated',
  PRIMARY KEY (`id`),
  KEY `fk_purchase_orders_1_idx` (`department_id`),
  KEY `fk_purchase_orders_4_idx` (`prepared_by_id`),
  KEY `fk_purchase_orders_2_idx` (`supplier_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `po_number`, `reg_date`, `department_id`, `supplier_id`, `reporting_person_id`, `exp_del_date`, `billing_address`, `delivery_address`, `prepared_by_id`, `created_on`, `total_amount`, `freight`, `terms_id`, `address_id`, `mode_of_dispatch`, `forced_closed`, `status`) VALUES
(1, '2017-12-2206:28:390.85289400', '22/12/2017', 1, 1, 2, '22/12/2017', NULL, NULL, 7, '2017-12-22 06:29:41', '25994.50', 1000, 5, 8, 'by truck', 0, 5),
(2, '2017-12-2206:34:380.98454900', '22/12/2017', 1, 1, 2, '22/12/2017', NULL, NULL, 7, '2017-12-22 06:35:48', '138250.00', 1000, 3, 4, 'dfg', 0, 5),
(3, '2017-12-2207:31:260.32379500', '22/12/2017', 1, 1, 2, '22/12/2017', NULL, NULL, 7, '2017-12-22 07:34:09', '30925.00', 1000, 5, 8, 'by plain', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_files`
--

CREATE TABLE IF NOT EXISTS `purchase_order_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) NOT NULL,
  `file` text,
  `original_name` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_items`
--

CREATE TABLE IF NOT EXISTS `purchase_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `indent_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `rate` float(11,2) NOT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `gst` float(11,2) DEFAULT NULL,
  `amount` float(11,2) NOT NULL,
  `freight` float(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_purchase_order_items_material_id_idx` (`material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `purchase_order_items`
--

INSERT INTO `purchase_order_items` (`id`, `po_id`, `indent_id`, `material_id`, `equipment_id`, `quantity`, `rate`, `discount`, `gst`, `amount`, `freight`) VALUES
(1, 1, 1, 8, NULL, 1500, 10.00, 1, 1.00, 15000.00, NULL),
(2, 1, 1, 9, NULL, 1000, 10.00, 2, 2.00, 10000.00, NULL),
(3, 2, 2, 8, NULL, 500, 100.00, 10, 5.00, 50000.00, NULL),
(4, 2, 2, 9, NULL, 1000, 100.00, 10, 5.00, 100000.00, NULL),
(5, 3, 3, 10, NULL, 1000, 10.00, 5, 5.00, 10000.00, NULL),
(6, 3, 3, 15, NULL, 2000, 10.00, 5, 5.00, 20000.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `requisition`
--

CREATE TABLE IF NOT EXISTS `requisition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_no` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `registered_on` varchar(20) DEFAULT NULL,
  `issue_to_dep_id` int(11) DEFAULT NULL,
  `issues_to_id` int(11) DEFAULT NULL,
  `prepared_by_id` int(11) NOT NULL,
  `approved_by_id` int(11) NOT NULL,
  `hod_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `nature` int(11) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '0->soft delete 1->open 2->approved 3->reject  4->indent',
  `is_approved` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0> not approved 1->approved',
  `is_issued` int(1) NOT NULL DEFAULT '0',
  `save_to_draft` int(1) NOT NULL DEFAULT '2' COMMENT '1->save to draft 2->save',
  PRIMARY KEY (`id`),
  KEY `fk_requisition_3_idx` (`site_id`),
  KEY `fk_requisition_1_idx` (`department_id`,`issue_to_dep_id`),
  KEY `fk_requisition_3_idx1` (`approved_by_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `requisition`
--

INSERT INTO `requisition` (`id`, `requisition_no`, `department_id`, `registered_on`, `issue_to_dep_id`, `issues_to_id`, `prepared_by_id`, `approved_by_id`, `hod_id`, `site_id`, `nature`, `created_on`, `status`, `is_approved`, `is_issued`, `save_to_draft`) VALUES
(1, 1, 1, '22/12/2017', NULL, 1, 1, 1, 1, 1, NULL, '2017-12-22 06:26:00', 5, 0, 1, 2),
(2, 2, 1, '22/12/2017', NULL, 1, 1, 1, 1, 1, NULL, '2017-12-22 06:33:10', 4, 0, 0, 2),
(3, 3, 1, '22/12/2017', NULL, 1, 1, 1, 1, 1, NULL, '2017-12-22 07:15:30', 4, 0, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `requisition_current_state`
--

CREATE TABLE IF NOT EXISTS `requisition_current_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `requisition_current_state`
--

INSERT INTO `requisition_current_state` (`id`, `requisition_id`, `state_id`, `employee_id`, `created_on`) VALUES
(1, 1, 1, 1, '2017-12-22 06:26:00'),
(2, 1, 4, 1, '2017-12-22 06:26:17'),
(3, 2, 1, 1, '2017-12-22 06:33:10'),
(4, 2, 4, 1, '2017-12-22 06:33:13'),
(5, 3, 1, 1, '2017-12-22 07:15:30'),
(6, 3, 4, 1, '2017-12-22 07:15:34');

-- --------------------------------------------------------

--
-- Table structure for table `requisition_file`
--

CREATE TABLE IF NOT EXISTS `requisition_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ri_id` int(11) NOT NULL,
  `requisition_file` text,
  `file_real_name` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `requisition_files`
--

CREATE TABLE IF NOT EXISTS `requisition_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `file` text,
  `original_name` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `requisition_items`
--

CREATE TABLE IF NOT EXISTS `requisition_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `material_brand_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `purpose` text,
  `remarks` text,
  `current_reading` bigint(20) DEFAULT NULL,
  `last_reading` bigint(20) DEFAULT NULL,
  `issue_to` varchar(255) DEFAULT NULL,
  `issue_type` int(1) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_requisition_items_1_idx` (`requisition_id`),
  KEY `fk_requisition_items_2_idx` (`material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `requisition_items`
--

INSERT INTO `requisition_items` (`id`, `requisition_id`, `material_id`, `equipment_id`, `material_brand_id`, `quantity`, `purpose`, `remarks`, `current_reading`, `last_reading`, `issue_to`, `issue_type`, `location_id`, `created_on`) VALUES
(1, 1, 9, NULL, 1, 1000, 'sdafkjsd', 'kljvgl', NULL, NULL, '9', 1, 8, '2017-12-22 06:26:00'),
(2, 1, 8, NULL, 1, 1500, 'hbdfsj', 'JCVNK', NULL, NULL, '2', 1, 8, '2017-12-22 06:26:00'),
(3, 2, 8, NULL, 1, 500, 'dsfj', 'kjdsvhf', NULL, NULL, '1', 1, 4, '2017-12-22 06:33:10'),
(4, 2, 9, NULL, 1, 1000, 'sdfkjh`', 'dksfj', NULL, NULL, '1', 1, 8, '2017-12-22 06:33:10'),
(5, 3, 10, NULL, 1, 1000, 'dsfkjs', 'kjdsnfkjs', NULL, NULL, '2', 1, 8, '2017-12-22 07:15:30'),
(6, 3, 15, NULL, 1, 2000, 'asfk', 'klasdf', NULL, NULL, '4', 1, 8, '2017-12-22 07:15:30');

-- --------------------------------------------------------

--
-- Table structure for table `requisition_nature`
--

CREATE TABLE IF NOT EXISTS `requisition_nature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `nature_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_requisition_nature_1_idx` (`requisition_id`),
  KEY `fk_requisition_nature_idx` (`nature_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `requisition_state`
--

CREATE TABLE IF NOT EXISTS `requisition_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `requisition_state`
--

INSERT INTO `requisition_state` (`id`, `requisition_state`) VALUES
(1, 'create'),
(2, 'checked'),
(3, 'verified'),
(4, 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `requisition_state_mapping`
--

CREATE TABLE IF NOT EXISTS `requisition_state_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `next_state_id` int(11) NOT NULL,
  `next_role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `requisition_state_mapping`
--

INSERT INTO `requisition_state_mapping` (`id`, `state`, `role_id`, `next_state_id`, `next_role_id`) VALUES
(1, 1, 1, 4, 2),
(3, 4, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `requisition_track`
--

CREATE TABLE IF NOT EXISTS `requisition_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `status` enum('requisition_created','requisition_approved','requisition_rejected','requisition_RFI','indent_created','indent_approved','indent_rejected','indent_RFI','po_created','po_approved','po_rejected','mrn_created','issue_slip','soft_deleted','close','po_issued','mrn_partially_generated') NOT NULL,
  `employee_id` int(11) NOT NULL,
  `comment` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `requisition_track`
--

INSERT INTO `requisition_track` (`id`, `requisition_id`, `status`, `employee_id`, `comment`, `created_on`) VALUES
(1, 1, 'requisition_created', 1, NULL, '2017-12-22 06:26:00'),
(2, 1, 'requisition_approved', 1, NULL, '2017-12-22 06:26:17'),
(3, 1, 'indent_created', 5, NULL, '2017-12-22 06:27:03'),
(4, 1, 'indent_approved', 4, NULL, '2017-12-22 06:27:23'),
(5, 1, 'indent_approved', 2, NULL, '2017-12-22 06:27:48'),
(6, 1, 'indent_approved', 11, NULL, '2017-12-22 06:28:02'),
(7, 1, 'po_created', 7, NULL, '2017-12-22 06:29:41'),
(8, 1, 'po_approved', 8, NULL, '2017-12-22 06:30:05'),
(9, 1, 'po_issued', 7, NULL, '2017-12-22 06:30:26'),
(10, 1, 'mrn_created', 5, NULL, '2017-12-22 06:31:10'),
(11, 2, 'requisition_created', 1, NULL, '2017-12-22 06:33:10'),
(12, 2, 'requisition_approved', 1, NULL, '2017-12-22 06:33:13'),
(13, 2, 'indent_created', 4, NULL, '2017-12-22 06:33:32'),
(14, 2, 'indent_approved', 4, NULL, '2017-12-22 06:33:46'),
(15, 2, 'indent_approved', 2, NULL, '2017-12-22 06:33:59'),
(16, 2, 'indent_approved', 11, NULL, '2017-12-22 06:34:13'),
(17, 2, 'po_created', 7, NULL, '2017-12-22 06:35:48'),
(18, 2, 'po_approved', 8, NULL, '2017-12-22 06:36:10'),
(19, 2, 'po_issued', 7, NULL, '2017-12-22 06:36:34'),
(20, 2, 'mrn_partially_generated', 4, NULL, '2017-12-22 06:37:33'),
(21, 2, 'mrn_created', 4, NULL, '2017-12-22 06:39:55'),
(22, 3, 'requisition_created', 1, NULL, '2017-12-22 07:15:30'),
(23, 3, 'requisition_approved', 1, NULL, '2017-12-22 07:15:34'),
(24, 3, 'indent_created', 5, NULL, '2017-12-22 07:23:12'),
(25, 3, 'indent_approved', 4, NULL, '2017-12-22 07:24:27'),
(26, 3, 'indent_approved', 2, NULL, '2017-12-22 07:24:44'),
(27, 3, 'indent_approved', 11, NULL, '2017-12-22 07:31:08'),
(28, 3, 'po_created', 7, NULL, '2017-12-22 07:34:09'),
(29, 3, 'po_approved', 8, NULL, '2017-12-22 07:34:43'),
(30, 3, 'po_issued', 7, NULL, '2017-12-22 07:35:32'),
(31, 3, 'mrn_created', 5, NULL, '2017-12-22 10:20:05');

-- --------------------------------------------------------

--
-- Table structure for table `ri_requisition`
--

CREATE TABLE IF NOT EXISTS `ri_requisition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(11) NOT NULL,
  `poster_id` int(11) NOT NULL,
  `comment` text CHARACTER SET utf8 NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ri_requisition`
--

INSERT INTO `ri_requisition` (`id`, `requisition_id`, `poster_id`, `comment`, `created_on`) VALUES
(1, 3, 5, 'fdgdfg', '2017-12-22 09:47:22');

-- --------------------------------------------------------

--
-- Table structure for table `Role`
--

CREATE TABLE IF NOT EXISTS `Role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `Role`
--

INSERT INTO `Role` (`id`, `name`) VALUES
(1, 'Create Requisition'),
(2, 'Approve Requisition'),
(3, 'Create Indent'),
(4, 'Check Indent'),
(5, 'Approve Indent'),
(6, 'ho planning'),
(7, 'Create PO'),
(8, 'account'),
(9, 'ceo'),
(10, 'ho_mechanical'),
(11, 'hr'),
(12, 'Create MRN'),
(13, 'Create Issue Slip'),
(14, 'Approve MRN'),
(15, 'Approve Issue Slip');

-- --------------------------------------------------------

--
-- Table structure for table `site`
--

CREATE TABLE IF NOT EXISTS `site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `start_date` varchar(20) NOT NULL,
  `location_id` int(11) NOT NULL,
  `address` text NOT NULL,
  `site_description` text NOT NULL,
  `gst_number` varchar(50) DEFAULT NULL,
  `billing_address` text,
  `end_date` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_site_1_idx` (`company_id`),
  KEY `fk_site_location_idx` (`location_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `site`
--

INSERT INTO `site` (`id`, `company_id`, `site_name`, `start_date`, `location_id`, `address`, `site_description`, `gst_number`, `billing_address`, `end_date`, `created_on`, `status`) VALUES
(1, 1, 'udhyog vihar phase 4 plot no 63 gurgaon', '01-Oct-2017', 1, 'udhyog vihar phase 4 plot no 63 gurgaon hariyana 224064', '2bhk', 'gst12345', 'udhyog vihar phase 4 plot no 63 gurgaon hariyana 224064', '31-Oct-2017', '2017-10-04 11:57:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `site_address`
--

CREATE TABLE IF NOT EXISTS `site_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `store_name` text NOT NULL,
  `delivery_address` longtext NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL COMMENT '0->inactive,1->active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `site_address`
--

INSERT INTO `site_address` (`id`, `site_id`, `store_name`, `delivery_address`, `created_on`, `status`) VALUES
(4, 1, 'Gurgaon', 'plot no 63, udyog vihar phase 4, gurgaon', '2017-12-06 00:28:11', 0),
(5, 7, 'Delhi', 'Delhi', '2017-12-06 00:28:11', 0),
(6, 1, 'Patna', 'Patna', '2017-12-06 00:28:11', 0),
(7, 7, 'Asam', 'Asam', '2017-12-06 00:29:18', 1),
(8, 1, 'Noida', 'Noida', '2017-12-06 00:29:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `site_contractors`
--

CREATE TABLE IF NOT EXISTS `site_contractors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractor_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_site_contractors_1_idx` (`contractor_id`),
  KEY `fk_site_contractors_2_idx` (`site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `site_contractors`
--

INSERT INTO `site_contractors` (`id`, `contractor_id`, `site_id`, `start_date`, `end_date`, `status`, `created_on`) VALUES
(2, 1, 1, NULL, NULL, 1, '2017-10-06 09:01:25');

-- --------------------------------------------------------

--
-- Table structure for table `site_employee`
--

CREATE TABLE IF NOT EXISTS `site_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_site_employee_1_idx` (`emp_id`),
  KEY `fk_site_employee_2_idx` (`site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `site_employee`
--

INSERT INTO `site_employee` (`id`, `emp_id`, `site_id`, `start_date`, `end_date`, `created_on`, `status`) VALUES
(4, 2, 1, NULL, NULL, '2017-11-01 12:21:42', 1),
(5, 1, 1, NULL, NULL, '2017-11-01 12:22:57', 1),
(6, 4, 1, NULL, NULL, '2017-11-01 12:48:06', 1),
(7, 3, 1, NULL, NULL, '2017-11-07 07:20:23', 1),
(8, 5, 1, NULL, NULL, '2017-11-14 04:06:36', 1),
(9, 6, 1, NULL, NULL, '2017-11-19 05:12:39', 1),
(10, 7, 1, NULL, NULL, '2017-11-21 06:04:18', 1),
(11, 8, 1, NULL, NULL, '2017-11-30 06:37:14', 1),
(12, 10, 1, NULL, NULL, '2017-11-30 09:45:32', 1),
(13, 11, 1, NULL, NULL, '2017-11-30 10:25:53', 1),
(14, 12, 1, NULL, NULL, '2017-12-04 11:38:45', 1),
(15, 15, 1, NULL, NULL, '2017-12-14 12:08:12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `site_equipment`
--

CREATE TABLE IF NOT EXISTS `site_equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipment_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_site_equipment_1_idx` (`equipment_id`),
  KEY `fk_site_equipment_2_idx` (`site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `site_equipment`
--

INSERT INTO `site_equipment` (`id`, `equipment_id`, `site_id`, `start_date`, `end_date`, `created_on`, `status`) VALUES
(1, 1, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(2, 2, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(3, 3, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(4, 4, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(5, 5, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(6, 6, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(7, 7, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(8, 8, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(9, 9, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(10, 10, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(11, 11, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(12, 12, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(13, 13, 1, NULL, NULL, '2017-12-21 11:53:35', 1),
(14, 14, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(15, 15, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(16, 16, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(17, 17, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(18, 18, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(19, 19, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(20, 20, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(21, 21, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(22, 22, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(23, 23, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(24, 24, 1, NULL, NULL, '2017-12-21 11:53:36', 1),
(25, 25, 1, NULL, NULL, '2017-12-21 11:53:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `site_material`
--

CREATE TABLE IF NOT EXISTS `site_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FOREIGN` (`site_id`,`material_id`),
  KEY `material_id` (`material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=668 ;

--
-- Dumping data for table `site_material`
--

INSERT INTO `site_material` (`id`, `site_id`, `material_id`, `start_date`, `end_date`, `quantity`, `created_on`, `status`) VALUES
(1, 1, 1, NULL, NULL, 0, '2017-12-21 11:50:12', 1),
(2, 1, 2, NULL, NULL, 0, '2017-12-21 11:50:12', 1),
(3, 1, 3, NULL, NULL, 0, '2017-12-21 11:50:12', 1),
(4, 1, 4, NULL, NULL, 0, '2017-12-21 11:50:12', 1),
(5, 1, 5, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(6, 1, 6, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(7, 1, 7, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(8, 1, 8, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(9, 1, 9, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(10, 1, 10, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(11, 1, 11, NULL, NULL, 0, '2017-12-21 11:50:13', 1),
(12, 1, 12, NULL, NULL, 0, '2017-12-21 11:50:14', 1),
(13, 1, 13, NULL, NULL, 0, '2017-12-21 11:50:14', 1),
(14, 1, 14, NULL, NULL, 0, '2017-12-21 11:50:14', 1),
(15, 1, 15, NULL, NULL, 0, '2017-12-21 11:50:14', 1),
(16, 1, 16, NULL, NULL, 0, '2017-12-21 11:50:14', 1),
(17, 1, 17, NULL, NULL, 0, '2017-12-21 11:50:15', 1),
(18, 1, 18, NULL, NULL, 0, '2017-12-21 11:50:15', 1),
(19, 1, 19, NULL, NULL, 0, '2017-12-21 11:50:15', 1),
(20, 1, 20, NULL, NULL, 0, '2017-12-21 11:50:15', 1),
(21, 1, 21, NULL, NULL, 0, '2017-12-21 11:50:15', 1),
(22, 1, 22, NULL, NULL, 0, '2017-12-21 11:50:16', 1),
(23, 1, 23, NULL, NULL, 0, '2017-12-21 11:50:16', 1),
(24, 1, 24, NULL, NULL, 0, '2017-12-21 11:50:16', 1),
(25, 1, 25, NULL, NULL, 0, '2017-12-21 11:50:16', 1),
(26, 1, 26, NULL, NULL, 0, '2017-12-21 11:50:16', 1),
(27, 1, 27, NULL, NULL, 0, '2017-12-21 11:50:16', 1),
(28, 1, 28, NULL, NULL, 0, '2017-12-21 11:50:17', 1),
(29, 1, 29, NULL, NULL, 0, '2017-12-21 11:50:17', 1),
(30, 1, 30, NULL, NULL, 0, '2017-12-21 11:51:02', 1),
(31, 1, 31, NULL, NULL, 0, '2017-12-21 11:51:03', 1),
(32, 1, 32, NULL, NULL, 0, '2017-12-21 11:51:03', 1),
(33, 1, 33, NULL, NULL, 0, '2017-12-21 11:51:03', 1),
(34, 1, 34, NULL, NULL, 0, '2017-12-21 11:51:03', 1),
(35, 1, 35, NULL, NULL, 0, '2017-12-21 11:51:03', 1),
(36, 1, 36, NULL, NULL, 0, '2017-12-21 11:51:04', 1),
(37, 1, 37, NULL, NULL, 0, '2017-12-21 11:51:04', 1),
(38, 1, 38, NULL, NULL, 0, '2017-12-21 11:51:04', 1),
(39, 1, 39, NULL, NULL, 0, '2017-12-21 11:51:04', 1),
(40, 1, 40, NULL, NULL, 0, '2017-12-21 11:51:04', 1),
(41, 1, 41, NULL, NULL, 0, '2017-12-21 11:51:05', 1),
(42, 1, 42, NULL, NULL, 0, '2017-12-21 11:51:05', 1),
(43, 1, 43, NULL, NULL, 0, '2017-12-21 11:51:05', 1),
(44, 1, 44, NULL, NULL, 0, '2017-12-21 11:51:05', 1),
(45, 1, 45, NULL, NULL, 0, '2017-12-21 11:51:05', 1),
(46, 1, 46, NULL, NULL, 0, '2017-12-21 11:51:05', 1),
(47, 1, 47, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(48, 1, 48, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(49, 1, 49, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(50, 1, 50, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(51, 1, 51, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(52, 1, 52, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(53, 1, 53, NULL, NULL, 0, '2017-12-21 11:51:06', 1),
(54, 1, 54, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(55, 1, 55, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(56, 1, 56, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(57, 1, 57, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(58, 1, 58, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(59, 1, 59, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(60, 1, 60, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(61, 1, 61, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(62, 1, 62, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(63, 1, 63, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(64, 1, 64, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(65, 1, 65, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(66, 1, 66, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(67, 1, 67, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(68, 1, 68, NULL, NULL, 0, '2017-12-21 11:51:07', 1),
(69, 1, 69, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(70, 1, 70, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(71, 1, 71, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(72, 1, 72, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(73, 1, 73, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(74, 1, 74, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(75, 1, 75, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(76, 1, 76, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(77, 1, 77, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(78, 1, 78, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(79, 1, 79, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(80, 1, 80, NULL, NULL, 0, '2017-12-21 11:51:08', 1),
(81, 1, 81, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(82, 1, 82, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(83, 1, 83, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(84, 1, 84, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(85, 1, 85, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(86, 1, 86, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(87, 1, 87, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(88, 1, 88, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(89, 1, 89, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(90, 1, 90, NULL, NULL, 0, '2017-12-21 11:51:09', 1),
(91, 1, 91, NULL, NULL, 0, '2017-12-21 11:51:10', 1),
(92, 1, 92, NULL, NULL, 0, '2017-12-21 11:51:10', 1),
(93, 1, 93, NULL, NULL, 0, '2017-12-21 11:51:10', 1),
(94, 1, 94, NULL, NULL, 0, '2017-12-21 11:51:10', 1),
(95, 1, 95, NULL, NULL, 0, '2017-12-21 11:51:10', 1),
(96, 1, 96, NULL, NULL, 0, '2017-12-21 11:51:11', 1),
(97, 1, 97, NULL, NULL, 0, '2017-12-21 11:51:11', 1),
(98, 1, 98, NULL, NULL, 0, '2017-12-21 11:51:11', 1),
(99, 1, 99, NULL, NULL, 0, '2017-12-21 11:51:11', 1),
(100, 1, 100, NULL, NULL, 0, '2017-12-21 11:51:11', 1),
(101, 1, 101, NULL, NULL, 0, '2017-12-21 11:51:11', 1),
(102, 1, 102, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(103, 1, 103, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(104, 1, 104, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(105, 1, 105, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(106, 1, 106, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(107, 1, 107, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(108, 1, 108, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(109, 1, 109, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(110, 1, 110, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(111, 1, 111, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(112, 1, 112, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(113, 1, 113, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(114, 1, 114, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(115, 1, 115, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(116, 1, 116, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(117, 1, 117, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(118, 1, 118, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(119, 1, 119, NULL, NULL, 0, '2017-12-21 11:51:12', 1),
(120, 1, 120, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(121, 1, 121, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(122, 1, 122, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(123, 1, 123, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(124, 1, 124, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(125, 1, 125, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(126, 1, 126, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(127, 1, 127, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(128, 1, 128, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(129, 1, 129, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(130, 1, 130, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(131, 1, 131, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(132, 1, 132, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(133, 1, 133, NULL, NULL, 0, '2017-12-21 11:51:13', 1),
(134, 1, 134, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(135, 1, 135, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(136, 1, 136, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(137, 1, 137, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(138, 1, 138, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(139, 1, 139, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(140, 1, 140, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(141, 1, 141, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(142, 1, 142, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(143, 1, 143, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(144, 1, 144, NULL, NULL, 0, '2017-12-21 11:51:14', 1),
(145, 1, 145, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(146, 1, 146, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(147, 1, 147, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(148, 1, 148, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(149, 1, 149, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(150, 1, 150, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(151, 1, 151, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(152, 1, 152, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(153, 1, 153, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(154, 1, 154, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(155, 1, 155, NULL, NULL, 0, '2017-12-21 11:51:15', 1),
(156, 1, 156, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(157, 1, 157, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(158, 1, 158, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(159, 1, 159, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(160, 1, 160, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(161, 1, 161, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(162, 1, 162, NULL, NULL, 0, '2017-12-21 11:51:16', 1),
(163, 1, 163, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(164, 1, 164, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(165, 1, 165, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(166, 1, 166, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(167, 1, 167, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(168, 1, 168, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(169, 1, 169, NULL, NULL, 0, '2017-12-21 11:51:17', 1),
(170, 1, 170, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(171, 1, 171, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(172, 1, 172, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(173, 1, 173, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(174, 1, 174, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(175, 1, 175, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(176, 1, 176, NULL, NULL, 0, '2017-12-21 11:51:18', 1),
(177, 1, 177, NULL, NULL, 0, '2017-12-21 11:51:19', 1),
(178, 1, 178, NULL, NULL, 0, '2017-12-21 11:51:19', 1),
(179, 1, 179, NULL, NULL, 0, '2017-12-21 11:51:19', 1),
(180, 1, 180, NULL, NULL, 0, '2017-12-21 11:51:19', 1),
(181, 1, 181, NULL, NULL, 0, '2017-12-21 11:51:19', 1),
(182, 1, 182, NULL, NULL, 0, '2017-12-21 11:51:20', 1),
(183, 1, 183, NULL, NULL, 0, '2017-12-21 11:51:20', 1),
(184, 1, 184, NULL, NULL, 0, '2017-12-21 11:51:20', 1),
(185, 1, 185, NULL, NULL, 0, '2017-12-21 11:51:20', 1),
(186, 1, 186, NULL, NULL, 0, '2017-12-21 11:51:20', 1),
(187, 1, 187, NULL, NULL, 0, '2017-12-21 11:51:21', 1),
(188, 1, 188, NULL, NULL, 0, '2017-12-21 11:51:21', 1),
(189, 1, 189, NULL, NULL, 0, '2017-12-21 11:51:21', 1),
(190, 1, 190, NULL, NULL, 0, '2017-12-21 11:51:21', 1),
(191, 1, 191, NULL, NULL, 0, '2017-12-21 11:51:21', 1),
(192, 1, 192, NULL, NULL, 0, '2017-12-21 11:51:21', 1),
(193, 1, 193, NULL, NULL, 0, '2017-12-21 11:51:22', 1),
(194, 1, 194, NULL, NULL, 0, '2017-12-21 11:51:22', 1),
(195, 1, 195, NULL, NULL, 0, '2017-12-21 11:51:22', 1),
(196, 1, 196, NULL, NULL, 0, '2017-12-21 11:51:22', 1),
(197, 1, 197, NULL, NULL, 0, '2017-12-21 11:51:22', 1),
(198, 1, 198, NULL, NULL, 0, '2017-12-21 11:51:22', 1),
(199, 1, 199, NULL, NULL, 0, '2017-12-21 11:51:23', 1),
(200, 1, 200, NULL, NULL, 0, '2017-12-21 11:51:23', 1),
(201, 1, 201, NULL, NULL, 0, '2017-12-21 11:51:23', 1),
(202, 1, 202, NULL, NULL, 0, '2017-12-21 11:51:23', 1),
(203, 1, 203, NULL, NULL, 0, '2017-12-21 11:51:23', 1),
(204, 1, 204, NULL, NULL, 0, '2017-12-21 11:51:24', 1),
(205, 1, 205, NULL, NULL, 0, '2017-12-21 11:51:24', 1),
(206, 1, 206, NULL, NULL, 0, '2017-12-21 11:51:24', 1),
(207, 1, 207, NULL, NULL, 0, '2017-12-21 11:51:24', 1),
(208, 1, 208, NULL, NULL, 0, '2017-12-21 11:51:24', 1),
(209, 1, 209, NULL, NULL, 0, '2017-12-21 11:51:25', 1),
(210, 1, 210, NULL, NULL, 0, '2017-12-21 11:51:25', 1),
(211, 1, 211, NULL, NULL, 0, '2017-12-21 11:51:25', 1),
(212, 1, 212, NULL, NULL, 0, '2017-12-21 11:51:25', 1),
(213, 1, 213, NULL, NULL, 0, '2017-12-21 11:51:25', 1),
(214, 1, 214, NULL, NULL, 0, '2017-12-21 11:51:26', 1),
(215, 1, 215, NULL, NULL, 0, '2017-12-21 11:51:26', 1),
(216, 1, 216, NULL, NULL, 0, '2017-12-21 11:51:26', 1),
(217, 1, 217, NULL, NULL, 0, '2017-12-21 11:51:26', 1),
(218, 1, 218, NULL, NULL, 0, '2017-12-21 11:51:26', 1),
(219, 1, 219, NULL, NULL, 0, '2017-12-21 11:51:26', 1),
(220, 1, 220, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(221, 1, 221, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(222, 1, 222, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(223, 1, 223, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(224, 1, 224, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(225, 1, 225, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(226, 1, 226, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(227, 1, 227, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(228, 1, 228, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(229, 1, 229, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(230, 1, 230, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(231, 1, 231, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(232, 1, 232, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(233, 1, 233, NULL, NULL, 0, '2017-12-21 11:51:27', 1),
(234, 1, 234, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(235, 1, 235, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(236, 1, 236, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(237, 1, 237, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(238, 1, 238, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(239, 1, 239, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(240, 1, 240, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(241, 1, 241, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(242, 1, 242, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(243, 1, 243, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(244, 1, 244, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(245, 1, 245, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(246, 1, 246, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(247, 1, 247, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(248, 1, 248, NULL, NULL, 0, '2017-12-21 11:51:28', 1),
(249, 1, 249, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(250, 1, 250, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(251, 1, 251, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(252, 1, 252, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(253, 1, 253, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(254, 1, 254, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(255, 1, 255, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(256, 1, 256, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(257, 1, 257, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(258, 1, 258, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(259, 1, 259, NULL, NULL, 0, '2017-12-21 11:51:29', 1),
(260, 1, 260, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(261, 1, 261, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(262, 1, 262, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(263, 1, 263, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(264, 1, 264, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(265, 1, 265, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(266, 1, 266, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(267, 1, 267, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(268, 1, 268, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(269, 1, 269, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(270, 1, 270, NULL, NULL, 0, '2017-12-21 11:51:30', 1),
(271, 1, 271, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(272, 1, 272, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(273, 1, 273, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(274, 1, 274, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(275, 1, 275, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(276, 1, 276, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(277, 1, 277, NULL, NULL, 0, '2017-12-21 11:51:31', 1),
(278, 1, 278, NULL, NULL, 0, '2017-12-21 11:51:32', 1),
(279, 1, 279, NULL, NULL, 0, '2017-12-21 11:51:32', 1),
(280, 1, 280, NULL, NULL, 0, '2017-12-21 11:51:32', 1),
(281, 1, 281, NULL, NULL, 0, '2017-12-21 11:51:32', 1),
(282, 1, 282, NULL, NULL, 0, '2017-12-21 11:51:32', 1),
(283, 1, 283, NULL, NULL, 0, '2017-12-21 11:51:32', 1),
(284, 1, 284, NULL, NULL, 0, '2017-12-21 11:51:33', 1),
(285, 1, 285, NULL, NULL, 0, '2017-12-21 11:51:33', 1),
(286, 1, 286, NULL, NULL, 0, '2017-12-21 11:51:33', 1),
(287, 1, 287, NULL, NULL, 0, '2017-12-21 11:51:33', 1),
(288, 1, 288, NULL, NULL, 0, '2017-12-21 11:51:33', 1),
(289, 1, 289, NULL, NULL, 0, '2017-12-21 11:51:33', 1),
(290, 1, 290, NULL, NULL, 0, '2017-12-21 11:51:34', 1),
(291, 1, 291, NULL, NULL, 0, '2017-12-21 11:51:34', 1),
(292, 1, 292, NULL, NULL, 0, '2017-12-21 11:51:34', 1),
(293, 1, 293, NULL, NULL, 0, '2017-12-21 11:51:34', 1),
(294, 1, 294, NULL, NULL, 0, '2017-12-21 11:51:34', 1),
(295, 1, 295, NULL, NULL, 0, '2017-12-21 11:51:35', 1),
(296, 1, 296, NULL, NULL, 0, '2017-12-21 11:51:35', 1),
(297, 1, 297, NULL, NULL, 0, '2017-12-21 11:51:35', 1),
(298, 1, 298, NULL, NULL, 0, '2017-12-21 11:51:35', 1),
(299, 1, 299, NULL, NULL, 0, '2017-12-21 11:51:35', 1),
(300, 1, 300, NULL, NULL, 0, '2017-12-21 11:51:36', 1),
(301, 1, 301, NULL, NULL, 0, '2017-12-21 11:51:36', 1),
(302, 1, 302, NULL, NULL, 0, '2017-12-21 11:51:36', 1),
(303, 1, 303, NULL, NULL, 0, '2017-12-21 11:51:36', 1),
(304, 1, 304, NULL, NULL, 0, '2017-12-21 11:51:36', 1),
(305, 1, 305, NULL, NULL, 0, '2017-12-21 11:51:36', 1),
(306, 1, 306, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(307, 1, 307, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(308, 1, 308, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(309, 1, 309, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(310, 1, 310, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(311, 1, 311, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(312, 1, 312, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(313, 1, 313, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(314, 1, 314, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(315, 1, 315, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(316, 1, 316, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(317, 1, 317, NULL, NULL, 0, '2017-12-21 11:51:37', 1),
(318, 1, 318, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(319, 1, 319, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(320, 1, 320, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(321, 1, 321, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(322, 1, 322, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(323, 1, 323, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(324, 1, 324, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(325, 1, 325, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(326, 1, 326, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(327, 1, 327, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(328, 1, 328, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(329, 1, 329, NULL, NULL, 0, '2017-12-21 11:51:38', 1),
(330, 1, 330, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(331, 1, 331, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(332, 1, 332, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(333, 1, 333, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(334, 1, 334, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(335, 1, 335, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(336, 1, 336, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(337, 1, 337, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(338, 1, 338, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(339, 1, 339, NULL, NULL, 0, '2017-12-21 11:51:39', 1),
(340, 1, 340, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(341, 1, 341, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(342, 1, 342, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(343, 1, 343, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(344, 1, 344, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(345, 1, 345, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(346, 1, 346, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(347, 1, 347, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(348, 1, 348, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(349, 1, 349, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(350, 1, 350, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(351, 1, 351, NULL, NULL, 0, '2017-12-21 11:51:40', 1),
(352, 1, 352, NULL, NULL, 0, '2017-12-21 11:51:41', 1),
(353, 1, 353, NULL, NULL, 0, '2017-12-21 11:51:41', 1),
(354, 1, 354, NULL, NULL, 0, '2017-12-21 11:51:41', 1),
(355, 1, 355, NULL, NULL, 0, '2017-12-21 11:51:41', 1),
(356, 1, 356, NULL, NULL, 0, '2017-12-21 11:51:41', 1),
(357, 1, 357, NULL, NULL, 0, '2017-12-21 11:51:41', 1),
(358, 1, 358, NULL, NULL, 0, '2017-12-21 11:51:42', 1),
(359, 1, 359, NULL, NULL, 0, '2017-12-21 11:51:42', 1),
(360, 1, 360, NULL, NULL, 0, '2017-12-21 11:51:42', 1),
(361, 1, 361, NULL, NULL, 0, '2017-12-21 11:51:42', 1),
(362, 1, 362, NULL, NULL, 0, '2017-12-21 11:51:42', 1),
(363, 1, 363, NULL, NULL, 0, '2017-12-21 11:51:43', 1),
(364, 1, 364, NULL, NULL, 0, '2017-12-21 11:51:43', 1),
(365, 1, 365, NULL, NULL, 0, '2017-12-21 11:51:43', 1),
(366, 1, 366, NULL, NULL, 0, '2017-12-21 11:51:43', 1),
(367, 1, 367, NULL, NULL, 0, '2017-12-21 11:51:43', 1),
(368, 1, 368, NULL, NULL, 0, '2017-12-21 11:51:44', 1),
(369, 1, 369, NULL, NULL, 0, '2017-12-21 11:51:44', 1),
(370, 1, 370, NULL, NULL, 0, '2017-12-21 11:51:44', 1),
(371, 1, 371, NULL, NULL, 0, '2017-12-21 11:51:44', 1),
(372, 1, 372, NULL, NULL, 0, '2017-12-21 11:51:44', 1),
(373, 1, 373, NULL, NULL, 0, '2017-12-21 11:51:44', 1),
(374, 1, 374, NULL, NULL, 0, '2017-12-21 11:51:45', 1),
(375, 1, 375, NULL, NULL, 0, '2017-12-21 11:51:45', 1),
(376, 1, 376, NULL, NULL, 0, '2017-12-21 11:51:45', 1),
(377, 1, 377, NULL, NULL, 0, '2017-12-21 11:51:45', 1),
(378, 1, 378, NULL, NULL, 0, '2017-12-21 11:51:45', 1),
(379, 1, 379, NULL, NULL, 0, '2017-12-21 11:51:45', 1),
(380, 1, 380, NULL, NULL, 0, '2017-12-21 11:51:46', 1),
(381, 1, 381, NULL, NULL, 0, '2017-12-21 11:51:46', 1),
(382, 1, 382, NULL, NULL, 0, '2017-12-21 11:51:46', 1),
(383, 1, 383, NULL, NULL, 0, '2017-12-21 11:51:46', 1),
(384, 1, 384, NULL, NULL, 0, '2017-12-21 11:51:46', 1),
(385, 1, 385, NULL, NULL, 0, '2017-12-21 11:51:47', 1),
(386, 1, 386, NULL, NULL, 0, '2017-12-21 11:51:47', 1),
(387, 1, 387, NULL, NULL, 0, '2017-12-21 11:51:47', 1),
(388, 1, 388, NULL, NULL, 0, '2017-12-21 11:51:47', 1),
(389, 1, 389, NULL, NULL, 0, '2017-12-21 11:51:47', 1),
(390, 1, 390, NULL, NULL, 0, '2017-12-21 11:51:47', 1),
(391, 1, 391, NULL, NULL, 0, '2017-12-21 11:51:48', 1),
(392, 1, 392, NULL, NULL, 0, '2017-12-21 11:51:48', 1),
(393, 1, 393, NULL, NULL, 0, '2017-12-21 11:51:48', 1),
(394, 1, 394, NULL, NULL, 0, '2017-12-21 11:51:48', 1),
(395, 1, 395, NULL, NULL, 0, '2017-12-21 11:51:48', 1),
(396, 1, 396, NULL, NULL, 0, '2017-12-21 11:51:48', 1),
(397, 1, 397, NULL, NULL, 0, '2017-12-21 11:51:49', 1),
(398, 1, 398, NULL, NULL, 0, '2017-12-21 11:51:49', 1),
(399, 1, 399, NULL, NULL, 0, '2017-12-21 11:51:49', 1),
(400, 1, 400, NULL, NULL, 0, '2017-12-21 11:51:49', 1),
(401, 1, 401, NULL, NULL, 0, '2017-12-21 11:51:49', 1),
(402, 1, 402, NULL, NULL, 0, '2017-12-21 11:51:50', 1),
(403, 1, 403, NULL, NULL, 0, '2017-12-21 11:51:50', 1),
(404, 1, 404, NULL, NULL, 0, '2017-12-21 11:51:50', 1),
(405, 1, 405, NULL, NULL, 0, '2017-12-21 11:51:50', 1),
(406, 1, 406, NULL, NULL, 0, '2017-12-21 11:51:50', 1),
(407, 1, 407, NULL, NULL, 0, '2017-12-21 11:51:50', 1),
(408, 1, 408, NULL, NULL, 0, '2017-12-21 11:51:51', 1),
(409, 1, 409, NULL, NULL, 0, '2017-12-21 11:51:51', 1),
(410, 1, 410, NULL, NULL, 0, '2017-12-21 11:51:51', 1),
(411, 1, 411, NULL, NULL, 0, '2017-12-21 11:51:51', 1),
(412, 1, 412, NULL, NULL, 0, '2017-12-21 11:51:51', 1),
(413, 1, 413, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(414, 1, 414, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(415, 1, 415, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(416, 1, 416, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(417, 1, 417, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(418, 1, 418, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(419, 1, 419, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(420, 1, 420, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(421, 1, 421, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(422, 1, 422, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(423, 1, 423, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(424, 1, 424, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(425, 1, 425, NULL, NULL, 0, '2017-12-21 11:51:52', 1),
(426, 1, 426, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(427, 1, 427, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(428, 1, 428, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(429, 1, 429, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(430, 1, 430, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(431, 1, 431, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(432, 1, 432, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(433, 1, 433, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(434, 1, 434, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(435, 1, 435, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(436, 1, 436, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(437, 1, 437, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(438, 1, 438, NULL, NULL, 0, '2017-12-21 11:51:53', 1),
(439, 1, 439, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(440, 1, 440, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(441, 1, 441, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(442, 1, 442, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(443, 1, 443, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(444, 1, 444, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(445, 1, 445, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(446, 1, 446, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(447, 1, 447, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(448, 1, 448, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(449, 1, 449, NULL, NULL, 0, '2017-12-21 11:51:54', 1),
(450, 1, 450, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(451, 1, 451, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(452, 1, 452, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(453, 1, 453, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(454, 1, 454, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(455, 1, 455, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(456, 1, 456, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(457, 1, 457, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(458, 1, 458, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(459, 1, 459, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(460, 1, 460, NULL, NULL, 0, '2017-12-21 11:51:55', 1),
(461, 1, 461, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(462, 1, 462, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(463, 1, 463, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(464, 1, 464, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(465, 1, 465, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(466, 1, 466, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(467, 1, 467, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(468, 1, 468, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(469, 1, 469, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(470, 1, 470, NULL, NULL, 0, '2017-12-21 11:51:56', 1),
(471, 1, 471, NULL, NULL, 0, '2017-12-21 11:51:57', 1),
(472, 1, 472, NULL, NULL, 0, '2017-12-21 11:51:57', 1),
(473, 1, 473, NULL, NULL, 0, '2017-12-21 11:51:57', 1),
(474, 1, 474, NULL, NULL, 0, '2017-12-21 11:51:57', 1),
(475, 1, 475, NULL, NULL, 0, '2017-12-21 11:51:57', 1),
(476, 1, 476, NULL, NULL, 0, '2017-12-21 11:51:57', 1),
(477, 1, 477, NULL, NULL, 0, '2017-12-21 11:51:58', 1),
(478, 1, 478, NULL, NULL, 0, '2017-12-21 11:51:58', 1),
(479, 1, 479, NULL, NULL, 0, '2017-12-21 11:51:58', 1),
(480, 1, 480, NULL, NULL, 0, '2017-12-21 11:51:58', 1),
(481, 1, 481, NULL, NULL, 0, '2017-12-21 11:51:58', 1),
(482, 1, 482, NULL, NULL, 0, '2017-12-21 11:51:59', 1),
(483, 1, 483, NULL, NULL, 0, '2017-12-21 11:51:59', 1),
(484, 1, 484, NULL, NULL, 0, '2017-12-21 11:51:59', 1),
(485, 1, 485, NULL, NULL, 0, '2017-12-21 11:51:59', 1),
(486, 1, 486, NULL, NULL, 0, '2017-12-21 11:51:59', 1),
(487, 1, 487, NULL, NULL, 0, '2017-12-21 11:51:59', 1),
(488, 1, 488, NULL, NULL, 0, '2017-12-21 11:52:00', 1),
(489, 1, 489, NULL, NULL, 0, '2017-12-21 11:52:00', 1),
(490, 1, 490, NULL, NULL, 0, '2017-12-21 11:52:00', 1),
(491, 1, 491, NULL, NULL, 0, '2017-12-21 11:52:00', 1),
(492, 1, 492, NULL, NULL, 0, '2017-12-21 11:52:00', 1),
(493, 1, 493, NULL, NULL, 0, '2017-12-21 11:52:01', 1),
(494, 1, 494, NULL, NULL, 0, '2017-12-21 11:52:01', 1),
(495, 1, 495, NULL, NULL, 0, '2017-12-21 11:52:01', 1),
(496, 1, 496, NULL, NULL, 0, '2017-12-21 11:52:01', 1),
(497, 1, 497, NULL, NULL, 0, '2017-12-21 11:52:01', 1),
(498, 1, 498, NULL, NULL, 0, '2017-12-21 11:52:01', 1),
(499, 1, 499, NULL, NULL, 0, '2017-12-21 11:52:02', 1),
(500, 1, 500, NULL, NULL, 0, '2017-12-21 11:52:02', 1),
(501, 1, 501, NULL, NULL, 0, '2017-12-21 11:52:02', 1),
(502, 1, 502, NULL, NULL, 0, '2017-12-21 11:52:02', 1),
(503, 1, 503, NULL, NULL, 0, '2017-12-21 11:52:02', 1),
(504, 1, 504, NULL, NULL, 0, '2017-12-21 11:52:03', 1),
(505, 1, 505, NULL, NULL, 0, '2017-12-21 11:52:03', 1),
(506, 1, 506, NULL, NULL, 0, '2017-12-21 11:52:03', 1),
(507, 1, 507, NULL, NULL, 0, '2017-12-21 11:52:03', 1),
(508, 1, 508, NULL, NULL, 0, '2017-12-21 11:52:03', 1),
(509, 1, 509, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(510, 1, 510, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(511, 1, 511, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(512, 1, 512, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(513, 1, 513, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(514, 1, 514, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(515, 1, 515, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(516, 1, 516, NULL, NULL, 0, '2017-12-21 11:52:04', 1),
(517, 1, 517, NULL, NULL, 0, '2017-12-21 11:52:05', 1),
(518, 1, 518, NULL, NULL, 0, '2017-12-21 11:52:05', 1),
(519, 1, 519, NULL, NULL, 0, '2017-12-21 11:52:05', 1),
(520, 1, 520, NULL, NULL, 0, '2017-12-21 11:52:05', 1),
(521, 1, 521, NULL, NULL, 0, '2017-12-21 11:52:05', 1),
(522, 1, 522, NULL, NULL, 0, '2017-12-21 11:52:05', 1),
(523, 1, 523, NULL, NULL, 0, '2017-12-21 11:52:06', 1),
(524, 1, 524, NULL, NULL, 0, '2017-12-21 11:52:06', 1),
(525, 1, 525, NULL, NULL, 0, '2017-12-21 11:52:06', 1),
(526, 1, 526, NULL, NULL, 0, '2017-12-21 11:52:06', 1),
(527, 1, 527, NULL, NULL, 0, '2017-12-21 11:52:06', 1),
(528, 1, 528, NULL, NULL, 0, '2017-12-21 11:52:06', 1),
(529, 1, 529, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(530, 1, 530, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(531, 1, 531, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(532, 1, 532, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(533, 1, 533, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(534, 1, 534, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(535, 1, 535, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(536, 1, 536, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(537, 1, 537, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(538, 1, 538, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(539, 1, 539, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(540, 1, 540, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(541, 1, 541, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(542, 1, 542, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(543, 1, 543, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(544, 1, 544, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(545, 1, 545, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(546, 1, 546, NULL, NULL, 0, '2017-12-21 11:52:07', 1),
(547, 1, 547, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(548, 1, 548, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(549, 1, 549, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(550, 1, 550, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(551, 1, 551, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(552, 1, 552, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(553, 1, 553, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(554, 1, 554, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(555, 1, 555, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(556, 1, 556, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(557, 1, 557, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(558, 1, 558, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(559, 1, 559, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(560, 1, 560, NULL, NULL, 0, '2017-12-21 11:52:08', 1),
(561, 1, 561, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(562, 1, 562, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(563, 1, 563, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(564, 1, 564, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(565, 1, 565, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(566, 1, 566, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(567, 1, 567, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(568, 1, 568, NULL, NULL, 0, '2017-12-21 11:52:09', 1),
(569, 1, 569, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(570, 1, 570, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(571, 1, 571, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(572, 1, 572, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(573, 1, 573, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(574, 1, 574, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(575, 1, 575, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(576, 1, 576, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(577, 1, 577, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(578, 1, 578, NULL, NULL, 0, '2017-12-21 11:52:10', 1),
(579, 1, 579, NULL, NULL, 0, '2017-12-21 11:52:11', 1),
(580, 1, 580, NULL, NULL, 0, '2017-12-21 11:52:11', 1),
(581, 1, 581, NULL, NULL, 0, '2017-12-21 11:52:11', 1),
(582, 1, 582, NULL, NULL, 0, '2017-12-21 11:52:11', 1),
(583, 1, 583, NULL, NULL, 0, '2017-12-21 11:52:11', 1),
(584, 1, 584, NULL, NULL, 0, '2017-12-21 11:52:12', 1),
(585, 1, 585, NULL, NULL, 0, '2017-12-21 11:52:12', 1),
(586, 1, 586, NULL, NULL, 0, '2017-12-21 11:52:12', 1),
(587, 1, 587, NULL, NULL, 0, '2017-12-21 11:52:12', 1),
(588, 1, 588, NULL, NULL, 0, '2017-12-21 11:52:12', 1),
(589, 1, 589, NULL, NULL, 0, '2017-12-21 11:52:12', 1),
(590, 1, 590, NULL, NULL, 0, '2017-12-21 11:52:13', 1),
(591, 1, 591, NULL, NULL, 0, '2017-12-21 11:52:13', 1),
(592, 1, 592, NULL, NULL, 0, '2017-12-21 11:52:13', 1),
(593, 1, 593, NULL, NULL, 0, '2017-12-21 11:52:13', 1),
(594, 1, 594, NULL, NULL, 0, '2017-12-21 11:52:13', 1),
(595, 1, 595, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(596, 1, 596, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(597, 1, 597, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(598, 1, 598, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(599, 1, 599, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(600, 1, 600, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(601, 1, 601, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(602, 1, 602, NULL, NULL, 0, '2017-12-21 11:52:14', 1),
(603, 1, 603, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(604, 1, 604, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(605, 1, 605, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(606, 1, 606, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(607, 1, 607, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(608, 1, 608, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(609, 1, 609, NULL, NULL, 0, '2017-12-21 11:52:15', 1),
(610, 1, 610, NULL, NULL, 0, '2017-12-21 11:52:16', 1),
(611, 1, 611, NULL, NULL, 0, '2017-12-21 11:52:16', 1),
(612, 1, 612, NULL, NULL, 0, '2017-12-21 11:52:16', 1),
(613, 1, 613, NULL, NULL, 0, '2017-12-21 11:52:16', 1),
(614, 1, 614, NULL, NULL, 0, '2017-12-21 11:52:16', 1),
(615, 1, 615, NULL, NULL, 0, '2017-12-21 11:52:16', 1),
(616, 1, 616, NULL, NULL, 0, '2017-12-21 11:52:17', 1),
(617, 1, 617, NULL, NULL, 0, '2017-12-21 11:52:17', 1),
(618, 1, 618, NULL, NULL, 0, '2017-12-21 11:52:17', 1),
(619, 1, 619, NULL, NULL, 0, '2017-12-21 11:52:17', 1),
(620, 1, 620, NULL, NULL, 0, '2017-12-21 11:52:17', 1),
(621, 1, 621, NULL, NULL, 0, '2017-12-21 11:52:18', 1),
(622, 1, 622, NULL, NULL, 0, '2017-12-21 11:52:18', 1),
(623, 1, 623, NULL, NULL, 0, '2017-12-21 11:52:18', 1),
(624, 1, 624, NULL, NULL, 0, '2017-12-21 11:52:18', 1),
(625, 1, 625, NULL, NULL, 0, '2017-12-21 11:52:18', 1),
(626, 1, 626, NULL, NULL, 0, '2017-12-21 11:52:19', 1),
(627, 1, 627, NULL, NULL, 0, '2017-12-21 11:52:19', 1),
(628, 1, 628, NULL, NULL, 0, '2017-12-21 11:52:19', 1),
(629, 1, 629, NULL, NULL, 0, '2017-12-21 11:52:19', 1),
(630, 1, 630, NULL, NULL, 0, '2017-12-21 11:52:19', 1),
(631, 1, 631, NULL, NULL, 0, '2017-12-21 11:52:19', 1),
(632, 1, 632, NULL, NULL, 0, '2017-12-21 11:52:20', 1),
(633, 1, 633, NULL, NULL, 0, '2017-12-21 11:52:20', 1),
(634, 1, 634, NULL, NULL, 0, '2017-12-21 11:52:20', 1),
(635, 1, 635, NULL, NULL, 0, '2017-12-21 11:52:20', 1),
(636, 1, 636, NULL, NULL, 0, '2017-12-21 11:52:21', 1),
(637, 1, 637, NULL, NULL, 0, '2017-12-21 11:52:21', 1),
(638, 1, 638, NULL, NULL, 0, '2017-12-21 11:52:21', 1),
(639, 1, 639, NULL, NULL, 0, '2017-12-21 11:52:21', 1),
(640, 1, 640, NULL, NULL, 0, '2017-12-21 11:52:21', 1),
(641, 1, 641, NULL, NULL, 0, '2017-12-21 11:52:21', 1),
(642, 1, 642, NULL, NULL, 0, '2017-12-21 11:52:22', 1),
(643, 1, 643, NULL, NULL, 0, '2017-12-21 11:52:22', 1),
(644, 1, 644, NULL, NULL, 0, '2017-12-21 11:52:22', 1),
(645, 1, 645, NULL, NULL, 0, '2017-12-21 11:52:22', 1),
(646, 1, 646, NULL, NULL, 0, '2017-12-21 11:52:22', 1),
(647, 1, 647, NULL, NULL, 0, '2017-12-21 11:52:22', 1),
(648, 1, 648, NULL, NULL, 0, '2017-12-21 11:52:23', 1),
(649, 1, 649, NULL, NULL, 0, '2017-12-21 11:52:23', 1),
(650, 1, 650, NULL, NULL, 0, '2017-12-21 11:52:23', 1),
(651, 1, 651, NULL, NULL, 0, '2017-12-21 11:52:23', 1),
(652, 1, 652, NULL, NULL, 0, '2017-12-21 11:52:23', 1),
(653, 1, 653, NULL, NULL, 0, '2017-12-21 11:52:24', 1),
(654, 1, 654, NULL, NULL, 0, '2017-12-21 11:52:24', 1),
(655, 1, 655, NULL, NULL, 0, '2017-12-21 11:52:24', 1),
(656, 1, 656, NULL, NULL, 0, '2017-12-21 11:52:24', 1),
(657, 1, 657, NULL, NULL, 0, '2017-12-21 11:52:24', 1),
(658, 1, 658, NULL, NULL, 0, '2017-12-21 11:52:24', 1),
(659, 1, 659, NULL, NULL, 0, '2017-12-21 11:52:25', 1),
(660, 1, 660, NULL, NULL, 0, '2017-12-21 11:52:25', 1),
(661, 1, 661, NULL, NULL, 0, '2017-12-21 11:52:25', 1),
(662, 1, 662, NULL, NULL, 0, '2017-12-21 11:52:25', 1),
(663, 1, 663, NULL, NULL, 0, '2017-12-21 11:52:25', 1),
(664, 1, 664, NULL, NULL, 0, '2017-12-21 11:52:26', 1),
(665, 1, 665, NULL, NULL, 0, '2017-12-21 11:52:26', 1),
(666, 1, 666, NULL, NULL, 0, '2017-12-21 11:53:58', 1),
(667, 1, 667, NULL, NULL, 0, '2017-12-21 11:53:58', 1);

-- --------------------------------------------------------

--
-- Table structure for table `site_suppliers`
--

CREATE TABLE IF NOT EXISTS `site_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `start_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_site_suppliers_1_idx` (`supplier_id`),
  KEY `fk_site_suppliers_2_idx` (`site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `site_suppliers`
--

INSERT INTO `site_suppliers` (`id`, `supplier_id`, `site_id`, `start_date`, `end_date`, `created_on`, `status`) VALUES
(1, 1, 1, NULL, NULL, '2017-10-09 03:58:29', 1),
(2, 2, 1, NULL, NULL, '2017-11-02 15:52:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_issue_slip`
--

CREATE TABLE IF NOT EXISTS `store_issue_slip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `issue_type` int(1) NOT NULL COMMENT '0->civil,1->machanical.2->diesel 3->hr',
  `issue_to_dep_id` int(11) DEFAULT NULL,
  `issue_to_id` int(11) DEFAULT NULL,
  `emp_issue_type` int(1) DEFAULT NULL COMMENT '1->employee 2->contractor',
  `date_on` varchar(255) NOT NULL,
  `requisition_id` int(11) DEFAULT NULL,
  `authorised_by_id` int(11) DEFAULT NULL,
  `store_incharge_id` int(11) DEFAULT NULL,
  `received_by_id` int(11) DEFAULT NULL,
  `nature_id` int(11) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `purpose` varchar(255) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `last_reading` double DEFAULT NULL,
  `current_reading` double DEFAULT NULL,
  `quantity_issued` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1->create 2->approve 3->reject 4->close',
  PRIMARY KEY (`id`),
  KEY `fk_store_issue_slip_1_idx` (`site_id`),
  KEY `fk_store_issue_slip_2_idx` (`issue_to_dep_id`),
  KEY `fk_store_issue_slip_4_idx` (`requisition_id`),
  KEY `fk_store_issue_slip_5_idx` (`authorised_by_id`),
  KEY `fk_store_issue_slip_1_idx1` (`material_id`),
  KEY `fk_store_issue_slip_equipment_idx` (`equipment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `store_issue_slip`
--

INSERT INTO `store_issue_slip` (`id`, `serial_no`, `site_id`, `material_id`, `issue_type`, `issue_to_dep_id`, `issue_to_id`, `emp_issue_type`, `date_on`, `requisition_id`, `authorised_by_id`, `store_incharge_id`, `received_by_id`, `nature_id`, `created_on`, `purpose`, `equipment_id`, `last_reading`, `current_reading`, `quantity_issued`, `status`) VALUES
(1, 1, 1, NULL, 0, NULL, 12, 1, '2017-12-22 06:32:07', 1, NULL, NULL, NULL, 2, '2017-12-22 06:32:07', NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `store_slip_items`
--

CREATE TABLE IF NOT EXISTS `store_slip_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_slip_id` int(11) NOT NULL,
  `material_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `quantity_required` int(11) DEFAULT NULL,
  `quantity_issued` int(11) DEFAULT NULL,
  `rate` float(11,2) DEFAULT NULL,
  `amount` float(11,2) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_store_slip_items_1_idx` (`store_slip_id`),
  KEY `fk_store_slip_items_2_idx` (`material_id`),
  KEY `fk_store_slip_items_3_idx` (`unit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `store_slip_items`
--

INSERT INTO `store_slip_items` (`id`, `store_slip_id`, `material_id`, `equipment_id`, `unit_id`, `quantity_required`, `quantity_issued`, `rate`, `amount`, `remarks`, `created_on`) VALUES
(1, 1, 8, NULL, NULL, 1500, 1500, NULL, NULL, 'JCVNK', '2017-12-22 06:32:07'),
(2, 1, 9, NULL, NULL, 1000, 1000, NULL, NULL, 'kljvgl', '2017-12-22 06:32:07');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `type` varchar(255) NOT NULL,
  `gst_no` varchar(50) NOT NULL,
  `pan_no` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `account_no` varchar(255) DEFAULT NULL,
  `vendor_code` varchar(50) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `type`, `gst_no`, `pan_no`, `address`, `phone_no`, `bank_name`, `branch_name`, `ifsc_code`, `account_no`, `vendor_code`, `created_on`, `status`) VALUES
(1, 'jeevan', 'test', 'gst1234', '889955', 'thishjsdka', '8447726137', NULL, NULL, NULL, NULL, '12345', '2017-10-05 10:29:49', 1),
(2, 'supplier', 'temprory', '123654', '5445', 'asjdfhdkasf dskjfjasf', '844772625', NULL, NULL, NULL, NULL, '54321', '2017-11-02 15:51:45', 1),
(3, 'sadasd', 'asdds', 'asdas', 'dasdas', 'asdasd', 'das', NULL, NULL, NULL, NULL, 'asdasdasd', '2017-12-04 12:17:06', 1),
(4, 'Mahesh', 'any', '123456789', 'BASD1212GHDJ', 'Test', '1311616113', 'SBI', 'Gurgaon', 'SBIN00007689', '343254353455435', 'TEST123', '2017-12-14 08:58:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `terms_condition`
--

CREATE TABLE IF NOT EXISTS `terms_condition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `terms_file` varchar(255) DEFAULT NULL,
  `file_real_name` varchar(255) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `terms_condition`
--

INSERT INTO `terms_condition` (`id`, `name`, `content`, `terms_file`, `file_real_name`, `created_on`) VALUES
(3, 'purchase condition', '<ol><li>&nbsp;should be delivered within timeline.</li><li>receive on site.</li><li>Mention phone no.</li></ol>', NULL, NULL, '2017-12-01 13:23:09'),
(5, 'terms and codition', '<p><b style="color: rgb(34, 34, 34); font-family: sans-serif;">Clickwrapped.com</b><span style="color: rgb(34, 34, 34); font-family: sans-serif;">&nbsp;rates 15 companies on their policies and practices, with respect to: using users'' data, disclosing users'' data, amending the terms, closing users'' accounts, requiring arbitration, fining users, and clarity.</span><br></p>', NULL, NULL, '2017-12-04 08:13:33');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `unit_name`, `created_on`, `status`) VALUES
(1, 'kg', '2017-10-03 04:59:31', 1),
(2, 'test2', '2017-10-03 05:02:05', 1),
(3, 'test3', '2017-10-03 05:03:19', 1),
(4, 'km', '2017-10-05 12:49:01', 1),
(5, 'ton', '2017-11-30 09:56:02', 1),
(6, 'Bags', '2017-11-30 09:56:05', 1),
(7, 'No.', '2017-11-30 09:56:06', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `company_subscription`
--
ALTER TABLE `company_subscription`
  ADD CONSTRAINT `fk_company_subscription_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `composition_material`
--
ALTER TABLE `composition_material`
  ADD CONSTRAINT `fk_composition_material_composition_id` FOREIGN KEY (`composition_id`) REFERENCES `composition` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_composition_material_material_id` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `composition_site`
--
ALTER TABLE `composition_site`
  ADD CONSTRAINT `fk_composition_site_com_material_id` FOREIGN KEY (`composition_material_id`) REFERENCES `composition_material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_composition_site_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `fk_employee_department_id` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `emp_role`
--
ALTER TABLE `emp_role`
  ADD CONSTRAINT `fk_emp_role_1` FOREIGN KEY (`role_id`) REFERENCES `Role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_emp_role_2` FOREIGN KEY (`empid`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `indent_items`
--
ALTER TABLE `indent_items`
  ADD CONSTRAINT `fk_indent` FOREIGN KEY (`indent_id`) REFERENCES `indent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_indent_items_material` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `material`
--
ALTER TABLE `material`
  ADD CONSTRAINT `fk_material_1` FOREIGN KEY (`material_group_id`) REFERENCES `material_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_2` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_3` FOREIGN KEY (`material_type_id`) REFERENCES `material_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `material_receipt`
--
ALTER TABLE `material_receipt`
  ADD CONSTRAINT `fk_material_issue_slip__po` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_issue_slip_acc` FOREIGN KEY (`accountant_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_issue_slip_emp` FOREIGN KEY (`requested_store_keeper_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_issue_slip_pm` FOREIGN KEY (`project_manager_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_issue_slip_s_i` FOREIGN KEY (`received_store_incharge_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_issue_slip_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_issue_slip_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `material_receipt_items`
--
ALTER TABLE `material_receipt_items`
  ADD CONSTRAINT `fk_material_slip` FOREIGN KEY (`material_receipt_id`) REFERENCES `material_receipt` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_material_slip_items` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `site`
--
ALTER TABLE `site`
  ADD CONSTRAINT `fk_site_company` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_site_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `site_contractors`
--
ALTER TABLE `site_contractors`
  ADD CONSTRAINT `fk_site_contractors_contractors` FOREIGN KEY (`contractor_id`) REFERENCES `contractors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_site_contractors_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `site_employee`
--
ALTER TABLE `site_employee`
  ADD CONSTRAINT `fk_site_employee_emp_id` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_site_employee_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `site_material`
--
ALTER TABLE `site_material`
  ADD CONSTRAINT `fk_site_material_material_id` FOREIGN KEY (`material_id`) REFERENCES `material` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `site_material_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `site_suppliers`
--
ALTER TABLE `site_suppliers`
  ADD CONSTRAINT `fk_site_suppliers_site_id` FOREIGN KEY (`site_id`) REFERENCES `site` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_site_suppliers_suppliers_id` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
