CREATE DEFINER=`root`@`localhost` PROCEDURE `getAmmendedPurchaseOrderItems`(IN `po_idIn` BIGINT, IN `department_idIn` INT(11))
    NO SQL
BEGIN

IF(department_idIn = 4) THEN

SELECT apoi.id,
       apoi.amended_po_id as po_id,
       apoi.equipment_id,
       apoi.quantity,
       apoi.rate,
       apoi.gst,
       apoi.discount,
       apo.freight,
       apo.freight as total_amount,
       apo.total_amount,
       apoi.amount,
       e.asset_code,
		e.reg_no
       
FROM amended_po_items AS apoi
LEFT JOIN amended_po AS apo ON apoi.amended_po_id = apo.id
LEFT JOIN equipments AS e ON apoi.equipment_id = e.id 

WHERE apoi.amended_po_id = po_idIn
GROUP BY apoi.id; 

ELSE

SELECT apoi.id,
       apoi.amended_po_id as po_id,
       apoi.material_id,
       apoi.quantity,
       apoi.rate,
       apoi.gst,
       apoi.discount,
       apo.freight,
       apo.freight as total_amount,
       apoi.amount,
       m.material_name,
       m.product_code,
       u.unit_name,
       e.asset_code,
       m.descriptions,
       m.specifications,
       m.part_no
       
FROM amended_po_items AS apoi
LEFT JOIN amended_po AS apo ON apoi.amended_po_id = apo.id
LEFT JOIN material AS m ON apoi.material_id = m.id
LEFT JOIN unit AS u ON m.unit_id = u.id
LEFT JOIN equipments AS e ON apoi.equipment_id = e.id
WHERE apoi.amended_po_id = po_idIn
GROUP BY apoi.id; 

END IF;

END