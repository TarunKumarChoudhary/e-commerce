<?php
namespace App\Error;

use Cake\Error\ExceptionRenderer;
use Cake\Event\Event;

class AppError extends ExceptionRenderer
{
    public function render()
    {
        $this->controller->set('Employee', 'index');
        return parent::render();
    }

}