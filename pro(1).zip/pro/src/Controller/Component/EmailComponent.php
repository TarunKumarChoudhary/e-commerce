<?php 

namespace App\Controller\Component;
use Cake\Controller\Component;

require_once(ROOT . DS . 'vendor' . DS . 'PHPMailer' . DS . 'src' . DS . 'PHPMailer.php');
require_once(ROOT . DS . 'vendor' . DS . 'PHPMailer' . DS . 'src' . DS . 'Exception.php');
require_once(ROOT . DS . 'vendor' . DS . 'PHPMailer' . DS . 'src' . DS . 'SMTP.php');

use PHPMailer\PHPMailer\PHPMailer;

class EmailComponent extends Component
{
	public function sentMail($email_id, $subject, $message ,$attachmentFiles){
 		//pr($email_id);die;
 		$mail = new PHPMailer('true');
 		try {
		    //Server settings
		   // $mail->SMTPDebug = 3;                                 // Enable verbose debug output
		    $mail->isSMTP();                                      // Set mailer to use SMTP
		  /*  $mail->Host = 'ssl://smtp.gmail.com'; 				  // Specify main and backup SMTP servers
		    $mail->SMTPAuth = true;                               // Enable SMTP authentication
		    $mail->Username = 'nkccsm@gmail.com';                 // SMTP username
		    $mail->Password = 'nkccsm123';                           // SMTP password
		    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		    $mail->Port = 465;  */
		    
		    
		    $mail->Host = 'mail.rapidsoft.co.in'; 				  // Specify main and backup SMTP servers
		    $mail->SMTPAuth = true;                               // Enable SMTP authentication
		    $mail->Username = 'support@rapidsoft.co.in';                 // SMTP username
		    $mail->Password = 'Asdf#2015';                           // SMTP password
		    $mail->SMTPSecure = 'tls';
                                               // Enable TLS encryption, `ssl` also accepted
		    $mail->SMTPOptions = array(
				'ssl' => array(
					'verify_peer' => false,
					'verify_peer_name' => false,
					'allow_self_signed' => true
				)
			);
			$mail->Port = 587;                                  // TCP port to connect to

		    //Recipients
		    $mail->setFrom('support@rapidsoft.co.in', 'NKC');
		  	if(is_array($email_id)){  
		    	foreach ($email_id as $key => $value){
		    		$mail->addAddress($value['email_id']);
		    	}
			}else{
				$mail->addAddress($email_id);
			}
		    
		   
		    $mail->addReplyTo('support@rapidsoft.co.in', 'NKC');
		   // $mail->addCC('cc@example.com');
		   // $mail->addBCC('bcc@example.com');
		    if(!empty($attachmentFiles)){
			    foreach ($attachmentFiles as $key => $value) {
			    	$mail->addAttachment("/var/www/html/nkc/webroot".$value);
			    }
			}
		    //Attachments echo SITEURL.'/files/requisition_files
		    //$files = "/var/www/html/nkc/webroot/files/requisition_files/1511348513-4.png";
		    //echo $files;die;
		    //$mail->addAttachment($files);         // Add attachments
		   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

		    //Content
		    $mail->isHTML(true);                                  // Set email format to HTML
		    $mail->Subject = $subject;
		    $mail->Body    = $message;
		   // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients :-'.$message;
		    $mail->send();

		    return true;
		} catch (Exception $e) {
			 return true;
		    //echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
		}
 	}


}







?>
