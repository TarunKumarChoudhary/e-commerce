<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\ForbiddenException;
use Cake\Network\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\Datasource\ConnectionManager;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;

/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController
{

    /**
     * Displays a view
     *
     * @return void|\Cake\Network\Response
     * @throws \Cake\Network\Exception\ForbiddenException When a directory traversal attempt.
     * @throws \Cake\Network\Exception\NotFoundException When the view file could not
     *   be found or \Cake\View\Exception\MissingTemplateException in debug mode.
     */
    public function index(){

    }


    public function getProducts()
    {
    if($this->request->is('post')) {


        $limit = $this->request->data('limit');
        $offset = $this->request->data('offset');
        $search = $this->request->data('search');
        $rating = $this->request->data('rating');
        $brands = $this->request->data('brands');

        //$brands = (isset($brands))?$brands:'';
       /* $arrayNew = explode(',', $brands);
        $str = '';
        foreach ($arrayNew as $key => $value) {
          if($str != ''){
            $str .= '\',\'' .$value;
          }else{
            $str .= '\'' .$value;
          }

        }
        $str .= '\'';
     
        $rating = (isset($rating))?$rating:-1;
        $conn = ConnectionManager::get('default');
        $conn->logQueries(true);
          Log::config('queries', [
            'className' => 'File',
            'path' => LOGS,
            'file' => 'queries.log',
            'scopes' => ['queriesLog']
        ]);

        $result_data = $conn->execute("SELECT product.id,product.name,product.brand,product.des,product.price,product.rating,review.review_text,categories.name as category_name,product.image as image  FROM product left JOIN categories ON categories.id = product.category_id
      left JOIN review ON review.product_id = product.id

       WHERE (product.name LIKE ? OR categories.name LIKE ? OR product.brand LIKE ?) AND (? = -1 OR product.rating = ?) AND (? = '' OR product.brand IN (?))  LIMIT ? OFFSET ?",
       [$search.'%',$search.'%',$search.'%', $rating, $rating,$brands,$str, $limit, $offset],['string','string','string','integer','integer','string','string','integer','integer'])->fetchAll('assoc');
        $new = "";
        */
        $conditions = array();
        if($search){
          $conditions = array('OR'=>array('product.name LIKE'=>$search.'%','categories.name LIKE'=>$search.'%','product.brand LIKE'=>$search.'%'));
        }
        if($rating){
          $conditions['product.rating'] = $rating;
        }
        if($brands){
          $conditions['product.brand IN'] = $brands;
        }


        

        $Product = TableRegistry::get('product');
         $result_data = $Product->find()
            ->select(['product.id', 'product.name','product.brand','product.des','product.price','product.rating','review_text'=>'review.review_text','category_name'=>'categories.name','image'=>'product.image'])
            ->join([
                    'categories'=>[
                        'table'=>'categories',
                        'type'=>'left',
                        'conditions'=>'categories.id = product.category_id'
                    ],
                    'review'=>[
                        'table'=>'review',
                        'type'=>'left',
                        'conditions'=>'review.product_id = product.id'
                    ]
                ])
            ->where($conditions)
            ->offset($offset)
            ->limit($limit)
            ->hydrate(false)
            ->toArray();
               $total = $Product->find()->join([
                    'categories'=>[
                        'table'=>'categories',
                        'type'=>'left',
                        'conditions'=>'categories.id = product.category_id'
                    ],
                    'review'=>[
                        'table'=>'review',
                        'type'=>'left',
                        'conditions'=>'review.product_id = product.id'
                    ]
                ])->where($conditions)->count();


      
//pr($result_data);die;

        $newArray = [];
        foreach($result_data as $index=>$value){
            //$new = base64_encode($value['image']);
            $newArray[$index]['id'] =  $value['id'];
            $newArray[$index]['image'] =  base64_encode(stream_get_contents($value['image']));
            $newArray[$index]['name'] =  $value['name'];

            $newArray[$index]['brand'] =  $value['brand'];
            $newArray[$index]['des'] =  $value['des'];
            $newArray[$index]['price'] =  $value['price'];
            $newArray[$index]['rating'] =  $value['rating'];
            $newArray[$index]['review_text'] =  $value['review_text'];


        }
      //  pr($newArray);die;

    /*$total = $conn->execute("SELECT count(product.id) as total  FROM product left JOIN categories ON categories.id = product.category_id
      left JOIN review ON review.product_id = product.id
       WHERE product.name LIKE ? OR categories.name LIKE ? OR product.brand LIKE ? ",
       [$search.'%',$search.'%',$search.'%'],['string','string','string'])->fetchAll('assoc');
*/
    $res = ['rows'=>$newArray, 'total'=>$total];
    $this->response->header("Content-type", "image/jpeg");
    $this->response->body(json_encode($res));
    return $this->response;
    }
    }

    public function getBrands(){
      $conn = ConnectionManager::get('default');
      $brands = $conn->execute("SELECT DISTINCT brand from product")->fetchAll('assoc');
      $this->response->body(json_encode($brands));
      return $this->response;
    }

    public function getProductById($id){

      $conn = ConnectionManager::get('default');
      //$search = $this->request->data('search');
      $result_data = $conn->execute("SELECT product.id,product.name,product.brand,product.des,product.price,product.rating,review.review_text,categories.name as category_name,product.image as image  FROM product left JOIN categories ON categories.id = product.category_id
      left JOIN review ON review.product_id = product.id
      WHERE product.id = ? ",[$id])->fetchAll('assoc');
      $result_data[0]['image'] = base64_encode($result_data[0]['image']);
      $this->response->body(json_encode($result_data));
      return $this->response;
    }

    public function display()
    {
        echo "hello";die;
        $path = func_get_args();

        $count = count($path);
        if (!$count) {
            return $this->redirect('/');
        }
        if (in_array('..', $path, true) || in_array('.', $path, true)) {
            throw new ForbiddenException();
        }
        $page = $subpage = null;

        if (!empty($path[0])) {
            $page = $path[0];
        }
        if (!empty($path[1])) {
            $subpage = $path[1];
        }
        $this->set(compact('page', 'subpage'));

        try {
            $this->render(implode('/', $path));
        } catch (MissingTemplateException $e) {
            if (Configure::read('debug')) {
                throw $e;
            }
            throw new NotFoundException();
        }
    }
}
