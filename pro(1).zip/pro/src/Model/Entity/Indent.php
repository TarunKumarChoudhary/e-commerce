<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Indent Entity
 *
 * @property int $id
 * @property int $requisition_id
 * @property string $registered_on
 * @property string $indent_no
 * @property int $requested_by_id
 * @property int $verified_by_id
 * @property int $approved_by_id
 * @property bool $status
 * @property \Cake\I18n\Time $created_on
 *
 * @property \App\Model\Entity\Requisition $requisition
 * @property \App\Model\Entity\Employee $employee
 * @property \App\Model\Entity\ApprovalMaster[] $approval_master
 * @property \App\Model\Entity\IndentItem[] $indent_items
 * @property \App\Model\Entity\PurchaseOrder[] $purchase_orders
 */
class Indent extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
