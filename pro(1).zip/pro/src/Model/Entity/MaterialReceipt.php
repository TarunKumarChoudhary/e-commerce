<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MaterialReceipt Entity
 *
 * @property int $id
 * @property string $serial_no
 * @property int $site_id
 * @property int $supplier_id
 * @property string $mrn_no
 * @property string $mrn_date
 * @property string $bill_number
 * @property string $bill_date
 * @property string $truck_no
 * @property string $transport_name
 * @property int $po_id
 * @property int $requested_store_keeper_id
 * @property int $received_store_incharge_id
 * @property int $accountant_id
 * @property int $project_manager_id
 * @property bool $status
 * @property \Cake\I18n\Time $created_on
 *
 * @property \App\Model\Entity\Site $site
 * @property \App\Model\Entity\Supplier $supplier
 * @property \App\Model\Entity\PurchaseOrder $purchase_order
 * @property \App\Model\Entity\Employee $employee
 * @property \App\Model\Entity\MaterialReceiptItem[] $material_receipt_items
 */
class MaterialReceipt extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
