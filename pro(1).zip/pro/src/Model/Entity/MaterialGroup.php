<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MaterialGroup Entity
 *
 * @property int $id
 * @property int $parent_id
 * @property string $name
 * @property \Cake\I18n\Time $created_on
 * @property bool $status
 *
 * @property \App\Model\Entity\ParentMaterialGroup $parent_material_group
 * @property \App\Model\Entity\Material[] $material
 * @property \App\Model\Entity\ChildMaterialGroup[] $child_material_group
 */
class MaterialGroup extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
