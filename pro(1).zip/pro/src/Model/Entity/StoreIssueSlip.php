<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StoreIssueSlip Entity
 *
 * @property int $id
 * @property string $serial_no
 * @property int $site_id
 * @property int $material_id
 * @property int $issue_type
 * @property int $issue_to_dep_id
 * @property int $issue_to_id
 * @property string $date_on
 * @property int $requested_by_id
 * @property int $authorised_by_id
 * @property int $store_incharge_id
 * @property int $received_by_id
 * @property \Cake\I18n\Time $created_on
 * @property string $purpose
 * @property int $equipment_id
 * @property float $last_reading
 * @property float $current_reading
 * @property int $quantity_issued
 * @property int $status
 */
class StoreIssueSlip extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
