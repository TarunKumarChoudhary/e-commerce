<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Requisition Entity
 *
 * @property int $id
 * @property string $requisition_no
 * @property int $department_id
 * @property string $registered_on
 * @property int $issue_to_dep_id
 * @property int $issues_to_id
 * @property int $prepared_by_id
 * @property int $approved_by_id
 * @property int $hod_id
 * @property int $site_id
 * @property \Cake\I18n\Time $created_on
 * @property bool $status
 * @property bool $is_approved
 * @property int $save_to_draft
 *
 * @property \App\Model\Entity\Nature[] $nature
 * @property \App\Model\Entity\Department $department
 * @property \App\Model\Entity\Employee $employee
 * @property \App\Model\Entity\Site $site
 * @property \App\Model\Entity\ApprovalMaster[] $approval_master
 * @property \App\Model\Entity\Indent[] $indent
 * @property \App\Model\Entity\RequisitionItem[] $requisition_items
 */
class Requisition extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
