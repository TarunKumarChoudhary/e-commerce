<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Material Entity
 *
 * @property int $id
 * @property int $material_group_id
 * @property int $equipment_id
 * @property string $material_name
 * @property string $specifications
 * @property string $descriptions
 * @property string $part_no
 * @property string $product_code
 * @property float $loss_percentage
 * @property int $unit_id
 * @property string $brand
 * @property int $quantity
 * @property float $rate
 * @property int $material_type_id
 * @property \Cake\I18n\Time $created_on
 * @property bool $status
 *
 * @property \App\Model\Entity\MaterialGroup $material_group
 * @property \App\Model\Entity\Equipment $equipment
 * @property \App\Model\Entity\Unit $unit
 * @property \App\Model\Entity\MaterialType $material_type
 * @property \App\Model\Entity\IndentItem[] $indent_items
 * @property \App\Model\Entity\MaterialReceiptItem[] $material_receipt_items
 * @property \App\Model\Entity\PurchaseOrderItem[] $purchase_order_items
 * @property \App\Model\Entity\RequisitionItem[] $requisition_items
 * @property \App\Model\Entity\StoreIssueSlip[] $store_issue_slip
 * @property \App\Model\Entity\StoreSlipItem[] $store_slip_items
 * @property \App\Model\Entity\Composition[] $composition
 * @property \App\Model\Entity\Site[] $site
 */
class Material extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
