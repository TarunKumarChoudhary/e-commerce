<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Site Entity
 *
 * @property int $id
 * @property int $company_id
 * @property string $site_name
 * @property string $start_date
 * @property int $location_id
 * @property string $address
 * @property string $site_description
 * @property string $end_date
 * @property \Cake\I18n\Time $created_on
 * @property bool $status
 *
 * @property \App\Model\Entity\Company $company
 * @property \App\Model\Entity\Location $location
 * @property \App\Model\Entity\MaterialReceipt[] $material_receipt
 * @property \App\Model\Entity\Nature[] $nature
 * @property \App\Model\Entity\Requisition[] $requisition
 * @property \App\Model\Entity\SiteEquipment[] $site_equipment
 * @property \App\Model\Entity\StoreIssueSlip[] $store_issue_slip
 * @property \App\Model\Entity\Composition[] $composition
 * @property \App\Model\Entity\Contractor[] $contractors
 * @property \App\Model\Entity\Employee[] $employee
 * @property \App\Model\Entity\Material[] $material
 * @property \App\Model\Entity\Supplier[] $suppliers
 */
class Site extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
