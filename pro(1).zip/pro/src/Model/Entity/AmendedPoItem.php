<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * AmendedPoItem Entity
 *
 * @property int $id
 * @property int $amended_po_id
 * @property int $material_id
 * @property int $equipment_id
 * @property int $quantity
 * @property float $rate
 * @property float $discount
 * @property float $gst
 * @property float $amount
 *
 * @property \App\Model\Entity\AmendedPo $amended_po
 * @property \App\Model\Entity\Material $material
 * @property \App\Model\Entity\Equipment $equipment
 */
class AmendedPoItem extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
