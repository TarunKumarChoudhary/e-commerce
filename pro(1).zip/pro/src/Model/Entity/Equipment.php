<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Equipment Entity
 *
 * @property int $id
 * @property string $name
 * @property string $asset_code
 * @property string $engine_no
 * @property string $chasis_no
 * @property string $reg_no
 * @property string $insurance_from
 * @property string $insurance_to
 * @property string $road_tax_from
 * @property string $road_tax_to
 * @property string $brand
 * @property string $model
 * @property \Cake\I18n\Time $created_on
 * @property int $status
 *
 * @property \App\Model\Entity\Material[] $material
 * @property \App\Model\Entity\SiteEquipment[] $site_equipment
 * @property \App\Model\Entity\StoreIssueSlip[] $store_issue_slip
 */
class Equipment extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'id' => false
    ];
}
