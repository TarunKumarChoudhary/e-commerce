<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Equipments Model
 *
 * @property \Cake\ORM\Association\HasMany $Material
 * @property \Cake\ORM\Association\HasMany $SiteEquipment
 * @property \Cake\ORM\Association\HasMany $StoreIssueSlip
 *
 * @method \App\Model\Entity\Equipment get($primaryKey, $options = [])
 * @method \App\Model\Entity\Equipment newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Equipment[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Equipment|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Equipment patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Equipment[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Equipment findOrCreate($search, callable $callback = null, $options = [])
 */
class EquipmentsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('equipments');
        $this->displayField('name');
        $this->primaryKey('id');

        $this->hasMany('Material', [
            'foreignKey' => 'equipment_id'
        ]);
        $this->hasMany('SiteEquipment', [
            'foreignKey' => 'equipment_id'
        ]);
        $this->hasMany('StoreIssueSlip', [
            'foreignKey' => 'equipment_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('name', 'create')
            ->notEmpty('name');

        $validator
            ->allowEmpty('asset_code');

      /*  $validator
            ->requirePresence('engine_no', 'create')
            ->notEmpty('engine_no');

        $validator
            ->requirePresence('chasis_no', 'create')
            ->notEmpty('chasis_no');

        $validator
            ->requirePresence('reg_no', 'create')
            ->notEmpty('reg_no');

        $validator
            ->allowEmpty('insurance_from');

        $validator
            ->allowEmpty('insurance_to');

        $validator
            ->allowEmpty('road_tax_from');

        $validator
            ->allowEmpty('road_tax_to');

        $validator
            ->requirePresence('brand', 'create')
            ->notEmpty('brand');

        $validator
            ->requirePresence('model', 'create')
            ->notEmpty('model');
*/

        return $validator;
    }
}
