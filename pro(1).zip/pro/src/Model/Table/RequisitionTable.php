<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Requisition Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Department
 * @property \Cake\ORM\Association\BelongsTo $Department
 * @property \Cake\ORM\Association\BelongsTo $Employee
 * @property \Cake\ORM\Association\BelongsTo $Employee
 * @property \Cake\ORM\Association\BelongsTo $Employee
 * @property \Cake\ORM\Association\BelongsTo $Employee
 * @property \Cake\ORM\Association\BelongsTo $Site
 * @property \Cake\ORM\Association\HasMany $ApprovalMaster
 * @property \Cake\ORM\Association\HasMany $Indent
 * @property \Cake\ORM\Association\HasMany $RequisitionItems
 * @property \Cake\ORM\Association\BelongsToMany $Nature
 *
 * @method \App\Model\Entity\Requisition get($primaryKey, $options = [])
 * @method \App\Model\Entity\Requisition newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Requisition[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Requisition|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Requisition patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Requisition[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Requisition findOrCreate($search, callable $callback = null, $options = [])
 */
class RequisitionTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('requisition');
        $this->displayField('id');
        $this->primaryKey('id');

        
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        
        return $rules;
    }
}
