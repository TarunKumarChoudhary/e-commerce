<?php
namespace App\Model\Table;

use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Site Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Company
 * @property \Cake\ORM\Association\BelongsTo $Location
 * @property \Cake\ORM\Association\HasMany $MaterialReceipt
 * @property \Cake\ORM\Association\HasMany $Nature
 * @property \Cake\ORM\Association\HasMany $Requisition
 * @property \Cake\ORM\Association\HasMany $SiteEquipment
 * @property \Cake\ORM\Association\HasMany $StoreIssueSlip
 * @property \Cake\ORM\Association\BelongsToMany $Composition
 * @property \Cake\ORM\Association\BelongsToMany $Contractors
 * @property \Cake\ORM\Association\BelongsToMany $Employee
 * @property \Cake\ORM\Association\BelongsToMany $Material
 * @property \Cake\ORM\Association\BelongsToMany $Suppliers
 *
 * @method \App\Model\Entity\Site get($primaryKey, $options = [])
 * @method \App\Model\Entity\Site newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Site[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Site|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Site patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Site[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Site findOrCreate($search, callable $callback = null, $options = [])
 */
class SiteTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('site');
        $this->displayField('id');
        $this->primaryKey('id');

        $this->belongsTo('Company', [
            'foreignKey' => 'company_id',
            'joinType'   => 'INNER',
        ]);
        $this->belongsTo('Location', [
            'foreignKey' => 'location_id',
            'joinType'   => 'INNER',
        ]);
        $this->hasMany('MaterialReceipt', [
            'foreignKey' => 'site_id',
        ]);
        $this->hasMany('Nature', [
            'foreignKey' => 'site_id',
        ]);
        $this->hasMany('Requisition', [
            'foreignKey' => 'site_id',
        ]);
        $this->hasMany('SiteEquipment', [
            'foreignKey' => 'site_id',
        ]);
        $this->hasMany('StoreIssueSlip', [
            'foreignKey' => 'site_id',
        ]);
        $this->belongsToMany('Composition', [
            'foreignKey'       => 'site_id',
            'targetForeignKey' => 'composition_id',
            'joinTable'        => 'composition_site',
        ]);
        $this->belongsToMany('Contractors', [
            'foreignKey'       => 'site_id',
            'targetForeignKey' => 'contractor_id',
            'joinTable'        => 'site_contractors',
        ]);
        $this->belongsToMany('Employee', [
            'foreignKey'       => 'site_id',
            'targetForeignKey' => 'employee_id',
            'joinTable'        => 'site_employee',
        ]);
        $this->belongsToMany('Material', [
            'foreignKey'       => 'site_id',
            'targetForeignKey' => 'material_id',
            'joinTable'        => 'site_material',
        ]);
        $this->belongsToMany('Suppliers', [
            'foreignKey'       => 'site_id',
            'targetForeignKey' => 'supplier_id',
            'joinTable'        => 'site_suppliers',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('site_name', 'create')
            ->notEmpty('site_name');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['company_id'], 'Company'));
        $rules->add($rules->existsIn(['location_id'], 'Location'));

        return $rules;
    }
}
